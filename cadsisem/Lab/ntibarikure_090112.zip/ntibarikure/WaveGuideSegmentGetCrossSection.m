function [ a, b, xo, yo ] = WaveGuideSegmentGetCrossSection( TwoPortSegment )
% Returns parameters

a = TwoPortSegment.a;
b = TwoPortSegment.b;
xo = TwoPortSegment.xo;
yo = TwoPortSegment.yo;