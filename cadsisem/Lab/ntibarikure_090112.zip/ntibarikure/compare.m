cd '..\..\..\CdL\Didattica\LezioniCAD 2004\MMfront-end';
bof0
cd '..\..\..\..\Lavori\aperti\cad-mm';
bof
