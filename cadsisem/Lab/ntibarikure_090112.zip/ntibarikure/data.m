load data
spy(GSM - A)