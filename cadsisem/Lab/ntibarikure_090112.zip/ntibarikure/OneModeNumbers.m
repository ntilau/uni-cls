function [ kx, ky ] = OneModeEigens( a, b, m, n )
%WAVENUMBERS Summary of this function goes here
%   Detailed explanation goes here

kx = m*pi/a;

ky = n*pi/b;



