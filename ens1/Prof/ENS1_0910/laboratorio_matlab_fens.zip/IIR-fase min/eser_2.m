function [titolo,testo,tvec,vvec]=eser_2(val_vec)
%
%	Funzione ESER_n( <vettore parametri> )
%		
%	in questa funzione viene definito l'esercizio
%	da visualizzare.
%
%	titolo - - - -  e' una stringa che descrive brevemente
%			il contenuto del grafico mostrato.
%
%	testo  - - - -  e' una matrice di stringhe (costruita con la
%			funzione STR2MAT) che descrive in modo piu'
%			dettagliato il contenuto dell'esercizio.
%
%	tvec - - - - -  e' la matrice contenente le etichette dei campi edit 
%			associati ai parametri,descrive il significato di
%			ogni parametro.
%
%	vvec - - - - -  e' la matrice contenente i valori dei campi edit 
%			associati ai parametri.
%

hndl_v = get(gcf,'UserData');
assi_1 = hndl_v(13);
assi_2 = hndl_v(14);

%#########################################################################
%####################  INIZIO PARTE DA MODIFICARE ########################
%#########################################################################


		tvec = str2mat('amp.p =',...
		'fase.p =',...
		'amp.z =',...
		'fase.z =',...
		' ');

	titolo = 'Filtri IIR - Sistemi a fase minima - risp. impulsiva';

	testo = str2mat(...
	         'Il sistema descritto da poli/zeri di colore giallo', ...
	 	 'da'' origine al corrispondente sistema a fase minima',...
		 'descritto dai poli/zeri di colore azzurro.',...
	         'Per ciascuna coppia di poli (o zeri) si definiscono', ...
	         'ampiezza e fase (normalizzata a PI) di solo uno di essi');

	
if nargin~=1;
	load savedata;
	return;
else
	vvec = val_vec;
end;

ap=str2num(val_vec(1,:));
fp=str2num(val_vec(2,:))*pi;
az=str2num(val_vec(3,:));
fz=str2num(val_vec(4,:))*pi;

z1=[az*exp(i*fz); az*exp(-i*fz)];
if abs(z1(1))>1;
	z2=[1/az*exp(i*fz); 1/az*exp(-i*fz)];
else
	z2=z1;
end;

p1=[ap*exp(i*fp); ap*exp(-i*fp)];
if abs(p1(1))>1;
	p2=[1/ap*exp(i*fp); 1/ap*exp(-i*fp)];
else
	p2=p1;
end;

k=1;
[b1,a1] = zp2tf(z1,p1,k);
[b2,a2] = zp2tf(z2,p2,k);
y1=dimpulse(b1,a1);
y2=dimpulse(b2,a2);

subplot(assi_1);
	stemcol(y1,[1 1 0]);
	title('Risposta impulsiva del sistema GIALLO','Color',[1 1 0]);
	axis('off');

subplot(assi_2);
	stemcol(y2,[0 1 1]);
	title('Risposta impulsiva del sistema AZZURRO','Color',[0 1 1]);
	axis('off');

%#########################################################################
%####################   FINE  PARTE DA MODIFICARE ########################
%#########################################################################
return;
