function [titolo,testo,tvec,vvec]=eser_1(val_vec)
%
%	Funzione ESER_n( <vettore parametri> )
%		
%	in questa funzione viene definito l'esercizio
%	da visualizzare.
%
%	titolo - - - -  e' una stringa che descrive brevemente
%			il contenuto del grafico mostrato.
%
%	testo  - - - -  e' una matrice di stringhe (costruita con la
%			funzione STR2MAT) che descrive in modo piu'
%			dettagliato il contenuto dell'esercizio.
%
%	tvec - - - - -  e' la matrice contenente le etichette dei campi edit 
%			associati ai parametri,descrive il significato di
%			ogni parametro.
%
%	vvec - - - - -  e' la matrice contenente i valori dei campi edit 
%			associati ai parametri.
%

hndl_v = get(gcf,'UserData');
assi_1 = hndl_v(13);
assi_2 = hndl_v(14);

%#########################################################################
%####################  INIZIO PARTE DA MODIFICARE ########################
%#########################################################################

		tvec = str2mat('amp.p =',...
		'fase.p =',...
		'amp.z =',...
		'fase.z =',...
		' ');

	titolo = 'Filtri IIR - Sistemi a fase minima';

	testo = str2mat(...
	         'Il sistema descritto da poli/zeri di colore giallo', ...
	 	 'da'' origine al corrispondente sistema a fase minima',...
		 'descritto dai poli/zeri di colore azzurro.',...
	         'Per ciascuna coppia di poli (o zeri) si definiscono', ...
	         'ampiezza e fase (normalizzata a PI) di solo uno di essi');

	
if nargin~=1;
	vvec=str2mat('0.9','0.25','1.5','0.5',' ');
	return;
else
	vvec = val_vec;
end;
save savedata vvec;
ap=str2num(val_vec(1,:));
fp=str2num(val_vec(2,:))*pi;
az=str2num(val_vec(3,:));
fz=str2num(val_vec(4,:))*pi;

z1=[az*exp(i*fz); az*exp(-i*fz)];
if abs(z1(1))<1;
	z2=z1;
else
	z2=[1/az*exp(i*fz); 1/az*exp(-i*fz)];
end;
p1=[ap*exp(i*fp); ap*exp(-i*fp)];
p2=p1;

k=1;
[b1,a1] = zp2tf(z1,p1,k);
[b2,a2] = zp2tf(z2,p2,k);
[h1,w1] = freqz(b1,a1);
[h2,w2] = freqz(b2,a2);
hmax=max(abs(h1));
subplot(assi_1);
	[zeri1,poli1,assi1]=zplane(z1,p1);
	hold on;
	[zeri2,poli2,assi2]=zplane(z2,p2);
	hold off;
	set(assi2,'Color',[1 1 1]);
	set(poli2,'Color',[1 1 1]);
	set(zeri2,'Color',[0 1 1]);
	set(assi1,'Color',[1 1 1]);
	set(poli1,'Color',[1 1 1]);
	set(zeri1,'Color',[1 1 0]);
	if z1==z2;
		set(zeri1,'Color',[1 1 1]);
	end;
subplot(assi_2),
 plot(w1/(2*pi),abs(h1)/hmax,'r-',...
	w1/(2*pi),angle(h1)/pi,'y:',w2/(2*pi),angle(h2)/pi,'c:'),
 ylabel('Amp. e Fase'),xlabel('F freq. normalizzata'),axis([0 0.5 -1 1]);
 h1=text(0.01,0.8,'Amp.');
 h2=text(0.01,-0.5,'Fase 1');
 h3=text(0.01,-0.8,'Fase 2');
 set(h1,'Color',[1 0 0]);
 set(h2,'Color',[1 1 0]);
 set(h3,'Color',[0 1 1]);


%#########################################################################
%####################   FINE  PARTE DA MODIFICARE ########################
%#########################################################################
return;
