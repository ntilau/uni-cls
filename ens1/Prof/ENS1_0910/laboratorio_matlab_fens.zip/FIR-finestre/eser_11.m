function [titolo,testo,tvec,vvec]=eser_11(val_vec)
%
%	Funzione ESER_n( <vettore parametri> )
%		
%	in questa funzione viene definito l'esercizio
%	da visualizzare.
%
%	titolo - - - -  e' una stringa che descrive brevemente
%			il contenuto del grafico mostrato.
%
%	testo  - - - -  e' una matrice di stringhe (costruita con la
%			funzione STR2MAT) che descrive in modo piu'
%			dettagliato il contenuto dell'esercizio.
%
%	tvec - - - - -  e' la matrice contenente le etichette dei campi edit 
%			associati ai parametri,descrive il significato di
%			ogni parametro.
%
%	vvec - - - - -  e' la matrice contenente i valori dei campi edit 
%			associati ai parametri.
%

hndl_v = get(gcf,'UserData');
assi_1 = hndl_v(13);
assi_2 = hndl_v(14);

%#########################################################################
%####################  INIZIO PARTE DA MODIFICARE ########################
%#########################################################################

	tvec = str2mat('N =',...
		'F1 =',...
		'F2 =',...
		' ',...
		' ');

	titolo = 'Progetto di filtro elimina banda - (dB)';

	testo = str2mat(...
	 'Sono qui rappresentate le risposte in ampiezza in dB',...
 	 'dei filtri progettati col metodo a finestre', ...
         'confrontate con la risposta ideale desiderata.', ...
         '', ...
 	 '');


	
if nargin~=1;
	vvec=str2mat('21','0.20','0.30',' ',' ');
	return;
else
	vvec = val_vec;
end;

N=str2num(val_vec(1,:))-1;
Wt1=str2num(val_vec(2,:))*2;
Wt2=str2num(val_vec(3,:))*2;
Wt=[Wt1 Wt2];

b_hamming=fir1(N,Wt,'stop',hamming(N+1));
b_kaiser=fir1(N,Wt,'stop',kaiser(N+1,10));
b_rect=fir1(N,Wt,'stop',boxcar(N+1));

[hh,wh] = freqz(b_hamming,[1]);
[hk,wk] = freqz(b_kaiser,[1]);
[hr,wr] = freqz(b_rect,[1]);
x=[0 Wt1/2 Wt1/2 Wt2/2 Wt2/2 1];
y=[1 1 0 0 1 1];
hmax=max(20*log10(abs(hr)));
hmin=min(20*log10(abs(hr)));
delta=hmax-hmin;
subplot(assi_1),
 plot(wh/(2*pi),20*log10(abs(hh)),'m-',...
	wk/(2*pi),20*log10(abs(hk)),'g-',...
	wr/(2*pi),20*log10(abs(hr)),'r-'),
	ylabel('Risposta di Ampiezza (dB)'),
	xlabel('F freq. normalizzata'),
	axis([0 0.5 hmin hmax]);
 	h1=text(0.01,0.1*delta+hmin,'Hamming');
 	h2=text(0.01,0.15*delta+hmin,'Kaiser');
 	h3=text(0.01,0.20*delta+hmin,'Rettangolare');
 	set(h1,'Color',[1 0 1]);
 	set(h2,'Color',[0 1 0]);
 	set(h3,'Color',[1 0 0]);
	title('Filtro ELIMINA BANDA');

%#########################################################################
%####################   FINE  PARTE DA MODIFICARE ########################
%#########################################################################
return;
