function [titolo,testo,tvec,vvec]=eser_12(val_vec)
%
%	Funzione ESER_n( <vettore parametri> )
%		
%	in questa funzione viene definito l'esercizio
%	da visualizzare.
%
%	titolo - - - -  e' una stringa che descrive brevemente
%			il contenuto del grafico mostrato.
%
%	testo  - - - -  e' una matrice di stringhe (costruita con la
%			funzione STR2MAT) che descrive in modo piu'
%			dettagliato il contenuto dell'esercizio.
%
%	tvec - - - - -  e' la matrice contenente le etichette dei campi edit 
%			associati ai parametri,descrive il significato di
%			ogni parametro.
%
%	vvec - - - - -  e' la matrice contenente i valori dei campi edit 
%			associati ai parametri.
%

hndl_v = get(gcf,'UserData');
assi_1 = hndl_v(13);
assi_2 = hndl_v(14);

%#########################################################################
%####################  INIZIO PARTE DA MODIFICARE ########################
%#########################################################################

	tvec = str2mat('N =',...
		'F1 =',...
		'F2 =',...
		' ',...
		' ');

	titolo = 'Risposta Impulsiva - Finestra di Hamming';

	testo = str2mat(...
	 'Viene mostrata la risposta all''impulso unitario',...
 	 'del filtro calcolato con il metodo a finestre', ...
         'utilizzando da finestra di Hamming', ...
         '', ...
 	 '');


	
if nargin~=1;
	vvec=str2mat('21','0.20','0.30',' ',' ');
	return;
else
	vvec = val_vec;
end;

N=str2num(val_vec(1,:))-1;
Wt1=str2num(val_vec(2,:))*2;
Wt2=str2num(val_vec(3,:))*2;
Wt=[Wt1 Wt2];

b_hamming=fir1(N,Wt,'stop',hamming(N+1));

subplot(assi_1),
	stem(b_hamming);
	xlabel('Campioni');
	title('Elimina Banda - Hamming');
	axis('off');

%#########################################################################
%####################   FINE  PARTE DA MODIFICARE ########################
%#########################################################################
return;
