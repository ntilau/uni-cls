function [titolo,testo,tvec,vvec]=eser_1(val_vec)
%
%	Funzione ESER_n( <vettore parametri> )
%		
%	in questa funzione viene definito l'esercizio
%	da visualizzare.
%
%	titolo - - - -  e' una stringa che descrive brevemente
%			il contenuto del grafico mostrato.
%
%	testo  - - - -  e' una matrice di stringhe (costruita con la
%			funzione STR2MAT) che descrive in modo piu'
%			dettagliato il contenuto dell'esercizio.
%
%	tvec - - - - -  e' la matrice contenente le etichette dei campi edit 
%			associati ai parametri,descrive il significato di
%			ogni parametro.
%
%	vvec - - - - -  e' la matrice contenente i valori dei campi edit 
%			associati ai parametri.
%

hndl_v = get(gcf,'UserData');
assi_1 = hndl_v(13);
assi_2 = hndl_v(14);

%#########################################################################
%####################  INIZIO PARTE DA MODIFICARE ########################
%#########################################################################

	tvec = str2mat('N =',...
		'F1 =',...
		' ',...
		' ',...
		' ');

	titolo = 'Progetto di filtro passa basso - (lineare)';

	testo = str2mat(...
	 'Sono qui rappresentate le risposte in ampiezza',...
 	 'dei filtri progettati col metodo a finestre', ...
         'confrontate con la risposta ideale desiderata.', ...
         '', ...
 	 '');


	
if nargin~=1;
	vvec=str2mat('5','0.25',' ',' ',' ');
	return;
else
	vvec = val_vec;
end;

N=str2num(val_vec(1,:))-1;
Wt=str2num(val_vec(2,:))*2;

b_hamming=fir1(N,Wt,hamming(N+1));
b_kaiser=fir1(N,Wt,kaiser(N+1,10));
b_rect=fir1(N,Wt,boxcar(N+1));

[hh,wh] = freqz(b_hamming,[1]);
[hk,wk] = freqz(b_kaiser,[1]);
[hr,wr] = freqz(b_rect,[1]);
x=[0 Wt/2 Wt/2 1];
y=[1 1 0 0];
hmax=max(abs(hr));
subplot(assi_1),
 plot(wh/(2*pi),abs(hh),'m-',...
	wk/(2*pi),abs(hk),'g-',...
	wr/(2*pi),abs(hr),'r-'),
	ylabel('Risposta di Ampiezza'),
	xlabel('F freq. normalizzata'),
	axis([0 0.5 0 hmax]);
 	h1=text(0.01,0.1,'Hamming');
 	h2=text(0.01,0.15,'Kaiser');
 	h3=text(0.01,0.20,'Rettangolare');
	h4=text(0.01,0.25,'Ideale');
 	set(h1,'Color',[1 0 1]);
 	set(h2,'Color',[0 1 0]);
 	set(h3,'Color',[1 0 0]);
 	set(h4,'Color',[1 1 0]);
	hl=line(x,y);
	set(hl,'Color',[1 1 0]);
	title('Filtro PASSA BASSO');

%#########################################################################
%####################   FINE  PARTE DA MODIFICARE ########################
%#########################################################################
return;
