function [titolo,testo,tvec,vvec]=eser_2(val_vec)
%
%	Funzione ESER_n( <vettore parametri> )
%		
%	in questa funzione viene definito l'esercizio
%	da visualizzare.
%
%	titolo - - - -  e' una stringa che descrive brevemente
%			il contenuto del grafico mostrato.
%
%	testo  - - - -  e' una matrice di stringhe (costruita con la
%			funzione STR2MAT) che descrive in modo piu'
%			dettagliato il contenuto dell'esercizio.
%
%	tvec - - - - -  e' la matrice contenente le etichette dei campi edit 
%			associati ai parametri,descrive il significato di
%			ogni parametro.
%
%	vvec - - - - -  e' la matrice contenente i valori dei campi edit 
%			associati ai parametri.
%

hndl_v = get(gcf,'UserData');
assi_1 = hndl_v(13);
assi_2 = hndl_v(14);

%#########################################################################
%####################  INIZIO PARTE DA MODIFICARE ########################
%#########################################################################

	tvec = str2mat('N =',...
		'F1 =',...
		'F2 =',...
		'W =',...
		' ');

	titolo = 'Parks-McClellan - Passa Basso - (dB)';

	testo = str2mat(...
	 'F1 --> fine banda passante',...
 	 'F2 --> inizio banda attenuata', ...
         'W  --> peso relativo banda attenuata', ...
         '', ...
 	 '');


	
if nargin~=1;
	vvec=str2mat('7','0.20','0.40','0.3',' ');
	return;
else
	vvec = val_vec;
end;

N=str2num(val_vec(1,:))-1;
F1=str2num(val_vec(2,:));
F2=str2num(val_vec(3,:));
W=str2num(val_vec(4,:));

F=2.*[0 F1  F2 0.5];
M=[1 1  0 0];
W=[1 W];

b=remez(N,F,M,W);
[h,w] = freqz(b,[1]);

x1=[0 F1];
y1=[1 1];
x2=[F2 0.5];
y2=[0 0];
hmax=max(20*log10(abs(h)));
hmin=min(20*log10(abs(h)));
delta=hmax-hmin;
subplot(assi_1),
 plot(w/(2*pi),20*log10(abs(h)),'m-'),
	ylabel('Risposta di Ampiezza (dB)'),
	xlabel('F freq. normalizzata'),
	axis([0 0.5 hmin hmax]);
 	h1=text(0.01,0.30*delta+hmin,'Parks-McClellan');
 	set(h1,'Color',[1 0 1]);
	title('Filtro PASSA BASSO');

%#########################################################################
%####################   FINE  PARTE DA MODIFICARE ########################
%#########################################################################
return;
