function [titolo,testo,tvec,vvec]=eser_10(val_vec)
%
%	Funzione ESER_n( <vettore parametri> )
%		
%	in questa funzione viene definito l'esercizio
%	da visualizzare.
%
%	titolo - - - -  e' una stringa che descrive brevemente
%			il contenuto del grafico mostrato.
%
%	testo  - - - -  e' una matrice di stringhe (costruita con la
%			funzione STR2MAT) che descrive in modo piu'
%			dettagliato il contenuto dell'esercizio.
%
%	tvec - - - - -  e' la matrice contenente le etichette dei campi edit 
%			associati ai parametri,descrive il significato di
%			ogni parametro.
%
%	vvec - - - - -  e' la matrice contenente i valori dei campi edit 
%			associati ai parametri.
%

hndl_v = get(gcf,'UserData');
assi_1 = hndl_v(13);
assi_2 = hndl_v(14);

%#########################################################################
%####################  INIZIO PARTE DA MODIFICARE ########################
%#########################################################################

	tvec = str2mat('N =',...
		'F1 =',...
		'F2 =',...
		'F3 =',...
		'F4 =');

	titolo = 'Parks-McClellan - Elimina Banda';

	testo = str2mat(...
	 'F1 --> fine I banda passante',...
 	 'F2 --> inizio banda attenuata', ...
         'F3 --> fine banda attenuata', ...
         'F4 --> inizio II banda passante', ...
 	 ' ');


	
if nargin~=1;
	vvec=str2mat('11','0.15','0.20','0.30','0.35');
	return;
else
	vvec = val_vec;
end;

N=str2num(val_vec(1,:))-1;
F1=str2num(val_vec(2,:));
F2=str2num(val_vec(3,:));
F3=str2num(val_vec(4,:));
F4=str2num(val_vec(5,:));

F=2.*[0 F1 F2 F3 F4 0.5];
M=[1 1 0 0 1 1];

b=remez(N,F,M);
[h,w] = freqz(b,[1]);

x1=[0 F1];
y1=[1 1];
x2=[F2 F3];
y2=[0 0];
x3=[F4 0.5];
y3=[1 1];
hmax=max(abs(h));
subplot(assi_1),
 plot(w/(2*pi),abs(h),'m-'),
	hold on,plot(x1,y1,'y-'),plot(x2,y2,'y-'),plot(x3,y3,'y-'),hold off,
	ylabel('Risposta di Ampiezza'),
	xlabel('F freq. normalizzata'),
	axis([0 0.5 0 hmax]);
 	h1=text(0.01,0.30,'Parks-McClellan');
	h4=text(0.01,0.20,'Ideale');
 	set(h1,'Color',[1 0 1]);
	set(h4,'Color',[1 1 0]);
	title('Filtro ELIMINA BANDA');

%#########################################################################
%####################   FINE  PARTE DA MODIFICARE ########################
%#########################################################################
return;
