function [titolo,testo,tvec,vvec]=eser_6(val_vec)
%
%	Funzione ESER_n( <vettore parametri> )
%		
%	in questa funzione viene definito l'esercizio
%	da visualizzare.
%
%	titolo - - - -  e' una stringa che descrive brevemente
%			il contenuto del grafico mostrato.
%
%	testo  - - - -  e' una matrice di stringhe (costruita con la
%			funzione STR2MAT) che descrive in modo piu'
%			dettagliato il contenuto dell'esercizio.
%
%	tvec - - - - -  e' la matrice contenente le etichette dei campi edit 
%			associati ai parametri,descrive il significato di
%			ogni parametro.
%
%	vvec - - - - -  e' la matrice contenente i valori dei campi edit 
%			associati ai parametri.
%

hndl_v = get(gcf,'UserData');
assi_1 = hndl_v(13);
assi_2 = hndl_v(14);

%#########################################################################
%####################  INIZIO PARTE DA MODIFICARE ########################
%#########################################################################

	tvec = str2mat('N =',...
		'F1 =',...
		'F2 =',...
		'W =',...
		' ');

	titolo = 'Parks-McClellan - Passa Alto - Risposta impulsiva';

	testo = str2mat(...
	 'F1 --> fine banda attenuata',...
 	 'F2 --> inizio banda passante', ...
         'W  --> peso relativo banda attenuata', ...
         '', ...
 	 '');


	
if nargin~=1;
	vvec=str2mat('7','0.20','0.40','0.3',' ');
	return;
else
	vvec = val_vec;
end;

N=str2num(val_vec(1,:))-1;
F1=str2num(val_vec(2,:));
F2=str2num(val_vec(3,:));
W=str2num(val_vec(4,:));

F=2.*[0 F1  F2 0.5];
M=[0 0 1 1];
W=[W 1];

b=remez(N,F,M,W);
subplot(assi_1),
	stem(b);
	xlabel('Campioni');
	title('Passa Alto - Parks-McClellan');
	axis('off');

%#########################################################################
%####################   FINE  PARTE DA MODIFICARE ########################
%#########################################################################
return;
