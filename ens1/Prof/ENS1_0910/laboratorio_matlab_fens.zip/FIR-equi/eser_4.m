function [titolo,testo,tvec,vvec]=eser_4(val_vec)
%
%	Funzione ESER_n( <vettore parametri> )
%		
%	in questa funzione viene definito l'esercizio
%	da visualizzare.
%
%	titolo - - - -  e' una stringa che descrive brevemente
%			il contenuto del grafico mostrato.
%
%	testo  - - - -  e' una matrice di stringhe (costruita con la
%			funzione STR2MAT) che descrive in modo piu'
%			dettagliato il contenuto dell'esercizio.
%
%	tvec - - - - -  e' la matrice contenente le etichette dei campi edit 
%			associati ai parametri,descrive il significato di
%			ogni parametro.
%
%	vvec - - - - -  e' la matrice contenente i valori dei campi edit 
%			associati ai parametri.
%

hndl_v = get(gcf,'UserData');
assi_1 = hndl_v(13);
assi_2 = hndl_v(14);

%#########################################################################
%####################  INIZIO PARTE DA MODIFICARE ########################
%#########################################################################

	tvec = str2mat('N =',...
		'F1 =',...
		'F2 =',...
		'W =',...
		' ');

	titolo = 'Parks-McClellan - Passa Alto';

	testo = str2mat(...
	 'F1 --> fine banda attenuata',...
 	 'F2 --> inizio banda passante', ...
         'W  --> peso relativo banda attenuata', ...
         '', ...
 	 '');


	
if nargin~=1;
	vvec=str2mat('7','0.20','0.40','0.3',' ');
	return;
else
	vvec = val_vec;
end;

N=str2num(val_vec(1,:))-1;
F1=str2num(val_vec(2,:));
F2=str2num(val_vec(3,:));
W=str2num(val_vec(4,:));

F=2.*[0 F1  F2 0.5];
M=[0 0 1 1];
W=[W 1];

b=remez(N,F,M,W);
[h,w] = freqz(b,[1]);

x1=[0 F1];
y1=[0 0];
x2=[F2 0.5];
y2=[1 1];
hmax=max(abs(h));
subplot(assi_1),
 plot(w/(2*pi),abs(h),'m-'),
	hold on,plot(x1,y1,'y-'),plot(x2,y2,'y-'),hold off,
	ylabel('Risposta di Ampiezza'),
	xlabel('F freq. normalizzata'),
	axis([0 0.5 0 hmax]);
 	h1=text(0.01,0.30,'Parks-McClellan');
	h4=text(0.01,0.20,'Ideale');
 	set(h1,'Color',[1 0 1]);
	set(h4,'Color',[1 1 0]);
	title('Filtro PASSA ALTO');

%#########################################################################
%####################   FINE  PARTE DA MODIFICARE ########################
%#########################################################################
return;
