function [titolo,testo,tvec,vvec]=eser_1(val_vec)
%
%	Funzione ESER_n( <vettore parametri> )
%		
%	in questa funzione viene definito l'esercizio
%	da visualizzare.
%
%	titolo - - - -  e' una stringa che descrive brevemente
%			il contenuto del grafico mostrato.
%
%	testo  - - - -  e' una matrice di stringhe (costruita con la
%			funzione STR2MAT) che descrive in modo piu'
%			dettagliato il contenuto dell'esercizio.
%
%	tvec - - - - -  e' la matrice contenente le etichette dei campi edit 
%			associati ai parametri,descrive il significato di
%			ogni parametro.
%
%	vvec - - - - -  e' la matrice contenente i valori dei campi edit 
%			associati ai parametri.
%

hndl_v = get(gcf,'UserData');
assi_1 = hndl_v(13);
assi_2 = hndl_v(14);

%#########################################################################
%####################  INIZIO PARTE DA MODIFICARE ########################
%#########################################################################

	tvec = str2mat(' ',...
		' ',...
		' ',...
		' ',...
		' ');

	titolo = 'Segnale Analitico - segnale originale e rel. spettro';


testo = str2mat( 'Si considera un segnale campionato s(n) il cui spettro',...
		 'e'' rappresentato nella parte inferiore del grafico.', ...
                 '', ...
                 ' ', ...
		 ' ');

	
if nargin~=1;
	vvec=str2mat(' ',' ',' ',' ',' ');
	return;
else
	vvec = val_vec;
end;

funi=[zeros(1,210) (0:1/90:1) zeros(1,211)];
fbil=[funi funi(length(funi):-1:1)];
N=length(fbil);
spl=floor(N/4);
s=real(ifft(fbil));
ss=[s((N-spl+1):N) s(1:(N-spl))];

w=-.5:1/(N-1):0.5;
h=fftshift(fft(ss));
hmax=max(abs(h));
subplot(assi_1),stemcol(ss(1:100)),title('Segnale originale');
subplot(assi_2),
 plot(w,abs(h)/hmax,'m-'), %,w,angle(h)/pi,'g:'),
 ylabel('Ampiezza'),xlabel('F freq. normalizzata'),axis([-0.5 0.5 -1 1]);
% h1=text(-0.49,-0.8,'Amp.');
% h2=text(-0.49,-0.5,'Fase');
% set(h1,'Color',[1 0 1]);
% set(h2,'Color',[0 1 0]);


%#########################################################################
%####################   FINE  PARTE DA MODIFICARE ########################
%#########################################################################
return;
