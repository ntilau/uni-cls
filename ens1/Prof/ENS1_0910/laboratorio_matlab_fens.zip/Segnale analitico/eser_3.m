function [titolo,testo,tvec,vvec]=eser_3(val_vec)
%
%	Funzione ESER_n( <vettore parametri> )
%		
%	in questa funzione viene definito l'esercizio
%	da visualizzare.
%
%	titolo - - - -  e' una stringa che descrive brevemente
%			il contenuto del grafico mostrato.
%
%	testo  - - - -  e' una matrice di stringhe (costruita con la
%			funzione STR2MAT) che descrive in modo piu'
%			dettagliato il contenuto dell'esercizio.
%
%	tvec - - - - -  e' la matrice contenente le etichette dei campi edit 
%			associati ai parametri,descrive il significato di
%			ogni parametro.
%
%	vvec - - - - -  e' la matrice contenente i valori dei campi edit 
%			associati ai parametri.
%

hndl_v = get(gcf,'UserData');
assi_1 = hndl_v(13);
assi_2 = hndl_v(14);

%#########################################################################
%####################  INIZIO PARTE DA MODIFICARE ########################
%#########################################################################

	tvec = str2mat('Ord. =',...
		' ',...
		' ',...
		' ',...
		' ');

	titolo = 'Segnale Analitico - rappresentazione del segnale analitico';


testo = str2mat( 'Nella parte superiore viene rappresentato il',...
		 'segnale analitico (campioni reali ed immaginari).', ...
                 '', ...
                 'Nel grafico in basso e'' rappresentato lo spettro', ...
		 'di ampiezza e fase del segnale analitico considerato.');

	
if nargin~=1;
	vvec=str2mat('20',' ',' ',' ',' ');
	return;
else
	vvec = val_vec;
end;

remord=str2num(val_vec(1,:));

funi=[zeros(1,210) (0:1/90:1) zeros(1,211)];
fbil=[funi funi(length(funi):-1:1)];
N=length(fbil);
spl=floor(N/4);
ss=real(ifft(fbil));
s=[ss((N-spl+1):N) ss(1:(N-spl))];

pad=floor(remord/2);

b=remez(remord,[0.1 0.9],[1 1],'Hilbert');
hs=filter(b,[1],s);
hhs=[hs(pad+1:N) zeros(1,pad)];

as=s+i*hhs;

fana=fft(as);
w=-.5:1/(N-1):0.5;
h=fftshift(fana);
hmax=max(abs(h));
subplot(assi_1),stemcol(s(1:50),[1 1 0]),hold on,
stemcol(hhs(1:50),[0 1 1]),hold off,title('Segnale Analitico');
h1=text(40,0.05,'P.Reale');
h2=text(40,0.08,'P.Immag.');
set(h1,'Color',[1 1 0]);
set(h2,'Color',[0 1 1]);

subplot(assi_2),
 plot(w,abs(h)/hmax,'m-'),
 ylabel('Ampiezza'),xlabel('F freq. normalizzata'),axis([-0.5 0.5 -1 1]);


%#########################################################################
%####################   FINE  PARTE DA MODIFICARE ########################
%#########################################################################
return;
