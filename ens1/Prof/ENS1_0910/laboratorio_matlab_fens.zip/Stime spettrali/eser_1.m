function [titolo,testo,tvec,vvec]=eser_1(val_vec)
%
%	Funzione ESER_n( <vettore parametri> )
%		
%	in questa funzione viene definito l'esercizio
%	da visualizzare.
%
%	titolo - - - -  e' una stringa che descrive brevemente
%			il contenuto del grafico mostrato.
%
%	testo  - - - -  e' una matrice di stringhe (costruita con la
%			funzione STR2MAT) che descrive in modo piu'
%			dettagliato il contenuto dell'esercizio.
%
%	tvec - - - - -  e' la matrice contenente le etichette dei campi edit 
%			associati ai parametri,descrive il significato di
%			ogni parametro.
%
%	vvec - - - - -  e' la matrice contenente i valori dei campi edit 
%			associati ai parametri.
%

hndl_v = get(gcf,'UserData');
assi_1 = hndl_v(13);
assi_2 = hndl_v(14);

%#########################################################################
%####################  INIZIO PARTE DA MODIFICARE ########################
%#########################################################################

	tvec = str2mat('Freq.1 =',...
		'Freq.2 =',...
		'Freq.3 =',...
		'NFFT =',...
		'lin<->db');

	titolo = 'Stima spettrale, metodo di Welch';

	testo = str2mat(...
	 'Nel grafico superiore e'' visualizzata una sequenza',...
	 'ottenuta dalla somma di 3 segnali sinusoidali.', ...
         'La densita'' spettrale di potenza della sequenza viene', ...
         'stimata col metodo di Welch utilizzando la finestra di', ...
 	 'HAMMING.');


	
if nargin~=1;
	vvec=str2mat('0.08','0.25','0.41','256','lin');
	return;
else
	vvec = val_vec;
end;


f1=str2num(val_vec(1,:));
f2=str2num(val_vec(2,:));
f3=str2num(val_vec(3,:));
N=str2num(val_vec(4,:));
islin=length(findstr(val_vec(5,:),'lin'));



t=0:2*pi:2*pi*4096;
amp=1000;
s=(cos(f1*t)+cos(f2*t)+cos(f3*t)).*amp;

window=hamming(N);
[pxx,ff]=psd(s,N,1,window,'none');

subplot(assi_1),stem(s(1:50)),axis('off'),title('Sequenza');
subplot(assi_2);
if islin~=0;
	plot(ff,pxx),xlabel('Frequenza normalizzata'),
	title('Ampiezza dello Spettro di Potenza (lineare)'),
	ylabel(''),grid;
else
	plot(ff,10*log10(pxx)),xlabel('Frequenza normalizzata'),
	title('Ampiezza dello Spettro di Potenza (dB)'),
	ylabel(''),grid;

end;


%#########################################################################
%####################   FINE  PARTE DA MODIFICARE ########################
%#########################################################################
return;
