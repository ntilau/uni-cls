function [titolo,testo,tvec,vvec]=eser_3(val_vec)
%
%	Funzione ESER_n( <vettore parametri> )
%		
%	in questa funzione viene definito l'esercizio
%	da visualizzare.
%
%	titolo - - - -  e' una stringa che descrive brevemente
%			il contenuto del grafico mostrato.
%
%	testo  - - - -  e' una matrice di stringhe (costruita con la
%			funzione STR2MAT) che descrive in modo piu'
%			dettagliato il contenuto dell'esercizio.
%
%	tvec - - - - -  e' la matrice contenente le etichette dei campi edit 
%			associati ai parametri,descrive il significato di
%			ogni parametro.
%
%	vvec - - - - -  e' la matrice contenente i valori dei campi edit 
%			associati ai parametri.
%

hndl_v = get(gcf,'UserData');
assi_1 = hndl_v(13);
assi_2 = hndl_v(14);

%#########################################################################
%####################  INIZIO PARTE DA MODIFICARE ########################
%#########################################################################

	tvec = str2mat(' ',...
		' ',...
		' ',...
		' ',...
		' ');

	titolo = 'Confronto nel dominio del tempo';

	testo = str2mat(...
	 ' ',...
 	 'Sopra: il risultato della convoluzione circolare tra le', ...
	 '       due sequenze',...
 	 'Sotto: la trasformata di Fourier inversa del prodotto delle', ...
         '       dft');


	
if nargin~=1;
	vvec=str2mat(' ',' ',' ',' ',' ');
	return;
else
	vvec = val_vec;
end;

s1=[2 1 -1 2 1 1 2 1 -2 -1 2 ];
s2=[3 3 3 0 0 0 0 0 0 0 0 ];
N=length(s1);

d1=fft(s1);
d2=fft(s2);
d3=d1 .* d2;

f1=1:11;
f2=15:25;
f3=30:40;

id1=ifft(d3);

d1max=max(abs(d1));
d2max=max(abs(d2));
d3max=max(abs(d3));


subplot(assi_1), stem((id1)),axis('off'),
	text(1,-5,'Convoluzione Circolare');


subplot(assi_2), stem((id1)),axis('off'),text(1,-5,'IDFT del prodotto');


%#########################################################################
%####################   FINE  PARTE DA MODIFICARE ########################
%#########################################################################
return;
