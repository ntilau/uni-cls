function [titolo,testo,tvec,vvec]=eser_1(val_vec)
%
%	Funzione ESER_n( <vettore parametri> )
%		
%	in questa funzione viene definito l'esercizio
%	da visualizzare.
%
%	titolo - - - -  e' una stringa che descrive brevemente
%			il contenuto del grafico mostrato.
%
%	testo  - - - -  e' una matrice di stringhe (costruita con la
%			funzione STR2MAT) che descrive in modo piu'
%			dettagliato il contenuto dell'esercizio.
%
%	tvec - - - - -  e' la matrice contenente le etichette dei campi edit 
%			associati ai parametri,descrive il significato di
%			ogni parametro.
%
%	vvec - - - - -  e' la matrice contenente i valori dei campi edit 
%			associati ai parametri.
%

hndl_v = get(gcf,'UserData');
assi_1 = hndl_v(13);
assi_2 = hndl_v(14);

%#########################################################################
%####################  INIZIO PARTE DA MODIFICARE ########################
%#########################################################################

	tvec = str2mat(' ',...
		' ',...
		' ',...
		' ',...
		' ');

	titolo = 'Convoluzione Circolare';

	testo = str2mat(...
	 'Questo esercizio mostra la convoluzione circolare',...
 	 'tra due sequenze di 11 campioni.', ...
         'Le sequenze mostrate nella parte inferiore sono il', ...
         'risultato della convoluzione circolare e lineare',...
	 'tra le due sequenze mostrate nella parte superiore.');


	
if nargin~=1;
	vvec=str2mat(' ',' ',' ',' ',' ');
	return;
else
	vvec = val_vec;
end;

s1=[2 1 -1 2 1 1 2 1 -2 -1 2 ];
s2=[3 3 3 0 0 0 0 0 0 0 0 ];
N=length(s1);
s3=[s2(2:N) s2];
cl=conv(s1,s2);
c=conv(s1,s3);
NC=length(cl);
cc=c(N:NC);

t1=1:11;
t2=15:25;
tcc=1:N;
tcl=N+8:N+NC+7;

subplot(assi_1), stem(t1,s1),hold on, stem(t2,s2),hold off,
	axis([0 26 -2 5]),axis('off'),text(0,-1,'Seq. 1'),
	text(15,-1,'Seq. 2');
subplot(assi_2), stem(tcc,cc),hold on,stem(tcl,cl),hold off,
	axis('off'),text(0,-9,'Convoluzione Circolare'),
	text(N+8,-9,'Convoluzione Lineare');


%#########################################################################
%####################   FINE  PARTE DA MODIFICARE ########################
%#########################################################################
return;
