function [titolo,testo,tvec,vvec]=eser_2(val_vec)
%
%	Funzione ESER_n( <vettore parametri> )
%		
%	in questa funzione viene definito l'esercizio
%	da visualizzare.
%
%	titolo - - - -  e' una stringa che descrive brevemente
%			il contenuto del grafico mostrato.
%
%	testo  - - - -  e' una matrice di stringhe (costruita con la
%			funzione STR2MAT) che descrive in modo piu'
%			dettagliato il contenuto dell'esercizio.
%
%	tvec - - - - -  e' la matrice contenente le etichette dei campi edit 
%			associati ai parametri,descrive il significato di
%			ogni parametro.
%
%	vvec - - - - -  e' la matrice contenente i valori dei campi edit 
%			associati ai parametri.
%

hndl_v = get(gcf,'UserData');
assi_1 = hndl_v(13);
assi_2 = hndl_v(14);

%#########################################################################
%####################  INIZIO PARTE DA MODIFICARE ########################
%#########################################################################

	tvec = str2mat(' ',...
		' ',...
		' ',...
		' ',...
		' ');

	titolo = 'Proprieta'' della DFT [x(n) reale e pari]';

 testo = str2mat(...,
  'Se x(n) e'' REALE e PARI',...
  'allora', ...
  '            ', ...
  'X(k) e'' REALE e PARI', ...
  ' ');


	
if nargin~=1;
	vvec=str2mat(' ',' ',' ',' ',' ');
	return;
else
	vvec = val_vec;
end;

s1=[ 0 0 1 1 2 2 3 2 2 1 1 0 ];
N=length(s1);
f=fft(s1);

t=1:N;
tt=(N+5):(2*N+4);
fmax=max(abs(f));
x=[N+1 N+4];
y=[0 0];
subplot(assi_1),stem(s1),axis('off'),
	title('Sequenza x(n)');
subplot(assi_2),stem(t,real(f)/fmax),hold on,stem(tt,imag(f)/fmax),
	axis([0 2*N+6 -1 1]),h=line(x,y);
	set(h,'Color',[0 0 0]),axis('off'),hold off,
	text(1,-1.3,'Parte reale'),text(N+5,-1.3,'Parte immaginaria'),
	title('Trasformata Discreta di Fourier X(k)');


%#########################################################################
%####################   FINE  PARTE DA MODIFICARE ########################
%#########################################################################
return;
