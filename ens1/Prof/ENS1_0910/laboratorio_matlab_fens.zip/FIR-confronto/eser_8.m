function [titolo,testo,tvec,vvec]=eser_8(val_vec)
%
%	Funzione ESER_n( <vettore parametri> )
%		
%	in questa funzione viene definito l'esercizio
%	da visualizzare.
%
%	titolo - - - -  e' una stringa che descrive brevemente
%			il contenuto del grafico mostrato.
%
%	testo  - - - -  e' una matrice di stringhe (costruita con la
%			funzione STR2MAT) che descrive in modo piu'
%			dettagliato il contenuto dell'esercizio.
%
%	tvec - - - - -  e' la matrice contenente le etichette dei campi edit 
%			associati ai parametri,descrive il significato di
%			ogni parametro.
%
%	vvec - - - - -  e' la matrice contenente i valori dei campi edit 
%			associati ai parametri.
%

hndl_v = get(gcf,'UserData');
assi_1 = hndl_v(13);
assi_2 = hndl_v(14);

%#########################################################################
%####################  INIZIO PARTE DA MODIFICARE ########################
%#########################################################################

	tvec = str2mat('N =',...
		'F1 =',...
		'F2 =',...
		'F3 =',...
		'F4 =');

	titolo = 'Confronto Parks-McClellan <> Finestre - elimina banda - (dB)';

	testo = str2mat(...
	 'Nel grafico e'' visualizzata la risposta in freq. di:',...
 	 '  > filtro FIR progettato col metodo a finestre', ...
         '  > filtro FIR progettato col metodo di Parks-McClellan', ...
         '', ...
 	 'dove: [0,F1] b.pass., [F2,F3] b.att., [F4,0.5] b.pass.');


	
if nargin~=1;
	vvec=str2mat('9','0.1','0.20','0.30','0.4');
	return;
else
	vvec = val_vec;
end;

N=str2num(val_vec(1,:))-1;
F1=str2num(val_vec(2,:));
F2=str2num(val_vec(3,:));
F3=str2num(val_vec(4,:));
F4=str2num(val_vec(5,:));

F=[0 F1 F2 F3 F4 0.5];
M=[1 1 0 0 1 1];

b_hamming=fir2(N,F*2,M,hamming(N+1));
b_remez=remez(N,F*2,M);

[hh,wh] = freqz(b_hamming,[1]);
[hr,wr] = freqz(b_remez,[1]);

hmax=max(20*log10([abs(hr);abs(hh)]));
hmin=min(20*log10([abs(hr);abs(hh)]));
da=hmax-hmin;
subplot(assi_1),
 plot(wh/(2*pi),20*log10(abs(hh)),'g-',...
	wr/(2*pi),20*log10(abs(hr)),'c-'),
	ylabel('Risposta di Ampiezza (dB)'),
	xlabel('F freq. normalizzata'),
	axis([0 0.5 hmin hmax]);
 	h1=text(0.01,0.1*da+hmin,'Hamming');
 	h2=text(0.01,0.15*da+hmin,'Parks-McClellan');
 	set(h1,'Color',[0 1 0]);
 	set(h2,'Color',[0 1 1]);
	title('FIR Elimina Banda');

%#########################################################################
%####################   FINE  PARTE DA MODIFICARE ########################
%#########################################################################
return;
