@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

      Fondamenti di Elaborazione Numerica dei Segnali

@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

                   Prof. E. Del Re

          Esercitazioni di Laboratorio di MATLAB 

(Si richiede la versione 4.0 di MATLAB Student Edition 
o successive)

@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

Istruzioni d'uso :

Scaricare il file laboratorio_matlab_fens.zip
Scompattarlo in una unica cartella [percorso X]
(tutte le esercitazioni proposte sono memorizzate come sottocartelle) 


       1) Avviare MATLAB.

       2) All'interno della finestra di MATLAB selezionare come
          "Currente Directory" il percorso X 
          (nella finestra compaiono tutte le sottocartelle delle esercitazioni)
          Selezionare (doppio click) la cartella con la esercitazione desiderata; ad es.

                     Aliasing
 
          
       3) All'interno della finestra "Command Window" di MATLAB
          digitare
                     panel (+invio)

       4) Nella nuova finestra che appare premere il
          pulsante SUCCESSIVO con il mouse.

       5) Premere il pulsante APPLICA con il mouse.

       6) Ripetere dal punto (4) fino ad esaurimento
          delle schermate della esercitazione scelta

       7) Premere il pulsante ESCI

       8) Ripetere dal punto (2) con una nuova
          esercitazione

NOTE:
       Durante le esercitazioni � possibile modificare
       i valori dei  parametri  mostrati  nella  parte
       destra della finestra attivata da "panel".
       Per ottenere ci� editare il valore del parametro
       ponendovi il cursore col mouse e ri-eseguire
       l'esercitazione tramite il pulsante APPLICA.

@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

     Elenco esercizi presenti nel file .zip

@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

ALIASING
	Questo esercizio mostra lo spettro di un 
	segnale campionato con frequenze di campionamento
	che verificano o meno il criterio del 
	teorema del campionamento.

SEGNALE ANALITICO
	Questo esercizio mostra la costruzione del
	segnale analitico di una sequenza tramite
	la trasformata di Hilbert. 

FUNZ TRASF
	In questo esecizio sono  mostrate  le  posi-
	zioni dei  poli  e  zeri, la antitrasformata
 	ed il contenuto spettrale di funzioni razionali
	della variabile complessa z del I II e III
	ordine.
	E'anche riportato un esempio di convoluzione tra
	due sequenze.

CONFRONTO DFT-FFT
	La DFT e FFT di una sequenza di 4096 campioni
	sono confrontate in questo esercizio in termini 
	di tempo di CPU.

CONV-LIN-CIRC
	Sono mostrate la convoluzione lineare e quella circolare
	di due sequenze.
	Si mostra inoltre che l'antitrasformata del prodotto
	delle DFT di due sequenze e' proprio la convoluzione
	circolare delle stesse sequenze.


FIR FASE LINEARE
	Si verifica che un filtro FIR di Parks McClellan passa
	basso e' a fase lineare.


FIR-FINESTRE
	In questi esercizi vengono mostrate le risposte in ampiezza
	di filtri FIR (passa basso, passa alto, passa banda ed
	elimina banda) progettati col metodo a finestre
	utilizzando finestre di HAMMING, KAISER e RETTANGOLARE.
	Viene mostrata anche la risposta impulsiva di tali filtri.

FIR-EQUI
	In questi esercizi vengono progettati dei filtri FIR
	con il metodo di Parks McClellan di cui viene mostrata
	la risposta in ampiezza lineare ed in dB.
	I filtri sono passa basso,passa alto, passa banda, 
	elimina banda, trasformatore di Hilbert e derivatore.

FIR-CONFRONTO
	Si confrontano qui filtri FIR progettati col metodo a
	finestre e col metodo di Parks McClellan.
	La risposta in ampiezza e' rappresentata in scala
	lineare e logaritmica.

IIR-II ORD
	Vengono mostrate la posizione dei poli e zeri nel piano
	complesso e la risposta in ampiezza e fase di sistemi
	IIR del II ordine con, rispettivamente, 0 1 e 2 zeri.

IIR-FASE MIN
	Vengono confrontate la posizione dei poli e zeri nel piano
	complesso la risposta in ampiezza e fase e la risposta
	impulsiva di un sistema IIR del II ordine e del suo
	equivalente a fase minima.

IIR-PROT ANALOG
	Sono progettati, in questi esercizi, filtri IIR coi metodi
	di Butterworth, Chebychev I e II, metodo dei filtri
	ellittici. Sono confrontate le risposte in ampiezza di un
	passa basso, passa alto, passa banda ed elimina banda.

IIR-DIRETTO
	Gli stessi filtri del gruppo di esercizi IIR3 sono
	adesso progettati col metodo di Yule Walker.

PROP DFT
	Vengono verificate alcune proprieta' della trasformata
	discreta di Fourier.

RISPFREQ II ORD
	Si mostra la risposta in amp. e fase di un sistema del
	II ordine e del suo reciproco.

STIME SPETTRALI
	Sono rappresentate le stime spettrali di una sequenza
	generata dalla somma di 3 sequenze sinusoidali adottando
	il metodo di Welch con una finestra di Hamming.



	                     NOTA FINALE

	In aggiunta alle istruzioni precedenti, per maggiori 
	dettagli su ciascun programma e' possibile visualizzare
	e/o stampare il listato dei programmi contenuto nei
	file .m di ciascun esercizio
