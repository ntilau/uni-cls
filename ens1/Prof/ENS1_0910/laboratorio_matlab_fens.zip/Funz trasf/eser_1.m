function [titolo,testo,tvec,vvec]=eser_1(val_vec)
%
%	Funzione ESER_1( <vettore parametri> )
%		
%	in questa funzione viene definito l'esercizio
%	da visualizzare.
%
%	titolo - - - -  e' una stringa che descrive brevemente
%			il contenuto del grafico mostrato.
%
%	testo  - - - -  e' una matrice di stringhe (costruita con la
%			funzione STR2MAT) che descrive in modo piu'
%			dettagliato il contenuto dell'esercizio.
%
%	tvec - - - - -  e' la matrice contenente le etichette dei campi edit 
%			associati ai parametri,descrive il significato di
%			ogni parametro.
%
%	vvec - - - - -  e' la matrice contenente i valori dei campi edit 
%			associati ai parametri.
%

hndl_v = get(gcf,'UserData');
assi_1 = hndl_v(13);
assi_2 = hndl_v(14);

%#########################################################################
%####################  INIZIO PARTE DA MODIFICARE ########################
%#########################################################################

	tvec = str2mat('polo 1 =',...
		'',...
		' ',...
		' ',...
		' ');

	titolo = 'Anti-trasformata Z';

	
if nargin~=1;
	vvec=str2mat('0.8',' ',' ',' ',' ');
else
	vvec = val_vec;
end;

z=[0];
k=1;
p=str2num(vvec(1,:));
[b,a] = zp2tf(z,p,k);

testo = str2mat( ' ',...
		 '             1', ...
                 'H(z)=  ____________', ...
                 '                -1', ...
	 sprintf('        1 %+3.1f z',a(2)));

[y,x]=dimpulse(b,a);
subplot(assi_1), stem(y),xlabel('Campioni'),ylabel('Antitrasformata');
subplot(assi_2), zplane(b,a);


%#########################################################################
%####################   FINE  PARTE DA MODIFICARE ########################
%#########################################################################
return;
