function [titolo,testo,tvec,vvec]=eser_7(val_vec)
%
%	Funzione ESER_7( <vettore parametri> )
%		
%	in questa funzione viene definito l'esercizio
%	da visualizzare.
%
%	titolo - - - -  e' una stringa che descrive brevemente
%			il contenuto del grafico mostrato.
%
%	testo  - - - -  e' una matrice di stringhe (costruita con la
%			funzione STR2MAT) che descrive in modo piu'
%			dettagliato il contenuto dell'esercizio.
%
%	tvec - - - - -  e' la matrice contenente le etichette dei campi edit 
%			associati ai parametri,descrive il significato di
%			ogni parametro.
%
%	vvec - - - - -  e' la matrice contenente i valori dei campi edit 
%			associati ai parametri.
%

hndl_v = get(gcf,'UserData');
assi_1 = hndl_v(13);
assi_2 = hndl_v(14);

%#########################################################################
%####################  INIZIO PARTE DA MODIFICARE ########################
%#########################################################################

	tvec = str2mat(' ',...
		' ',...
		' ',...
		' ',...
		' ');

	titolo = 'Convoluzione di Sequenze';

	testo = str2mat(...
	 'Questo esercizio mostra l''effetto della convoluzione.',...
 	 ' ', ...
         'La sequenza mostrata nella parte inferiore e'' il', ...
         'risultato della convoluzione  tra le due sequenze', ...
 	 'mostrate nella parte superiore.');


	
if nargin~=1;
	vvec=str2mat(' ',' ',' ',' ',' ');
else
	vvec = val_vec;
end;

s1=[5 4 3 2 1 0 -1 -2 -3 -4 ];
t=0:pi/5:2*pi;
s2=2*(2-cos(t));

t1=1:10;
t2=15:25;
c=conv(s1,s2);

subplot(assi_1), stem(t1,s1),hold on, stem(t2,s2),hold off,
	axis([0 26 -6 6]),axis('off'),text(0,-2,'Seq. 1'),
	text(15,-2,'Seq. 2');
subplot(assi_2), stem(c),axis('off'),text(0,-30,'Convoluzione');


%#########################################################################
%####################   FINE  PARTE DA MODIFICARE ########################
%#########################################################################
return;
