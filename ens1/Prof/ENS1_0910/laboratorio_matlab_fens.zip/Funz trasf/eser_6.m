function [titolo,testo,tvec,vvec]=eser_6(val_vec)
%
%	Funzione ESER_6( <vettore parametri> )
%		
%	in questa funzione viene definito l'esercizio
%	da visualizzare.
%
%	titolo - - - -  e' una stringa che descrive brevemente
%			il contenuto del grafico mostrato.
%
%	testo  - - - -  e' una matrice di stringhe (costruita con la
%			funzione STR2MAT) che descrive in modo piu'
%			dettagliato il contenuto dell'esercizio.
%
%	tvec - - - - -  e' la matrice contenente le etichette dei campi edit 
%			associati ai parametri,descrive il significato di
%			ogni parametro.
%
%	vvec - - - - -  e' la matrice contenente i valori dei campi edit 
%			associati ai parametri.
%

hndl_v = get(gcf,'UserData');
assi_1 = hndl_v(13);
assi_2 = hndl_v(14);

%#########################################################################
%####################  INIZIO PARTE DA MODIFICARE ########################
%#########################################################################

		tvec = str2mat('polo 1 =',...
		'polo 2 =',...
		'polo 3 =',...
		'zero 1 =',...
		'zero 2 =');

	titolo = 'Risposta in Frequenza';

	
if nargin~=1;
	vvec=str2mat('-0.9+0.2i','-0.9-0.2i','0.5','0.8','0.2');
else
	vvec = val_vec;
end;

z=[str2num(vvec(4,:)); str2num(vvec(5,:)); 0 ];
p=[str2num(vvec(1,:)); str2num(vvec(2,:)); str2num(vvec(3,:)) ];
k=1;
[b,a] = zp2tf(z,p,k);

testo = str2mat(...
         '                    -1      -2', ...
 sprintf('         %3.1f  %+3.1f z  %+3.1f z',b(1),b(2),b(3)),...
         'H(z)=   ______________________________ ', ...
         '                    -1      -2      -3', ...
 sprintf('         %3.1f  %+3.1f z  %+3.1f z  %+3.1f z',a(1),a(2),a(3),a(4)) );

[h,w] = freqz(b,a);
hmax=max(abs(h));
subplot(assi_1), zplane(z,p);
subplot(assi_2),
 plot(w/(2*pi),abs(h)/hmax,'m-',w/(2*pi),angle(h)/pi,'g:'),
 ylabel('Amp. e Fase'),xlabel('F freq. normalizzata'),axis([0 0.5 -1 1]);
 h1=text(0.01,-0.8,'Amp.');
 h2=text(0.01,-0.5,'Fase');
 set(h1,'Color',[1 0 1]);
 set(h2,'Color',[0 1 0]);


%#########################################################################
%####################   FINE  PARTE DA MODIFICARE ########################
%#########################################################################
return;
