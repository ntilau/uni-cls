function [titolo,testo,tvec,vvec]=eser_1(val_vec)
%
%	Funzione ESER_n( <vettore parametri> )
%		
%	in questa funzione viene definito l'esercizio
%	da visualizzare.
%
%	titolo - - - -  e' una stringa che descrive brevemente
%			il contenuto del grafico mostrato.
%
%	testo  - - - -  e' una matrice di stringhe (costruita con la
%			funzione STR2MAT) che descrive in modo piu'
%			dettagliato il contenuto dell'esercizio.
%
%	tvec - - - - -  e' la matrice contenente le etichette dei campi edit 
%			associati ai parametri,descrive il significato di
%			ogni parametro.
%
%	vvec - - - - -  e' la matrice contenente i valori dei campi edit 
%			associati ai parametri.
%

hndl_v = get(gcf,'UserData');
assi_1 = hndl_v(13);
assi_2 = hndl_v(14);

%#########################################################################
%####################  INIZIO PARTE DA MODIFICARE ########################
%#########################################################################

	tvec = str2mat(' ',...
		' ',...
		' ',...
		' ',...
		' ');

	titolo = 'Confronto FFT <-> DFT';

	testo = str2mat(...
	 'Nei grafici sono riportati i risultati del confronto',...
	 'tra DFT e FFT per una sequenza di 4096 campioni.', ...
         'Il confronto riguarda i tempi di elaborazione.', ...
 	 ' ');


	
if nargin~=1;
	vvec=str2mat(' ',' ',' ',' ',' ');
else
	vvec = val_vec;
end;

t=0:pi/4096:pi;
s2=cos(3*t)+sin(50*t)+cos(123*t);
N=length(s2);
s1=s2(2:N);

tic;
f1=fft(s1);
t1=toc;

tic;
f2=fft(s2);
t2=toc;

pt1x=[0 t1 t1 0];
pt1y=[1 1 2 2];

pt2x=[0 t2 t2 0];
pt2y=[2.5 2.5 3.5 3.5];


subplot(assi_1),fill(pt1x,pt1y,'r',pt2x,pt2y,'g'),axis('auto'),
	axis('off'),text(t1,1.5,' FFT'),text(t2,3,' DFT');
	title('Tempo di CPU');

    
%#########################################################################
%####################   FINE  PARTE DA MODIFICARE ########################
%#########################################################################
return;
