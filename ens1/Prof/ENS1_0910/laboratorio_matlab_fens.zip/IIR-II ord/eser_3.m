function [titolo,testo,tvec,vvec]=eser_3(val_vec)
%
%	Funzione ESER_n( <vettore parametri> )
%		
%	in questa funzione viene definito l'esercizio
%	da visualizzare.
%
%	titolo - - - -  e' una stringa che descrive brevemente
%			il contenuto del grafico mostrato.
%
%	testo  - - - -  e' una matrice di stringhe (costruita con la
%			funzione STR2MAT) che descrive in modo piu'
%			dettagliato il contenuto dell'esercizio.
%
%	tvec - - - - -  e' la matrice contenente le etichette dei campi edit 
%			associati ai parametri,descrive il significato di
%			ogni parametro.
%
%	vvec - - - - -  e' la matrice contenente i valori dei campi edit 
%			associati ai parametri.
%

hndl_v = get(gcf,'UserData');
assi_1 = hndl_v(13);
assi_2 = hndl_v(14);

%#########################################################################
%####################  INIZIO PARTE DA MODIFICARE ########################
%#########################################################################

		tvec = str2mat('amp.p =',...
		'fase.p =',...
		'amp.z =',...
		'fase.z =',...
		' ');

	titolo = 'Filtri IIR - II ordine - 2 zeri';

	testo = str2mat(...
	         'Viene visualizzata la risposta in frequenza di un IIR', ...
	 	 'del II Ordine insieme alla rappr. dei suoi zeri e poli.',...
		 '',...
	         'Per ciascuna coppia di poli (o zeri) si definiscono', ...
	         'ampiezza e fase (normalizzata a PI) di solo uno di essi');

	
if nargin~=1;
	vvec=str2mat('0.85','0.25','0.85','0.75',' ');
	return;
else
	vvec = val_vec;
end;

ap=str2num(val_vec(1,:));
fp=str2num(val_vec(2,:))*pi;
az=str2num(val_vec(3,:));
fz=str2num(val_vec(4,:))*pi;

z=[az*exp(i*fz); az*exp(-i*fz)];
p=[ap*exp(i*fp); ap*exp(-i*fp)];
k=1;
[b,a] = zp2tf(z,p,k);

[h,w] = freqz(b,a);
hmax=max(abs(h));
subplot(assi_1), zplane(z,p);
subplot(assi_2),
 plot(w/(2*pi),abs(h)/hmax,'m-',w/(2*pi),angle(h)/pi,'g:'),
 ylabel('Amp. e Fase'),xlabel('F freq. normalizzata'),axis([0 0.5 -1 1]);
 h1=text(0.01,-0.8,'Amp.');
 h2=text(0.01,-0.5,'Fase');
 set(h1,'Color',[1 0 1]);
 set(h2,'Color',[0 1 0]);


%#########################################################################
%####################   FINE  PARTE DA MODIFICARE ########################
%#########################################################################
return;
