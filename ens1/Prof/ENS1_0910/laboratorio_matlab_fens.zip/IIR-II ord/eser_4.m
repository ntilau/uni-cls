function [titolo,testo,tvec,vvec]=eser_4(val_vec)
%
%	Funzione ESER_n( <vettore parametri> )
%		
%	in questa funzione viene definito l'esercizio
%	da visualizzare.
%
%	titolo - - - -  e' una stringa che descrive brevemente
%			il contenuto del grafico mostrato.
%
%	testo  - - - -  e' una matrice di stringhe (costruita con la
%			funzione STR2MAT) che descrive in modo piu'
%			dettagliato il contenuto dell'esercizio.
%
%	tvec - - - - -  e' la matrice contenente le etichette dei campi edit 
%			associati ai parametri,descrive il significato di
%			ogni parametro.
%
%	vvec - - - - -  e' la matrice contenente i valori dei campi edit 
%			associati ai parametri.
%

hndl_v = get(gcf,'UserData');
assi_1 = hndl_v(13);
assi_2 = hndl_v(14);

%#########################################################################
%####################  INIZIO PARTE DA MODIFICARE ########################
%#########################################################################

		tvec = str2mat('amp.p =',...
		'fase.p =',...
		' ',...
		' ',...
		' ');

	titolo = 'Filtro Passa-Tutto';

	testo = str2mat(...
	         'Viene visualizzata la risposta in frequenza di un', ...
	 	 'filtro Passa-Tutto del II ordine.',...
		 'Per la coppia di poli si definiscono', ...
	         'ampiezza e fase (normalizzata a PI) di solo uno di essi',...
		 'Gli zeri sono definiti come il reciproco dei poli');

	
if nargin~=1;
	vvec=str2mat('0.85','0.25',' ',' ',' ');
	return;
else
	vvec = val_vec;
end;

ap=str2num(val_vec(1,:));
fp=str2num(val_vec(2,:))*pi;

z=[1/ap*exp(i*fp); 1/ap*exp(-i*fp)];
p=[ap*exp(i*fp); ap*exp(-i*fp)];
k=1;
[b,a] = zp2tf(z,p,k);

[h,w] = freqz(b,a);
hmax=max(abs(h));
subplot(assi_1), zplane(z,p);
subplot(assi_2),
 plot(w/(2*pi),abs(h)/hmax,'m-',w/(2*pi),angle(h)/pi,'g:'),
 ylabel('Amp. e Fase'),xlabel('F freq. normalizzata'),axis([0 0.5 -1 1]);
 h1=text(0.01,-0.8,'Amp.');
 h2=text(0.01,-0.5,'Fase');
 set(h1,'Color',[1 0 1]);
 set(h2,'Color',[0 1 0]);


%#########################################################################
%####################   FINE  PARTE DA MODIFICARE ########################
%#########################################################################
return;
