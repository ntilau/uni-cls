function panel(action);
%------------------------------------------------
%
% PANEL.M V.1.1
% interfaccia principale del corso di elaborazione
% digitale dei segnali.
%
%------------------------------------------------
global curr_exer;
if nargin<1,
    action='initialize';
end;

bordo_oggetti=0.01;
bordo_assi=0.07; %fu 0.05
assi_est=0.8;
assi_ovest=0;
assi_nord=1;
assi_sud=0.25;
assi_mid=(assi_nord - assi_sud)/2 + assi_sud;

pos_assi1=[bordo_assi+assi_ovest assi_mid+bordo_assi ...
	(assi_est-assi_ovest)-2*bordo_assi ...
	(assi_nord-assi_mid)-2*bordo_assi];

pos_assi2=[bordo_assi+assi_ovest assi_sud+bordo_assi ...
	(assi_est-assi_ovest)-2*bordo_assi ...
	(assi_mid-assi_sud)-2*bordo_assi];


if strcmp(action,'initialize'),
    curr_exer=0;
    figNumber=figure( ...
        'Name','Corso di Elaborazione Numerica dei Segnali', ...
        'NumberTitle','off', ...
	'Visible','off');

    assi1_handle=axes( ...
	'Units','normalized', ...
        'Position',pos_assi1);

    assi2_handle=axes( ...
	'Units','normalized', ...
        'Position',pos_assi2);

    %===================================
    % Set up the MiniCommand Window

    top=assi_sud;
    left=assi_ovest;
    right=assi_est;
    bottom=0;
    labelHt=0.04;
    spacing=0.005;

    %====================================
    % First, the MiniCommand Window frame

    frmBorder=0.005;
    frmPos=[left+bordo_oggetti bottom+bordo_oggetti ...
	(right-left)-2*bordo_oggetti (top-bottom)-2*bordo_oggetti];
    uicontrol( ...
        'Style','frame', ...
        'Units','normalized', ...
        'Position',frmPos, ...
	'BackgroundColor',[0.50 0.50 0.50]);

    %====================================
    % Then the title

    labelPos=[left+bordo_oggetti+frmBorder ...
	top-labelHt-frmBorder-bordo_oggetti...
	(right-left)-2*frmBorder-2*bordo_oggetti ...
	labelHt ];
    title_handle=uicontrol( ...
	'Style','text', ...
        'Units','normalized', ...
        'Position',labelPos, ...
        'BackgroundColor',[1 1 1], ...
	'ForegroundColor',[0 0 0], ...
        'String','Nessun esercizio attivo');

    textPos=[left+bordo_oggetti+frmBorder ...
	0+frmBorder+bordo_oggetti ...
	(right-left)-2*frmBorder-2*bordo_oggetti ...
	(top-bottom)-2*bordo_oggetti-2*frmBorder-2*labelHt ];
    text_handle=uicontrol( ...
	'Style','edit', ...
        'Units','normalized', ...
        'Position',textPos, ...
        'BackgroundColor',[0.5 0.5 0.5], ...
	'ForegroundColor',[1 1 1], ...
	'Max',10, ...
	'String','Prova di testo');


    %====================================    
    % Information for all buttons

    labelColor=[0.8 0.8 0.8];
    frame_est=1;
    frame_ovest=assi_est;
    frame_nord=assi_nord;
    frame_sud=0;
    top=frame_nord-2*bordo_oggetti;
    bott_ovest=(1-assi_est)*0.125+assi_est;
    btnWid=(1-assi_est)*0.75;
    btnHt=btnWid*0.40;

    % Spacing between the button and the next command's label
    spacing=0.03;

    %====================================
    % The CONSOLE frame

    frmBorder=btnWid/0.75*0.25;
    ypos=0;
    frmPos=[frame_ovest+bordo_oggetti frame_sud+bordo_oggetti ...
	(frame_est-frame_ovest)-2*bordo_oggetti ...
	(frame_nord-frame_sud)-2*bordo_oggetti ];
    uicontrol( ...
        'Style','frame', ...
        'Units','normalized', ...
        'Position',frmPos, ...
	'BackgroundColor',[0.50 0.50 0.50]);

    %====================================
    % bottone PROSSIMO

    btnNumber=1;
    yPos=top-(btnNumber-1)*(btnHt+spacing);
    labelStr='Successivo';
    callbackStr='panel(''prossimo'')';


    % Generic popup button information
    btnPos=[bott_ovest yPos-btnHt btnWid btnHt];
    uicontrol( ...
	'Style','pushbutton', ...
        'Units','normalized', ...
        'Position',btnPos, ...
        'String',labelStr, ...
        'Callback',callbackStr);

    %====================================
    % bottone PRECEDENTE

    btnNumber=2;
    yPos=top-(btnNumber-1)*(btnHt+spacing);
    labelStr='Precedente';
    callbackStr='panel(''precedente'')';
    
    % Generic popup button information
    btnPos=[bott_ovest yPos-btnHt btnWid btnHt];
    uicontrol( ...
	'Style','pushbutton', ...
        'Units','normalized', ...
        'Position',btnPos, ...
        'String',labelStr, ...
        'Callback',callbackStr);

    %====================================
    % slider PARAM_1

    btnNumber=4;
    yPos=top-(btnNumber-1)*(btnHt+spacing);
    labelStr='Param 1';
    callbackStr='panel(''param1'')';

    % Generic slider information
    btnPos=[bott_ovest yPos-btnHt btnWid btnHt];
    par1_handle = uicontrol( ...
	'Style','slider', ...
        'Units','normalized', ...
        'Position',btnPos, ...
        'String',labelStr, ...
        'Callback',callbackStr, ...
	'Max',0.5,...
	'Min',-0.5, ...
	'Value',0);

%====================================
% testo PARAM_1

    btnNumber=5;
    yPos=top-(btnNumber-1)*(btnHt+spacing);
    labelStr='Parametro 1';

    % Generic text information
    btnPos=[bott_ovest yPos-btnHt btnWid btnHt];
    tpar1_handle = uicontrol( ...
	'Style','text', ...
        'Units','normalized', ...
        'Position',btnPos, ...
        'String',labelStr);


%===========================================
%	slider PARAM_2

    btnNumber=6;
    yPos=top-(btnNumber-1)*(btnHt+spacing);
    labelStr='Param 1';
    callbackStr='panel(''param2'')';

    % Generic slider information
    btnPos=[bott_ovest yPos-btnHt btnWid btnHt];
    par2_handle = uicontrol( ...
	'Style','slider', ...
        'Units','normalized', ...
        'Position',btnPos, ...
        'String',labelStr, ...
        'Callback',callbackStr, ...
	'Max',0.5,...
	'Min',-0.5, ...
	'Value',0);

%====================================
% testo PARAM_2

    btnNumber=7;
    yPos=top-(btnNumber-1)*(btnHt+spacing);
    labelStr='Parametro 2';
 
    % Generic popup button information
    btnPos=[bott_ovest yPos-btnHt btnWid btnHt];
    tpar2_handle = uicontrol( ...
	'Style','text', ...
        'Units','normalized', ...
        'Position',btnPos, ...
        'String',labelStr);

    %====================================
    % The CLOSE button

    uicontrol( ...
	'Style','push', ...
        'Units','normalized', ...
       'Position',[bott_ovest bottom+2*bordo_oggetti btnWid btnHt], ...
        'String','Esci', ...
        'Callback','close(gcf)');

    %=====================================
    % Now uncover the figure
    % and save important handles

    handle_vec = [title_handle text_handle ...
	par1_handle tpar1_handle ...
	par2_handle tpar2_handle ...
	assi1_handle assi2_handle ];
    set(figNumber,'UserData',handle_vec);
    set(figNumber,'Visible','on');


elseif strcmp(action,'prossimo'),

	handle_vec = get(gcf,'UserData');
	esStr=['eser_' int2str(curr_exer+1)];
	if exist(esStr) == 2,
		curr_exer=curr_exer+1;
		set(handle_vec(3),'Value',0);
		set(handle_vec(5),'Value',0);
		[title,text,tpar1,tpar2] = feval(esStr,0,0);
		set(handle_vec(1),'String',title);
		set(handle_vec(2),'String',text);
		set(handle_vec(4),'String',tpar1);
		set(handle_vec(6),'String',tpar2);
	end;

elseif strcmp(action,'precedente'),

	handle_vec = get(gcf,'UserData');
	esStr=['eser_' int2str(curr_exer-1)];
	if exist(esStr) == 2,
		curr_exer=curr_exer-1;
		set(handle_vec(3),'Value',0);
		set(handle_vec(5),'Value',0);
		[title,text,tpar1,tpar2] = feval(esStr,0,0);
		set(handle_vec(1),'String',title);
		set(handle_vec(2),'String',text);
		set(handle_vec(4),'String',tpar1);
		set(handle_vec(6),'String',tpar2);
	end;

elseif strcmp(action,'param1'),

	handle_vec = get(gcf,'UserData');
	val1=get(handle_vec(3),'Value');
	val2=get(handle_vec(5),'Value');
	esStr=['eser_' int2str(curr_exer)];
	feval(esStr,val1,val2);

elseif strcmp(action,'param2'),

	handle_vec = get(gcf,'UserData');
	val1=get(handle_vec(3),'Value');
	val2=get(handle_vec(5),'Value');
	esStr=['eser_' int2str(curr_exer)];
	feval(esStr,val1,val2);
		
end;
    % if strcmp(action, ...

