function [titolo,testo,label_par1,label_par2]=eser_2(val1,val2)
%
%	Funzione ESER_2( <parametro 1>, <parametro 2>)
%		
%	in questa funzione viene definito l'esercizio
%	da visualizzare.
%
%	titolo - - - -  e' una stringa che descrive brevemente
%			il contenuto del grafico mostrato.
%
%	testo  - - - -  e' una matrice di stringhe (costruita con la
%			funzione STR2MAT) che descrive in modo piu'
%			dettagliato il contenuto dell'esercizio.
%
%	label_par1 - -  e' l'etichetta del cursore associato al parametro 1
%			descrive il significato del parametro ed, eventualmente
%			i valori minimo e massimo.
%
%	label_par2 - -  idem come sopra per il parametro 2
%

hndl_v = get(gcf,'UserData');
assi_1 = hndl_v(7);
assi_2 = hndl_v(8);

%#########################################################################
%####################  INIZIO PARTE DA MODIFICARE ########################
%#########################################################################

titolo = 'Inversione spettrale per segnali numerici';

testo = str2mat( 'Questo esercizio mostra l''effetto della', ...
	         'inversione di segno dei campioni dispari', ...
                 'in un segnale numerico.');


label_par1 = 'On Off On';

label_par2= ' ';

fattore=(abs(val1)>0.25)*(-2)+1;	% fattore=-1, 0, -1

nc=256;

sp=zeros(1,nc);

for i = 1:nc,
	sp(i)=( max([(192-i) 0]))/191;
end

spettro=[fliplr(sp) sp];

segnale=real(ifft(spettro));

for i = 1:2*nc,
	segnale(i)=segnale(i)*(fattore)^i;
end

if fattore == -1
	valstr=sprintf('     Spettro di ampiezza (inversione)');
else
	valstr=sprintf('     Spettro di ampiezza             ');
end

subplot(assi_1),stem(segnale(nc-24:nc+25)),title('Segnale'),axis('off');
subplot(assi_2),dfplot(segnale),title(valstr);


%#########################################################################
%####################   FINE  PARTE DA MODIFICARE ########################
%#########################################################################
return;
