function [titolo,testo,label_par1,label_par2]=eser_1(val1,val2)
%
%	Funzione ESER_1( <parametro 1>, <parametro 2>)
%		
%	in questa funzione viene definito l'esercizio
%	da visualizzare.
%
%	titolo - - - -  e' una stringa che descrive brevemente
%			il contenuto del grafico mostrato.
%
%	testo  - - - -  e' una matrice di stringhe (costruita con la
%			funzione STR2MAT) che descrive in modo piu'
%			dettagliato il contenuto dell'esercizio.
%
%	label_par1 - -  e' l'etichetta del cursore associato al parametro 1
%			descrive il significato del parametro ed, eventualmente
%			i valori minimo e massimo.
%
%	label_par2 - -  idem come sopra per il parametro 2
%

hndl_v = get(gcf,'UserData');
assi_1 = hndl_v(7);
assi_2 = hndl_v(8);

%#########################################################################
%####################  INIZIO PARTE DA MODIFICARE ########################
%#########################################################################

titolo = 'Fenomeno dell''aliasing di una sinusoide';

testo = str2mat( 'Questo esercizio mostra l''aliasing di una sinusoide', ...
	         'se la frequenza della sinusoide supera il valore', ...
                 'di 1/2 fc (fc=frequenza di campionamento)');


label_par1 = 'f1';

label_par2= 'fc';

f1=3e3 + val1*4e3;	% f1 = 1000..5000
fc=1e4 + val2*4e3;	% fc = 8000..10000..12000

dt=1/10e3;        
tc=1/fc;
nc=200;

tt=0:tc:nc*dt;
t=0:dt/5:nc*dt/5;
yc=sin(2*pi*f1*tt);
yy=sin(2*pi*f1*t);

df=fc/200;
ff=-fc/2:df:fc/2;
aa=zeros(size(ff));
index0 = floor(f1/fc*200 + 100);
index1 = rem(index0,200)+1;
aa(index1)=1;
aa(201-index1)=1;


valstr=sprintf('f1 = %5.0f, fc = %6.0f', f1, fc);
subplot(assi_1),plot(t*1e3,yy),hold on,stem(tt(1:20)*1e3,yc(1:20)),
	axis([0 20e3*tc -1.2 1.2]),hold off;
subplot(assi_2),plot(ff,aa,'-'),axis([-fc/2 fc/2 0 1.1]),title(valstr);


%#########################################################################
%####################   FINE  PARTE DA MODIFICARE ########################
%#########################################################################
return;
