function dfplot( xa )
%DFPLOT
%	dfplot( xa )
%
%	xa:  il segnale digitale
%	
%
L=length(xa);
Nfft=round(2 .^ round(log2(L)));
Xa=fft(xa,Nfft);
range=0:(Nfft/2);
lr=length(range);
ff=range/Nfft;
ff2=[-1.*fliplr(ff) ff];
Xa2=[fliplr(Xa) Xa];
plot(ff2,abs(Xa2(1:length(ff2))  ));
title('TRASFORMATA DISCRETA DI FOURIER (AMP)');
xlabel('F/Fc'), grid;