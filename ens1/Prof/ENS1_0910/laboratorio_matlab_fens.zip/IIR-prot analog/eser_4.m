function [titolo,testo,tvec,vvec]=eser_4(val_vec)
%
%	Funzione ESER_n( <vettore parametri> )
%		
%	in questa funzione viene definito l'esercizio
%	da visualizzare.
%
%	titolo - - - -  e' una stringa che descrive brevemente
%			il contenuto del grafico mostrato.
%
%	testo  - - - -  e' una matrice di stringhe (costruita con la
%			funzione STR2MAT) che descrive in modo piu'
%			dettagliato il contenuto dell'esercizio.
%
%	tvec - - - - -  e' la matrice contenente le etichette dei campi edit 
%			associati ai parametri,descrive il significato di
%			ogni parametro.
%
%	vvec - - - - -  e' la matrice contenente i valori dei campi edit 
%			associati ai parametri.
%

hndl_v = get(gcf,'UserData');
assi_1 = hndl_v(13);
assi_2 = hndl_v(14);

%#########################################################################
%####################  INIZIO PARTE DA MODIFICARE ########################
%#########################################################################

	tvec = str2mat('Ord. =',...
		'F1 =',...
		'F2 =',...
		' ',...
		' ');

	titolo = 'IIR passa banda - Butterworth, Chebyshev (I e II), Ellittico';

	testo = str2mat(...
	 'Specifiche di progetto:',...
 	 'Butterworth  -> -', ...
         'Chebyshev  I -> 0.5 dB ripple in banda', ...
         'Chebyshev II -> 50 dB attenuazione', ...
 	 'Ellittici    -> 0.5 dB ripple, 50 db attenuazione');


	
if nargin~=1;
	vvec=str2mat('7','0.15','0.35',' ',' ');
	return;
else
	vvec = val_vec;
end;

N=str2num(val_vec(1,:));
Wt1=str2num(val_vec(2,:))*2;
Wt2=str2num(val_vec(3,:))*2;

[bbut,abut]=butter(N,[Wt1 Wt2]);
[bche1,ache1]=cheby1(N,0.5,[Wt1 Wt2]);
[bche2,ache2]=cheby2(N,50,[Wt1 Wt2]);
[belli,aelli]=ellip(N,0.5,50,[Wt1 Wt2]);

[hb,wb]=freqz(bbut,abut);
[h1,w1]=freqz(bche1,ache1);
[h2,w2]=freqz(bche2,ache2);
[he,we]=freqz(belli,aelli);


x=[0 Wt1/2 Wt1/2 Wt2/2 Wt2/2 1];
y=[0 0 1 1 0 0];
hmax=0;
hmin2=min(20*log10(abs(h2)));
hmine=min(20*log10(abs(he)));
hmin=min([hmin2; hmine]);
dh=hmax-hmin;
subplot(assi_1),
 plot(  wb/(2*pi),20*log10(abs(hb)),'g-',...
	w1/(2*pi),20*log10(abs(h1)),'m-',...
	w2/(2*pi),20*log10(abs(h2)),'c-',...
	we/(2*pi),20*log10(abs(he)),'r-'),
	ylabel('Ampiezza (dB)'),
	xlabel('F freq. normalizzata'),
	axis([0 0.5 hmin hmax]);
 	h1=text(0.01,0.25*dh+hmin,'Butterworth');
 	h2=text(0.01,0.2*dh+hmin,'Chebyshev I');
 	h3=text(0.01,0.15*dh+hmin,'Chebyshev II');
	h4=text(0.01,0.1*dh+hmin,'Ellittici');
 	set(h1,'Color',[0 1 0]);
 	set(h2,'Color',[1 0 1]);
 	set(h3,'Color',[0 1 1]);
 	set(h4,'Color',[1 0 0]);
	title('Filtro PASSA BANDA');

%#########################################################################
%####################   FINE  PARTE DA MODIFICARE ########################
%#########################################################################
return;
