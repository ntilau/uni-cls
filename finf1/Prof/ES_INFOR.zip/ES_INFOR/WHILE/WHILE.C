#include <stdio.h>

main()
{
int somma, numero, max, i;
clrscr();
printf("SOMMA E MASSIMO\n");
printf("zero per finire\n\n");
numero=1;
somma=0;
max=0;

i=1;
while(numero!=0 && i<=10)
{
printf("Valore int.: \t");
scanf("%d", &numero);
if (numero>max)
  max=numero;
somma+=numero;
i++;
}

printf("Somma: %d\n", somma);
printf("Maggiore: %d\n", max);
getch();
}