#include <stdio.h>
main()
{
int x;
clrscr();
printf ("numero\t quadrato\t cubo\n", x, x*x, x*x*x);

for (x=0; x<11; x++)
{
printf ("%d\t %d\t\t %d\n", x, x*x, x*x*x);
}
getch();

}