 #include <stdio.h>
main()
{
int x, y, num;
clrscr();
printf("Digitare un numero di 5 cifre\n");
scanf("%d", &num);
for (x=10000; x>0; x/=10)
{
 y=num/x;
 num=num-y*x;
 printf ("%d ", y);
}
getch();
}
