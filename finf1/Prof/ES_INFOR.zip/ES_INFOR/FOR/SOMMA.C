#include <stdio.h>

int i, max;
float somma, numero;
main()
{
clrscr();
printf ("\nSOMMA DI NUMERI\n");
printf("\nQuanti numeri si vuole sommare? ");
scanf ("%d", &max);
printf ("\nSomma di %d numeri", max);
somma=0;

for (i=1; i<=max; i++)
{
  printf("\nInser. %d� float: ",i);
  scanf ("%f", &numero);
  somma += numero;
}

printf ("\nLa somma delle %d cifre inserite �: %8.3f\n", max, somma);
getch();
}
