#include <stdio.h>

int i;
// float i;
// double i;

int mag_100;
int min_100;

main()
{
mag_100=0;
min_100=0;
clrscr();

printf ("Digitare un numero:\n");
//printf ("Digitare un numero (anche con virgola):\n");

scanf ("%d", &i);      /* con int    */
//scanf ("%f", &i);    /* con float  */
//scanf ("%lf", &i);   /* con double */

if (i<100)
{
printf ("\n minore di 100");
min_100 = 1;
}
else
{
printf ("\n maggiore o uguale a 100");
mag_100=1;
}
getch();
}
