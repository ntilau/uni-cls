#include <stdio.h>
#include <math.h>

main()
{
float a, b, segmento, lunghezza;
int lunghint;
clrscr();
printf ("\n\nLUNGHEZZA SEGMENTO \n");
printf ("Primo estremo: ");
scanf ("%f", &a);
printf ("Secondo estremo: ");
scanf ("%f", &b);

segmento = a-b;
lunghezza = fabs(segmento);

printf ("Lunghezza segmento: %f\nLunghezza appross.: %d", lunghezza, abs(lunghezza));
getch();
}
