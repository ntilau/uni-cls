#include <stdio.h>
#include <math.h>

main()
{
int a, b, segmento, lunghezza;
clrscr();
printf ("\n\nLUNGHEZZA SEGMENTO \n");
printf ("Primo estremo: ");
scanf ("%d", &a);
printf ("Secondo estremo: ");
scanf ("%d", &b);

segmento = a-b;
lunghezza = abs(segmento);

printf ("Lunghezza segmento: %d", lunghezza);
getch();
}
