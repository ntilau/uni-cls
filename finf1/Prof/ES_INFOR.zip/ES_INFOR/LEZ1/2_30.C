#include <stdio.h>
main()
{
int x, y, z, num;
clrscr();
printf("Digitare un numero di 5 cifre\n");
scanf("%d", &num);
z=10000;
 y=num/z;
 num=num-y*z;
 z/=10;
 printf ("%d ", y);

 y=num/z;
 num=num-y*z;
 z/=10;
 printf ("%d ", y);

 y=num/z;
 num=num-y*z;
 z/=10;
 printf ("%d ", y);

 y=num/z;
 num=num-y*z;
 z/=10;
 printf ("%d ", y);

 y=num/z;
 num=num-y*z;
 z/=10;
 printf ("%d ", y);

getch();
}
