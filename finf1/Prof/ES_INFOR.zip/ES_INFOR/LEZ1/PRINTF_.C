#include <stdio.h>
main()
{
clrscr();
printf("%9.3f\n", 12345.34);
printf("%9.3f", 56.11);
}