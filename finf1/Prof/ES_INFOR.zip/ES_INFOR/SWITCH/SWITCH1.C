#include <stdio.h>

char x;

main()
{
clrscr();
printf("\n Inserisci una cifra: ");
scanf("%c", &x);

switch(x)
 {
  case '2':
  case '4':
  case '6':
  case '8':
      printf("\n pari");
      break;
  case '1':
  case '3':
  case '5':
  case '7':
  case '9':
      printf("\n  dispari");
      break;
  default:
      printf ("\n altro");
 }
 getch();
}