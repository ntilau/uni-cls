#include <stdio.h>
#include <stdlib.h>

/**
 * Esercitazione del 26 maggio 2005
 * Leonardo Bocchi (leonardo.bocchi@asp.det.unifi.it)
 * http://asp.det.unifi.it/~leo
 *
 * Programma di esempio per funzioni e array, viene utilizzato per
 * mostrare le seguenti tecniche:
 *
 * -Passaggio di strutture alle funzioni
 * -Utilizzo di parametri di ingresso e di uscita alle funzioni
 * -Creazione e gestione dinamica di una lista
 * -Creazione di funzioni riutilizzabili
 *
 * */

/**
 * La nostra lista e' destinata a contenere valori interi. La
 * struttura che rappresenta un nodo della lista, deve quindi
 * contenere due elementi: un intero, che rappresenta il valore che
 * vogliamo memorizzare, e un puntatore all'elemento successivo della
 * lista. La convensione sui nome e' la stessa vista l'altra volta
 */
struct SNodo {
  int value;     // l'elemento da memorizzare
  struct SNodo * next; // puntatore al nodo successivo
};
 
// definiamo un tipo di variabile
typedef struct SNodo TNodo;

/**
 * Funzione pre inserire un nodo nella lista. Quando la lista e'
 * vuota, si crea una lista contenente un solo nodo. Per questo
 * motivo, la funzione restituisce al programma chiamante un puntatore
 * al nuovo inizio della lista. I due argomenti di ingresso sono,
 * rispettivamente, il puntatore al primo nodo della lista, e
 * l'elemento da inserire.
 */
TNodo * aggiungiLista(TNodo * inizio, int elemento)
{
  // variabile di lavoro
  TNodo * tmp;

  // la funzione si deve comportare diversamente se la lista e' vuota
  if (inizio == NULL) {
    // alloco lo spazio di memoria a contenere un nodo. sizeof(TNodo)
    // indica lo spazio di memoria necessario a contenere la
    // struttura. l'operatore di cast (TNodo *) serve per convertire
    // il puintatore void restituito dalla malloc nel puntatore
    // corretto.
    tmp = (TNodo *) malloc (sizeof(TNodo));

    // tmp ora contiene l'indirizzo del nuovo nodo. Posso riempirlo
    tmp->value = elemento;
    // e' importante marchiare il nodo come 'ultimo di lista',
    // settando a zero il puntatore al nodo successivo.
    tmp->next = NULL;

    // L'inizio della lista e' cambiato. Devo restituire il nuovo
    // indirizzo al programma chiamante.
    return tmp;

  } else {

    // La lsita contiene gia' dei nodi. l'elemento nuovo va aggiunto
    // alla fine. Parto a scandire la lista dei nodi, a partire dal primo
     tmp = inizio;

     // le due istruzioni seguenti rappresentano un modo per scorrere
     // tutta la lista, fino ad ottenere l''ultimo nodo valido. Il
     // ciclo si ferma quando il puntatore 'next' che indica il nodo
     // seguente e' vuoto. Il corpo del ciclo contiene l'istruzione
     // per spostare il puntatore tmp dal nodo corrente al nodo
     // successivo. Si potrebbe anche realizzare con un ciclo for:
     // for(tmp=inizio; tmp->next!=NULL; tmp=tmp->next) {}
     while (tmp->next != NULL) {
       tmp = tmp->next;
     }
     // Importante: qui il ciclo non e' utile solo per quello che
     //contiene, ma anche per lo stato in cui lascia le variabili. la
     //variabile di controllo, all'uscita del ciclo, contiene l'ultimo
     //nodo valido (quello per cui tmp->next e' nullo). Confrontare la
     //condizione di uscita qui con quella della funzione seguente. 

     // creo un nuovo nodo. A differenza di prima, non memorizzo
     // l'indirizzo direttamente nel nodo tmp (che e' valido), ma lo
     // aggancio alla lista come nodo successivo all'ultimo (lo
     // memorizzo in tmp->next)
     tmp->next = (TNodo *) malloc (sizeof(TNodo));

     // Ora in tmp->next ho un nodo valido. sposto il mio puntatore
     // sul nuovo nodo in modo da poterlo riempire
     tmp = tmp->next;

     /// tmp punta al nodo appena creato. Riempio il nodo (stesse
     /// istruzioni usate sopra)
     tmp->value = elemento;
     tmp->next = NULL;

     // in questo caso l'inizio della lista non e' variato. segnalo al
     // programma chiamante che il vecchi puntatore di inizio e'
     // ancora valido.
     return inizio;
  }
}

/** 
 * Funzione non ricorsiva per la stampa della lista. Ho un unico
 * argomento di ingresso, corrispondente all'inizio della lista.
 */  
void stampaLista(TNodo * inizio)
{
  // scorro tutta la lista finche' il puntatore al nodo corrente e'
  // valido.  data la forma della condizione di uscita, il ciclo
  // funziona correttamente anche con una lista vuota, non devo
  // gestire il caso particolare.
  while (inizio != NULL) {
    // se ho ancora un elemento, ne stampo il valore
    printf("Elemento della lista: %d\n", inizio->value);
    
    // mi sposto sull'elemento successivo
    inizio = inizio->next; 
  }
}

/**
 * Realizzo la stampa in modo ricorsivo. Utile per la gestione di
 * alberi, che non si prestano ad essere analizzati tramite un ciclo.
 */ 
void stampaRicorsivaLista(TNodo * inizio)
{
  // se non ho piu' nodi non devo fare niente
  if (inizio == NULL)
    return;
 
  // stampo l'elemento corrente
  printf("Elemento della lista: %d\n", inizio->value);

  // per stampare la lista composta dagli elementi successivi,
  // richiamo la funzione ricorsivamente.
  stampaRicorsivaLista(inizio->next);
}

/**
 * Funzione di ricerca. inizio e' la lista in cui cercare, elemento e'
 * l'elemento che sto cercando. Il valore di ritorno e' un int per
 * poter utilizzare la funzione copme condizione nell'if: se
 * l'elemento c'e' restituisco 1 (vero) altrimenti restituisco 0
 * (falso)
 */
int cercaLista(TNodo * inizio, int elemento)
{
  // le condizioni di controllo del ciclo sono le stesse della
  // funzione di stampa. quell oche cambia e' solo l'istruzione
  // all'interno del ciclo stesso.
  while (inizio) {
    if (inizio->value == elemento) {
      // trovato. L'elemento corrisponde. E' inutile continuare a
      // guardare, restituisco direttamente l'informazione al
      // programma chiamante.
      return 1;
    }
    inizio = inizio->next;
  }

  // non ho trovato niente. :(
  return 0;
} 


/**
 * Funzione di cancellazione Elimino un elemento dalla lista. Siccome
 * posso eliminare il primo elemento, la funzione restituisce
 * l'indirizzo dell'inizio lista al programma principale.
 */
TNodo * eliminaLista(TNodo * inizio, int elemento)
{
  TNodo * tmp;

  // Verifico che ci sia qualcosa in lista
  // se la lista e' vuota resta vuota
  if (inizio == NULL) return NULL;

  // Il primo nodo lo devo trattare in modo speciale
  if (inizio->value == elemento) {
    // devo eliminare il primo nodo.
    // il nuovo inizio della lista e' il secondo nodo
    TNodo * nuovoInizio = inizio->next;

    // cancello dalla memoria il primo nodo
    free(inizio);
    
    // segnalo al programma principa che l'inizio si e' spostato
    return nuovoInizio;

    /*
      NOTA:

      E' sbagliato fare:
      free(inizio);
      return inizio->next;

      anche se di solito funziona. Dopo la chiamata alal free() l'area
      di memoria contenente inizio->next e' libera e il sistema
      operativo puo' farne quello che vuole, non si puo' piu' accedere
      ai componenti della struttura
    */
  }

  // Ok, non devo cancellare il primo elemento. Scorro la lista.
  // non importa l'else, tanto nel corpo dell'if c'e' un return.
  tmp = inizio;
  while (tmp->next) {
    // per poter eliminare un elemento, devo avere a disposizione il
    // puntatore al nodo precedente.  Non posso mai eliminare il nodo
    // corrente: e' un po' come tagliare il ramo dell'albero su cui
    // siete seduti.
    TNodo * successivo = tmp->next;

    if (successivo->value == elemento) {
      // trovato. Elimino il nodo successivo a quello corrente.
      // primo passo: aggancio il resto della lista al nodo corrente.
      // ora il nodo 'successivo' e' scollegato dalla lista
      tmp->next = successivo->next;

      // libero la memoria assegnata al nodo eliminato
      free(successivo);

      // interrompiamo il ciclo
      break;

      // la scelta di interrompere il ciclo comporta che nel caso che
      // nella lista ci siano piu' elementi uguali elimino solo il
      // primo. Se tolgo il break, elimino tutti gli elementi uguali a
      // quello richiesto.
    }

    // vado sull'elemento successivo
    tmp = tmp->next;
  }
  // segnalo al programma principale che l'inizio lista non e' cambiato
  return inizio;
}

/**
 * Programma principale. Viene presentata all'utente una scelta su
 * cosa si vuole fare (inserire, stampare, o cercare nella lista).
 */ 
int main()
{
  // Puntatore al primo nodo della lista. La lista e' nota quando
  // abbiamo a disposizione il primo dei nodi. I successivi li ricavo
  // a partire dal primo.
  TNodo * inizioLista;
 
  // la scelta effettuata dall'utente nel menu.
  int scelta;
 
  // l'elemento da inserire o cercare
  int elemento;
 
  // all'inizio la lista e' vuota
  inizioLista = NULL;
 
  // ripetiamo, utilizzando un ciclo infinito
  while (1) {
    // Stampo un menu' utente
    printf("0- esci\n");
    printf("1- Inserisci elemento\n");
    printf("2- Stampa lista\n");
    printf("3- Cerca nella lista\n");
    printf("4- Cancella dalla lista\n");
    printf("Cosa vuoi fare?");
    
    // lego la risposta dell'utente
    scanf("%d",&scelta);
 
    // a seconda della scelta inserita, mi comporto di conseguenza
    switch (scelta) {
    case 0:
      // l'utente vuole terminare. L'istruzione return mi fa uscire dal main.
      return 0;
      // non serve il break: dopo aver eseguito il return,
      // l'esecuzione del programma termina.
  
    case 1:
      // inserimento di un nuovo elemento: leggo l'elemento
      printf("Inserisci elemento: ");
      scanf("%d",&elemento);
      // Aggiungo l'elemento alla lista. Il valore restituito dalla
      // funzione viene utilizzato come nuovo puntatore ad inizio
      // lista.
      inizioLista = aggiungiLista(inizioLista, elemento);

      // il break e' necessario, per evitare che l'esecuzione prosegua
      // con il case 2.
      break;
      
    case 2:
      // stampo la lista
      stampaLista(inizioLista);
      break;
      
    case 3:
      // cerco nella lista
      printf("Inserisci elemento da cercare: ");
      scanf("%d",&elemento);

      // per come e' fatta la funzione cercaLista, posso metterla
      // direttamente dentro l'if. Ricordare che in C un valore
      // diverso da zero significa 'vero'
      if (cercaLista(inizioLista, elemento)) {
	printf("Trovato!!!!\n");
      } else {
	printf("L'elemento non e' presente in lista\n");
      }

      // esco dal case
      break;

    case 4:
      // chiedo che elemento voglio cancellare
      printf("Inserisci elemento da cancellare: ");
      scanf("%d",&elemento);

      // controllo di errore: verifico che l'elemento ci sia
      if (cercaLista(inizioLista, elemento)) {
	// c'e', quindi lo posso cancellare

	// IMPORTANTE: il puntatore all''inizio lista puo' essere cambiato
	// all'interno della funzione (se cancello il primo elemento)
	inizioLista = eliminaLista(inizioLista, elemento);
	printf("Elemento cancellato\n");
      } else {
	printf("L'elemento non e' presente in lista.\n");
      }
      
      // esco dal case
      break;

    default:
      // la scelta e' sbagliata
      printf("Scelta non valida!\n");
    } 
  }
}
 
 
