#include<stdio.h>
#include<stdlib.h>

/** 
 *  Definiamo la struttura dati per contenere il generico nodo
 *  dell'albero. Gli elementi necessari sono:
 * 1- I due puntatori ai due rami sottostanti (destro e sinistro)
 * 2- Le variabili necessarie a contenere le informazioni richieste 
 *    (in questo caso una variabile float);
 */
 
struct SNodo
{
  float radice;
  struct SNodo * sinistro;
  struct SNodo * destro;
};

/* Introduciamo un typdef per evitare di dover ripetere per tutto il
 * codice "struct SNodo", sostituendolo con un "TNodo" */
typedef struct SNodo TNodo;

/**
 * 
 * Funzione per il calcolo del max e del minimo all'interno di un
 * sottoalbero. Poiche dobbiamo restituire al programma chiamante due
 * valori (max e min, per l'appunto), non possiamo restituirli come
 * valore di ritorno. Utilizzaimo quindi la tecnica di passare due
 * variabili per indirizzo, in modo da poterle modificare all'interno
 * della funzione e far vedere le modifiche al programma chiamante.
 */

void MaxMin(TNodo * albero, float * max, float * min)
{
  /* Per terminare la ricorsione, abbiamo due possibilita: la prima e'
     inserire questo controllo (vedi commento al termine della funzione)*/
  if(albero == NULL) return;

  /* Calcoliamo max e min, confrontando il valore corrente delle due
     variabili con l'informazione nel nodo corrente. Ricordiamoci che
     max e min sono puntatori, per cui bisogna usare l'operatore * per
     accedere al valore contenuto */
  if(*max < albero->radice)
    *max = albero->radice;

  if(*min > albero->radice)
    *min = albero->radice;

  /* Seconda possibilita' per terminare la ricorsione: chiamo la
     funzione solo se il nodo 'bersaglio' esiste */
  if(albero->destro != NULL)    
    MaxMin( albero->destro, max, min);

  if(albero->sinistro != NULL)
    MaxMin( albero->destro, max, min);
}

/*
  Nella funzione sopra, sono inseriti due controlli equivalenti. Per
  terminare la ricorsione, posso infatti seguire due strade. Nella
  seconda, prima di andare a calcolare il max e min sui nodi figli,
  verifico che i nodi esistano. In questo caso, la funzione MaxMin
  viene chiamata solo per i nodi dell'albero validi. Nella prima,
  toliendo il controllo descritto sopra, chiamo MaxMin per entrambi i
  nodi figli, anche se questi non esistono. A questo punto, all'inizio
  della funzione stessa, devo verificare che il nodo corrente sia
  valido. Confrontate anche i due controlli all'interno dei due
  if. Nal primo caso, verifico che il nodo corrente (albero) sia
  diverso da NULL. Nel secondo caso, verifico che i nodi figli siano
  diversi da NULL. Infine, la funzione richiede, cosi' come tutti li
  algoritmi di ricerca di max e min, una attenta inizializzazione
  delel due variabili max e min (vedere rispettivamente la funzione
  costruisci e la funziona main). */


/**
 * Inseriamo un nuovo nodo nell'albero in base alle richieste del
 * testo dell'esercizio. In questo caso ci serve come parametro di
 * ingresso il puntatore all'inizio dell'albero (o sottoalbero) e il
 * valore da inserire nel nodo. Inolre, la funzione puo' trovarsi
 * nella necessita' di modificare il nodo radice (nel caso che
 * l'albero sia vuoto). Questo lo possiamo ottenere o passando per
 * indirizzo il "puntatore al nodo radice", ottenendo quindi un
 * puntatore doppio (indirizzo di un puntatore) oppure restituendo il
 * valore del puntatore, eventalmente modificato, al programma
 * chiamante.  La funzione utilizza la seconda strada (vedere le
 * funzioni Costruisci2 e main2 per un esempio della seconda
 * possibilita'). 
 */
TNodo * Costruisci(TNodo * albero, float valore)
{
  float max, min;

  /* Se l'albero e' vuoto (non ho un nodo radice, devo semplicemente
     costruire un nuovo nodo e inserirci i valori. Devo anche
     ricordarmi di restituire al programma chiamante il nuovo nodo
     radice (prima l'albero era vuoto, ora contiene un nodo, per cui
     la radice e' stata modificata) 
  */
  if (albero == NULL)         /*caso in cui non esiste davvero*/
    {
      /* Alloco lo spazio di memori  necessario */
      albero = (TNodo*) malloc(sizeof(TNodo));

      /* inizializzo TUTTI i campi della struttura */
      albero->radice = valore;
      albero->destro = NULL;
      albero->sinistro = NULL;
      return albero;
    }

  /* Importante: devo inizializzare max e min prima di chiamare la
     funzione MaxMin. Perche' l'algoritmo funzioni correttamente, devo
     inizializzare le due variabili ad un valore ragionevole (nel
     senso che a max deve essere assegnato un valore <= del max
     effettivo). La soluzione piu' immediata e' assegnare a tali
     variabili un valore contenuto in uno dei nodi dell'albero. In
     particolare, prendiamo il nodo radice, che esiste sicuramente (il
     caso albero == NULL lo abbiamo trattato nell'if precedente). 
  */
  max = albero -> radice;
  min = albero -> radice;

  /* Chiamata alla funzione max min per calcolare max e min del
  sottoalbero corrente. Ricordarsi che max e min vanno passate per
  indirizzo).  
  */
  MaxMin( albero, &max, &min);

  /* Ora che ho max e min, posso sapere se il nuovo nodo va allocato
     nel sottoalbero di destra o di sinistra. */
  if( valore >= (max + min) / 2)
    {
      /* Ricordarsi di assegnare il valore (possibilemnete modificato)
         restituito dalla funzione, al nodo opportuno dell'albero. */
      albero -> destro = Costruisci( albero -> destro, valore);
    }
  else
    {
      albero -> sinistro = Costruisci(albero -> sinistro, valore);
    }
  /* restituiamo il nodo radice (in questo caso, non e' stato modificato) */
  return albero;
}

/**
 * Programma principale. Chiedo all'utente il numero di valori da
 * inserire, li leggo, e li inserisco nell'albero. Infine calcolo Max
 * e Min e li stampo.  
 */
int main()
{
  int n,i;

  TNodo * albero = NULL;

  float valore, max, min;

  printf("Quanti valori vuoi inserire?");
  scanf("%d", &n);

  for(i=0; i<n; i++)
    {
      printf("Inserisci il valore n. %d\n", i);
      scanf("%f", &valore);
      albero = Costruisci( albero, valore);
    }

  /* anche in questo caso devo inizializzare max e min. In questo
     caso, si utilizza l'ultimo nodo inserito nell'albero */
  max = valore;
  min = valore;
  MaxMin(albero, &max, &min);
  printf("Max = %f, Min = %f\n", max, min);
  getchar(); getchar();

}

/**
 * Inseriamo un nuovo nodo nell'albero in base alle richieste del
 * testo dell'esercizio. Seconda versione, passando la radice
 * dell'albero come puntatore doppio.  Rispetto alla funzione
 * precedente, si e' sostituito "albero" con " (*albero) ". Analizzare
 * anche la chiamata a Costruisci2.  
 */
void Costruisci2(TNodo ** albero, float valore)
{
  float max, min;

  /* Se l'albero e' vuoto (non ho un nodo radice), devo semplicemente
     costruire un nuovo nodo e inserirci i valori.
  */
  if (*albero == NULL)         /*caso in cui non esiste davvero*/
    {
      /* Alloco lo spazio di memoria necessario */
      *albero = (TNodo*) malloc(sizeof(TNodo));

      /* inizializzo TUTTI i campi della struttura */
      (*albero) ->radice = valore;
      (*albero) ->destro = NULL;
      (*albero) ->sinistro = NULL;
      
    }

  /* Importante: devo inizializzare max e min prima di chiamare la
     funzione MaxMin. Perche' l'algoritmo funzioni correttamente, devo
     inizializzare le due variabili ad un valore ragionevole (nel
     senso che a max deve essere assegnato un valore <= del max
     effettivo). La soluzione piu' immediata e' assegnare a tali
     variabili un valore contenuto in uno dei nodi dell'albero. In
     particolare, prendiamo il nodo radice, che esiste sicuramente (il
     caso albero == NULL lo abbiamo trattato nell'if precedente). 
  */
  max = (*albero) -> radice;
  min = (*albero) -> radice;

  /* Chiamata alla funzione max min per calcolare max e min del
  sottoalbero corrente. Ricordarsi che max e min vanno passate per
  indirizzo).  
  */
  MaxMin( *albero, &max, &min);

  /* Ora che ho max e min, posso sapere se il nuovo nodo va allocato
     nel sottoalbero di destra o di sinistra. */
  if( valore >= (max + min) / 2)
    {
      /* Devo passare il puntatore al ramo destro del nodo
         corrente. La & all'inizio indica che lo passo per
         indirizzo. Anche se non tutte le parentesisono necessarie,
         servono per chiarire (per quanto possibile) la loogica
         dell'istruzione */
      Costruisci2( & ( (*albero) -> destro), valore);
    }
  else
    {
      Costruisci2(& ((*albero) -> sinistro), valore);
    }
}

/**
 * Programma principale. Chiedo all'utente il numero di valori da
 * inserire, li leggo, e li inserisco nell'albero. Infine calcolo Max
 * e Min e li stampo.  
 */
int main2()
{
  int n,i;

  TNodo * albero = NULL;

  float valore, max, min;

  printf("Quanti valori vuoi inserire?");
  scanf("%d", &n);

  for(i=0; i<n; i++)
    {
      printf("Inserisci il valore n. %d\n", i);
      scanf("%f", &valore);
      Costruisci2( &albero, valore);
    }

  /* anche in questo caso devo inizializzare max e min. In questo
     caso, si utilizza l'ultimo nodo inserito nell'albero */
  max = valore;
  min = valore;
  MaxMin(albero, &max, &min);
  printf("Max = %f, Min = %f\n", max, min);
  getchar(); getchar();

}

