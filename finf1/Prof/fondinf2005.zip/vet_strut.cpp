#include <stdio.h>
#include <stdlib.h>

/**
 * Esercitazione del 23 maggio 2005
 * Leonardo Bocchi (leonardo.bocchi@asp.det.unifi.it)
 * http://asp.det.unifi.it/~leo
 *
 * Programma di esempio per funzioni, strutture ed array, viene
 * utilizzato per mostrare le seguenti tecniche:
 *
 * -Passaggio di array alle funzioni
 * -Utilizzo di parametri di ingresso e di uscita alle funzioni
 * -Creazione di funzioni riutilizzabili
 * -Utilizzo di strutture per raggruppare dati correlati
 *
 **/

/**
 * Un vettore viene descritto completamente quando ne e' nota la
 * lunghezza, oltre alle componenti. Rappresentiamo quindi questi due
 * dati raggruppandoli in una struttura, che denominiamo SVettore. La
 * S iniziale serve ad indicare sch stiamo definendo un tipo di
 * variabile (e precisamente una struttura) e non una variabile.  Per
 * comodita', fissiamo il numero massimo di componenti, e lo assumiamo
 * pari a 32.
 */

/* Una costante per dimensionare gli array */
#define MAX_COMP 32

struct SVettore { 
  int dimensione;       // numero di componenti (effettive)
  int componenti[MAX_COMP];   // array delle conponenti
};

// il typedef ci permette di sostituire, in tutto il codice, la
// scritta 'struct SVettore' con la piu' compatta TVettore
typedef struct SVettore TVettore;

/*
 * Prototipi di funzione
 */
void leggiVettore(TVettore * vettore);
void scriviVettore(TVettore * vettore);
void sommaVettori(TVettore * risultato, TVettore * g, TVettore * h);

/**
 * Funzione per leggere da tastiera un vettore di n elementi.  Il
 * vettore, viene passato come argomento alla funzione. Si tratta
 * infatti di un passaggio per indirizzo, per cui il valore della
 * variabile, modificato all'interno della funzione, viene restituito
 * al codice chiamante. Il parametro a ha quindi la funzione di un
 * parametro di uscita. Il valore di ritorno della funzione puo'
 * essere void, in quanto la funzione restituisce il valore desiderato
 * all'interno del parametro a.  Il nome della funzione utilizza la
 * convenzione detta 'lowerCaseCamel', in cui cioe' le iniziali delle
 * parole che compongono il nome sono maiuscole, con l'esclusione
 * della prima lettera del nome.
 */
void leggiVettore(TVettore * vettore)
{
  // variabile locale di lavoro
  int i;
  int dim;
  int a;
  
  // chiedo la dimensione del vettore
  printf("Inserire la dimensione del vettore:");
  scanf("%d", &dim);
  
  // quando si utilizzano le strutture, ricordarsi di inizializzare
  // tutti i campi
  vettore -> dimensione = dim;

  // il numero di componenti e' fissato uguale a due
  for (i=0; i<dim; i++) {
    // viene richiesto l'inserimento di una componente
    printf("inserire componente %d:", i);

    // la componente viene letta
    scanf("%d",&a);
    // e memorizzata all'itnerno della struttura
    vettore->componenti[i] = a;
  }
}

/**
 * Funzione per l'output a video di un vettore. In questo caso il
 * vettore, passato come argomento alla funzione, e' un parametro di
 * ingresso che non viene modificato dalla funzione stessa. Anche in
 * questo caso la funzione e' di tipo void, e il nome segue la
 * convenzione 'lowerCaseCamel' 
 */
void scriviVettore(TVettore * vettore)
{
  // variabile locale di lavoro
  int i;

  // stampo la parentesi aperta di inizio vettore
  printf("(");

  // ogni TVettore al suo interno contiene anche la lunghezza.
  // utilizziamo questa info per operare correttamente solo sulle
  // componenti realmente presenti
  for (i=0; i<vettore->dimensione; i++) {
    // stampo la generica componente
    printf("%d",vettore->componenti[i]);

    // per tutte le componenti, escluso l'ultima, stampo una virgola di 
    // separazione
    if (i != vettore->dimensione - 1) printf(", ");
  }
  
  // la parentesi chiusa indica il termine del vettore
  printf(")");
}

/**
 * Funzione per il calcolo della somma di due vettori. La funzione ha
 * tre argomenti, il primo di uscita e gli altri due di ingresso.  la
 * funzione effettua la somma del vettore g con il vettore h,
 * memorizzando il risultato in ris. L'ordine degli argomenti segue
 * l'ordine logico in cui questi apparirebbero in una espressione del
 * tipo ris = g + h. Nel caso che i due vettori abbiano lunghezza
 * differente, supponiamo, per semplicita' che le compoenti mancanti
 * valgano zero.
 */
void sommaVettori(TVettore * ris, TVettore * g, TVettore * h)
{
  // variabile locale di lavoro
  int i;

  // calcolo la dimensione desiderata
  // si dimostra anche l'utilizzo dell'operatore '?' e ':'
  ris->dimensione = 
    (g->dimensione > h->dimensione)?     // se g ha piu' comp. di h
    g->dimensione                        // uso la diemnsione di g
    :                                    // altrimenti
    h->dimensione;                       // uso la dimensione di h

  // azzero le componenti inutilizzate di g ed h
  for (i=g->dimensione; i<MAX_COMP; i++)
    g->componenti[i] = 0;
  for (i=h->dimensione; i<MAX_COMP; i++)
    h->componenti[i] = 0;

  // calcolo la somma
  for (i=0; i<ris->dimensione; i++) {
    // calcolo la generica componente per tradurre in italiano,
    // considerare ogni termine da destra a sinistra: "i-esima
    // componente di ris" diventa "ris->componenti[i]"
    ris->componenti[i] = g->componenti[i] + h->componenti[i];
  }
}

/**
 *
 * Programma principale
 *
 * Vengono letti da tastiera due vettori a e b. Questi vengono sommati
 * e il risultato viene stampato a video. Poi vengono chiesti tre vettori,
 * e viene calcolata la somma di tutti e tre. Notare come l'utilizzo
 * delle proprieta' elementari della somma (associativita') permette
 * di calcolare la somma senza inserire ulteriori funzioni
 */
main()
{
  // anche le strutture possono essere dichiarate tutte insieme
  TVettore b,c,d,r,s;

  printf("Inserire il primo vettore\n");
  leggiVettore(&b);
  printf("Inserire il secondo vettore\n");
  leggiVettore(&c);

  sommaVettori(&r,&b,&c);
  printf("Soluzione\n\n");
  scriviVettore(&b);
  printf(" + ");
  scriviVettore(&c);
  printf(" fa ");
  scriviVettore(&r);

  printf("\n\nOra calcoliamo la somma di tre vettori\n");

  printf("Inserire il primo vettore\n");
  leggiVettore(&b);

  printf("Inserire il secondo vettore\n");
  leggiVettore(&c);

  printf("Inserire il terzo vettore\n");
  leggiVettore(&d);

  // sommo b e c e metto il risultato in r
  sommaVettori(&r,&b,&c);
  // sommo r e d e metto il risultato in s
  sommaVettori(&s,&r,&d);
 
  printf("Soluzione\n\n");
  scriviVettore(&b);
  printf(" + ");
  scriviVettore(&c);
  printf(" + ");
  scriviVettore(&d);
  printf(" fa ");
  scriviVettore(&s);
  printf("\n\n");

  // dopo aver usato una scanf() servono due getchar() per sospendere 
  // il programma
  getchar(); 
  getchar();
}

