#include <stdio.h>
#include <stdlib.h>

/**
 * Esercitazione del 19 maggio 2005
 * Leonardo Bocchi (leonardo.bocchi@asp.det.unifi.it)
 * http://asp.det.unifi.it/~leo
 *
 * Programma di esempio per funzioni e array, viene utilizzato per
 * mostrare le seguenti tecniche:
 *
 * -Passaggio di array alle funzioni
 * -Utilizzo di parametri di ingresso e di uscita alle funzioni
 * -Creazione di funzioni riutilizzabili
 *
 * */

/*
 * Prototipi di funzione
 */
void leggiVettore(int *a);
void scriviVettore(int *a);
void sommaVettori(int * ris, int * g, int * h);

/**
 * Esempio di funzione ERRATA
 *
 * E' un grave errore resituire l'indirizzo di una variabile locale.
 * Infatti all'uscita della funzione, la variabile non esiste piu' e
 * il nostro indirizzo punta ad una locazione di memoria non valida, o
 * piu' probabilmente ad una locazione di memoria utilizzata per altri
 * scopi.
 *
 */
int * leggivettore_no()
{
  int a[2];

  a[0] = 0;
  a[1] = 1;
  // .....
  return a; // NO!!!!!! La variabile a (senza indice) e' un puntatore
}

/**
 * Funzione per leggere da tastiera un vettore di due elementi.  Il
 * vettore, per evitare il problema di cui sopra, viene passato come
 * argomento alla funzione. Si tratta infatti di un passaggio per
 * indirizzo, per cui il valore della variabile, modificato
 * all'interno della funzione, viene restituito al codice
 * chiamante. Il parametro a ha quindi la funzione di un parametro di
 * uscita. Il valore di ritorno della funzione puo' essere void, in
 * quanto la funzione restituisce il valore desiderato all'interno del
 * parametro a.  Il nome della funzione utilizza la convenzione detta
 * 'lowerCaseCamel', in cui cioe' le iniziali delle parole che
 * compongono il nome sono maiuscole, con l'esclusione della prima
 * lettera del nome.
 */
void leggiVettore(int *a)
{
  // variabile locale di lavoro
  int i;
  
  // il numero di componenti e' fissato uguale a due
  for (i=0; i<2; i++) {
    // viene richiesto l'inserimento di una componente
    printf("inserire componente %d:", i);

    // la componente viene letta
    scanf("%d",&a[i]);
  }
}

/**
 * Funzione per l'output a video di un vettore. In questo caso il
 * vettore, passato come argomento alla funzione, e' un parametro di
 * ingresso che non viene modificato dalla funzione stessa. Anche in
 * questo caso la funzione e' di tipo void, e il nome segue la
 * convenzione 'lowerCaseCamel' 
 */
void scriviVettore(int *a)
{
  // variabile locale di lavoro
  int i;

  // stampo la parentesi aperta di inizio vettore
  printf("(");
  for (i=0; i<2; i++) {
    // stampo la generica componente
    printf("%d",a[i]);

    // per tutte le componenti, escluso l'ultima, stampo una virgola di 
    // separazione
    if (i != 1) printf(", ");
  }
  
  // la parentesi chiusa indica il termine del vettore
  printf(")");
}

/**
 * Funzione per il calcolo della somma di due vettori. La funzione
 * ha tre argomenti, il primo di uscita e gli altri due di ingresso.
 * la funzione effettua la somma del vettore g con il vettore h,
 * memorizzando il risultato in ris. L'ordine degli argomenti
 * segue l'ordine logico in cui questi apparirebbero in una espressione
 * del tipo ris = g + h.
 */
void sommaVettori(int * ris, int * g, int * h)
{
  // variabile locale di lavoro
  int i;

  for (i=0; i<2; i++) {
    // calcolo la generica componente
    ris[i] = g[i] + h[i];
  }
}

/**
 *
 * Programma principale
 *
 * Vengono letti da tastiera due vettori a e b. Questi vengono sommati
 * e il risultato viene stampato a video. Poi vengono chiesti tre vettori,
 * e viene calcolata la somma di tutti e tre. Notare come l'utilizzo
 * delle proprieta' elementari della somma (associativita') permette
 * di calcolare la somma senza inserire ulteriori funzioni
 */
main()
{
  int b[2];
  int c[2];
  int d[2];
  int r[2];
  int s[2];

  printf("Inserire il primo vettore\n");
  leggiVettore(b);
  printf("Inserire il secondo vettore\n");
  leggiVettore(c);

  sommaVettori(r,b,c);
  printf("Soluzione\n\n");
  scriviVettore(b);
  printf(" + ");
  scriviVettore(c);
  printf(" fa ");
  scriviVettore(r);

  printf("\n\nOra calcoliamo la somma di tre vettori\n");

  printf("Inserire il primo vettore\n");
  leggiVettore(b);

  printf("Inserire il secondo vettore\n");
  leggiVettore(c);

  printf("Inserire il terzo vettore\n");
  leggiVettore(d);

  // sommo b e c e metto il risultato in r
  sommaVettori(r,b,c);
  // sommo r e d e metto il risultato in s
  sommaVettori(s,r,d);
 
  printf("Soluzione\n\n");
  scriviVettore(b);
  printf(" + ");
  scriviVettore(c);
  printf(" + ");
  scriviVettore(d);
  printf(" fa ");
  scriviVettore(s);
  printf("\n\n");

  // dopo aver usato una scanf() servono due getchar() per sospendere 
  // il programma
  getchar(); 
  getchar();
}

