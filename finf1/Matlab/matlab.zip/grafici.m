function grafici(a,b)
%Sia data la funzione:
%y=x-cos(x)
%La cui derivata prima �:
%y1=1+sin(x)
%Scrivere una funzione grafici.m che, 
%ricevendo in ingresso gli estremi a e b dell'intervallo [a b],
%calcoli 100 valori di y e di y1 su tale intervallo e disegni il grafico di entrambe le funzioni.
%(ad esempio usare la funzione sui due intervalli: [0  2pi] e [-pi/2  pi/2]).
 
x=[a:0.01:b];
y=x-cos(x);
y1=1+sin(x);
subplot(2,1,1)
plot(x,y)
subplot(2,1,2)
plot(x,y1)