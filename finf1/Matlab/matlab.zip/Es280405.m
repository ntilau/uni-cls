%Si utilizzi la nuova funzione rect() per costruire e visualizzare un rettangolo, 
%di ampiezza 3 e di estremi 1 s, 2 s.
%L'asse temporale (discretizzato a passo dt=10 ms), ha estremi 3 s, 3 s. 
t=-3:0.01:3;
R=3*rect(t,-1,2);
figure
plot(t,R);
xlabel('Tempo [s]')
ylabel('Rettangolo di ampiezza 3')
Title('Uso della funzione rect.m')
axis([-3 3 -1 4])