function y=rect(x,A,B) 
%Si scriva una funzione (rect.m) che restituisca in uscita 
%l'ordinata del rettangolo di estremi A e B, posta uguale a 1, rispetto al vettore delle ascisse x 
%e disegni il grafico del rettangolo cos� ottenuto.
%La funzione ha 3 parametri in ingresso (un vettore, due valori scalari) e 1 in uscita (un vettore).


y=zeros(size(x)); %vettore inizializzato a zero, di lunghezza uguale al vettore x
set=find(x>=A & x<=B); %valori di x compresi tra gli estremi
y(set)=1;   %ordinata del rettangolo uguale a 1
figure
plot(x,y,'r')
xlabel('Tempo [s]')
ylabel('Rettangolo unitario')
Title('Funzione rect.m')
axis([-3 3 -1 2])