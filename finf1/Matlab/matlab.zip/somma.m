function Y=somma(a,b)
%Scrivere una funzione che somma 2 matrici, passate come parametri, 
%e restituisce il risultato. 
%La funzione deve verificare che le 2 matrici abbiano la stessa dimensione.
%Suggerimento: usare la funzione di libreria size.m 
%e gli operatori logici (|  OR; &  AND; ~=  disuguaglianza; ==  uguaglianza).

[a1,a2]=size(a);
[b1,b2]=size(b);
if a1~=b1 | a2 ~=b2
disp('ATTENZIONE: matrici di diversa dimensione');
return;
end
Y=a+b;
return;