function logaritmi(a,b,pass)
%Scrivere una funzione che calcoli il valore di ln(x) e di log10(x) 
%e ne disegni i grafici (con colore e/o tratteggio diverso, entrambi nella stessa figura)
%con didascalia esplicativa.
%Suggerimento: per velocizzare la scrittura della funzione e  ogni volta si renda necessario, 
%ricordarsi di usare l'help in linea (ad es. per la definizione delle funzioni ln e log10, e per la costruzione del grafico).
%La funzione deve avere come parametri di ingresso gli estremi dell'intervallo ed il passo di campionamento, 
%entrambi da specificare da parte dell'utente.
%Non si richiede che venga restituito alcun valore in uscita dalla funzione. 

%(Opzionale: Usare la funzione  find  per trovare i punti di intersezione delle due curve 
%e sovrapporre al grafico un simbolo (ad es: *) in corrispondenza di tali punti.)
x=(a:pass:b);
y1=log(x);
y2=log10(x);
plot(x,y1,'r')
hold on
plot(x,y2,'k')
Title('Log.naturale (rosso) e log. base 10 (nero). Intersezione: * blu')
Xlabel('asse x')
Ylabel('asse y')
intersez=find(y1==y2);
plot(y1(intersez),'*')
hold off