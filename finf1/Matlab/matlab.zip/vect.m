function [minvett,maxvett]=vect(V1)
%Dato un vettore V1 di dimensione n=16, 
%scrivere una funzione che ordini il vettore sia in senso crescente che decrescente
%e ne determini il minimo -minvett- e il massimo -maxvett-.
%La funzione deve avere come parametro di ingresso il vettore V1 
%e come parametri in uscita minvett e maxvett.  
%La funzione deve anche disegnare il grafico del vettore non ordinato
%e dei due vettori ordinati in una stessa figura (con colori o tratteggio diverso).
%Utilizzare dove possibile funzioni di libreria del Matlab (min, max, sort).

%Come vettore V1 di prova si pu� utilizzare il seguente:
%V1=[5 12 3 8 -15 18 2 21 22 -3.5 7.8 1 2.3 -1.6 1.3 4.1]

V1=[5 12 3 8 -15 18 2 21 22 -3.5 7.8 1 2.3 -1.6 1.3 4.1];
minvett=min(V1);
maxvett=max(V1);
ascend=sort(V1);
descend=-sort(-V1);
plot(V1,'b')
hold on
plot(ascend,'r')
plot(descend,'g')