function parabola(step)
%Scrivere una funzione che costruisca una parabola:
%y = x^2
%sull'intervallo [-100, 100], 
%con passo di campionamento -step- passato come parametro dall�utente.
%Costruire poi la stessa parabola sull'intervallo [-10, 10].
%Disegnare in un'unica figura i grafici delle due funzioni (si usi la funzione subplot), 
%indicando le grandezze e la funzione sugli assi e nel titolo (funzioni xlabel, ylabel, title).
 
x = -100:step:100;
 
y = x.^2; 
len_x = length(x)
x1= -10:step:10;
y1=x1.^2;
figure
subplot(2,1,1)
plot(x,y,'or')
xlabel('x')
ylabel('y')
title('First plot on [-100,100]')
subplot(2,1,2)
plot(x1,y1,'--x')
xlabel('x')
ylabel('y')
title('Second plot on [-10,10]')
