<html><head></head><body>
<?php
 $s = 'la variabile $a non esiste';
 print ("s vale: <B>$s</B><BR>\n");
 
 $len = strlen($s);
 $len--;
 
 $sinv = '';
 for($i=$len;$i>=0;$i--)
 {
  $sinv = $sinv . $s[$i];
 }
 print ("sinv vale: <B>$sinv</B><BR>");
?>
</body></html>
