<html>
<head></head>
<body>
 <form action="sqr.php" method="get">
  <h2>Valore: <input type="text" name="radice" value="<?php if (IsSet($_GET['radice'])) print $_GET['radice']; ?>"></h2>
  <h2>Epsilon: <input type="text" name="epsilon" value="<?php if (IsSet($_GET['epsilon'])) print $_GET['epsilon']; ?>"></h2>
  <input type="submit" value="Calcola">
 </form>
<?php
/* Radice quadrata (metodo di Newton) */
if (IsSet($_GET['radice']) and IsSet($_GET['epsilon']))
{
  if ($_GET['radice'] > 0)
       $t = $_GET['radice'];
  else
     {
     	print "Non so cosa dovrei calcolare";
     	print "</body></html>";
     	exit(0);
     }
  if ($_GET['epsilon'] <= 0)
     {
     	$p = 0.000000001;
     }
  else
     $p=$_GET['epsilon'];
  
$s=1.0;
$sq = $s * $s;
while(($sq-$t > $p) or ($sq-$t < -$p))
{
	// print("Valore corrente: $s<BR>");
	$s = ($s + ($t/$s))/2;
	$sq = $s * $s;
}
print("<h2>La radice di $t � circa $s</h2>");
print("con approssimazione di $p");
}
?>
</body></html>