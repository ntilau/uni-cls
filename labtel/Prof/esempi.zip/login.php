<html>
<head></head>
<body>
<?php
   print "<h1>Cognome:   {$_REQUEST['cognome']}</h1>";
   print "<h2>Matricola: {$_REQUEST['num_matricola']}</h2>";		
?>
</body>
</html>
