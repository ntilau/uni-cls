<?php
    session_start();
    session_destroy();
?>
<html>
<head></head>
<body>
<h1>Secondo esempio</h1>
<?php
print "<h2>La variabile test2 vale {$HTTP_SESSION_VARS['test2']}</h2>";
?>
</body>
</html>

