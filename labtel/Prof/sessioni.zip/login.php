<?php
   session_start();
   include "utenti.php";
   if ($_POST['password'] != $users[$_POST['username']])
   {
   	?>
   	<html><head></head><body>
   	<h1>Non autorizzato!</h1>
   	</body></html>
   	<?php
   	exit();
   }
?>
<html>
<head></head>
<body>
<?php
   $username = $_POST['username'];
   $password = $_POST['password'];

   session_register('username');
   session_register('password');

   print "<h1>Username: {$_POST['username']}</h1>";
   print "<h2>Password: {$_POST['password']}</h2>";		
   
?>
<h2>Click <a href="pagina2.php">here</a></h2>
</body>
</html>
