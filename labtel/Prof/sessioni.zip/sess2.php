<?php
/* Questo funziona anche con le Global Register off */
session_start();
session_register("count");
?>
<html>
<head><title>Pagina 1</title></head>
<body>
<h1>$count vale <?php echo $HTTP_SESSION_VARS["count"]; $HTTP_SESSION_VARS["count"]++; ?></h1>
</body>
</html>

