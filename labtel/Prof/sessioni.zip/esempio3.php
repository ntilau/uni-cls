<?php
    session_start();
?>
<html>
<head></head>
<body>
<h1>Secondo esempio</h1>
<?php
print "<h2>La variabile test3 vale $test3</h2>";
?>
</body>
</html>
