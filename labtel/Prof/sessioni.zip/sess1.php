<?php
/* Questo funziona solo con le Global Register on */
session_start();
session_register("count");
?>
<html>
<head><title>Pagina 1</title></head>
<body>
<h1>$count vale <?php echo $count; $count++; ?></h1>
</body>
</html>

