<?php
/* l'array users contiene le coppie username/password
   autorizzate */
	$users['pippo'] = 'pippo';
	$users['pluto'] = 'pluto';
	
	   if (IsSet($HTTP_SESSION_VARS['password']))
   {
   	if (  ($HTTP_SESSION_VARS['password'] !=
         $users[$HTTP_SESSION_VARS['username']]))
   	{
   	?>
   	<html><head></head><body>
   	<h1>Non autorizzato!</h1>
   	</body></html>
   	<?php
   	exit();
   	}
   	session_destroy();
   }
   else
   {
      	?>
   	<html><head></head><body>
   	<h1>Non autorizzato!</h1>
   	</body></html>
   	<?php
   	exit();
    }

	
?>
	