<?php
    session_start();
    session_register('test');
    session_register('test2');
    /* */
    $HTTP_SESSION_VARS['test'] = 4;
    $HTTP_SESSION_VARS['test2'] = "Claudio";
?>
<html>
<head></head>
<body>
<h1>Primo esempio</h1>
<?php
print "<h2>La variabile test vale {$HTTP_SESSION_VARS['test']}</h2>";
?>
</body>
</html>
