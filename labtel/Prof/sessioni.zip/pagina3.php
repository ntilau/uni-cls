<?php
   session_start();
   include "utenti.php";   
?>
<html>
<head></head>
<body>
<h1> Pagina 3 </h1>
<h2><a href="form.html">Inizio</a></h2>
</body>
</html>
