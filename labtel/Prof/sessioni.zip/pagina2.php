<?php
   session_start();
   include "utenti.php";
 
?>
<html>
<head></head>
<body>
<h1> Pagina 2 </h1>
<h2><a href="pagina3.php">Fine</a></h2>
</body>
</html>
