%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%LICENCE
% Experiment Framework
% Copyright (C) 2001-2002-2003  Stefano Selleri
%
%This program is free software; you can redistribute it and/or
%modify it under the terms of the GNU General Public License
%as published by the Free Software Foundation; either version 2
%of the License, or (at your option) any later version.
%
%This program is distributed in the hope that it will be useful,
%but WITHOUT ANY WARRANTY; without even the implied warranty of
%MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%GNU General Public License for more details.
%
%You should have received a copy of the GNU General Public License
%along with this program; if not, write to the Free Software
%Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Crea il processo principale e la finestra dei men�
% principale.
%
% 13-06-2001 Stefano Selleri
% Versione 00.00.00
%
% Ref: WN-A
%
    
function main()
%
% First merges alv.rc
%
global ALVrcItems;
path(path,'API');
ALVrcItems=GetALVrc('ef.rc');

%
% Then builds Chapter tree
%
ALVchItems=GetALVchapters;

%
% Finally pops up ALV Main Window
%
scrsize = get(0,'ScreenSize');
MasterWindow = figure ('Name','EF - Experiment Framework (C) 2003 Stefano Selleri',...
   'Position',[15,scrsize(4)-65,scrsize(4)-35,1],...
   'Resize','off',...
   'MenuBar','none');
%
% Menubar
%
MasterMenuI0  = uimenu('Label',ALVrcItems.FileMenu); 
MasterMenuI1  = uimenu('Label',ALVrcItems.ChapterMenu); 
MasterMenuI2  = uimenu('Label',ALVrcItems.HelpMenu); 
%
% Menu File
%
MenuFileI0 = uimenu (MasterMenuI0,...
   'Label',ALVrcItems.ExitLabel,'Callback','close(MasterWindow);clear');
%
% Menu Chapter
%
chapters = getfield(ALVchItems,'Keys');
for i=1:length(chapters)
   MenuLabel      = getfield(ALVchItems,strcat(chapters(i).name,'label'));
   SubMenuStruct  = getfield(ALVchItems,strcat(chapters(i).name,'struct'));
   MenuChapter(i) = uimenu (MasterMenuI1,'Label',MenuLabel);
   for j=1:length(SubMenuStruct)
      command = strcat('ALVappletWrapper(''',chapters(i).name,...
         ''',''',SubMenuStruct(j).dir,''')');
      SubMenuChapter(i,j) = uimenu(MenuChapter(i),'Label',SubMenuStruct(j).label,...
         'Callback',command);
   end
end
   
%
% Menu Help
%
MenuHelpI0 = uimenu (MasterMenuI2,...
   'Label',ALVrcItems.HelpLabel,'Callback','ALVhelp');
MenuHelpI1 = uimenu (MasterMenuI2,...
   'Label',ALVrcItems.AboutLabel,'Callback','ALVabout');

