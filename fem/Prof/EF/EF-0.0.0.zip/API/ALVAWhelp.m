%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%LICENCE
% Experiment Framework
% Copyright (C) 2001-2002-2003  Stefano Selleri
%
%This program is free software; you can redistribute it and/or
%modify it under the terms of the GNU General Public License
%as published by the Free Software Foundation; either version 2
%of the License, or (at your option) any later version.
%
%This program is distributed in the hope that it will be useful,
%but WITHOUT ANY WARRANTY; without even the implied warranty of
%MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%GNU General Public License for more details.
%
%You should have received a copy of the GNU General Public License
%along with this program; if not, write to the Free Software
%Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Ambiente Laboratorio Virtuale
%
function ALVAWhelp()
%
% Effettua la chiamata all'applet
%
% 15-06-2001 Stefano Selleri
% Versione 00.00.00
%
% Ref: WN-A
%
% Maschera di Help
%
global HelpData;

scrsize  = get(0,'ScreenSize');
WHelp = figure('Name','ALS - Experiment Help',...
   'Position',[(scrsize(3)-600)/2,(scrsize(4)-400)/2,600,400],...
   'MenuBar','none');

WTitle = uicontrol(WHelp,'Style','text','String',HelpData.Title,...
   'Position',[1,375,598,30],'FontSize',18,...
   'BackgroundColor',[0.8,0.8,0.8]);
WBody = uicontrol(WHelp,'Style','text','String',HelpData.Text,...
   'Position',[1,20,598,350],'BackgroundColor',[0.8,0.8,0.8]);

cback = strcat('close(',num2str(WHelp),')');
WOK = uicontrol(WHelp,'Style','pushbutton','String','Ok',...
   'Position',[1,1,598,20],'Callback',cback);
