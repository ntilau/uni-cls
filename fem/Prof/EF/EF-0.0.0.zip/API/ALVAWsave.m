%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%LICENCE
% Experiment Framework
% Copyright (C) 2001-2002-2003  Stefano Selleri
%
%This program is free software; you can redistribute it and/or
%modify it under the terms of the GNU General Public License
%as published by the Free Software Foundation; either version 2
%of the License, or (at your option) any later version.
%
%This program is distributed in the hope that it will be useful,
%but WITHOUT ANY WARRANTY; without even the implied warranty of
%MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%GNU General Public License for more details.
%
%You should have received a copy of the GNU General Public License
%along with this program; if not, write to the Free Software
%Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Ambiente Laboratorio Virtuale
%
function ALVAWsave()
%
% Effettua il Salvataggio Dati
%
% 14-06-2001 Stefano Selleri
% Versione 00.00.00
%
% Ref: WN-A
%
%
global ALVrcItems;
global AppletData;
global AppletDataTL;
global ChDir;
global ExDir;

Dd = dir(strcat(ExDir,'/*.ad'));
liststring = {Dd.name};

smode = 1;   
promptstring = cellstr(ALVrcItems.AWLabelFileNew);
listsize = [160 300];
okstring = ALVrcItems.AWButtonOK;
cancelstring = ALVrcItems.AWButtonCancel;
fus = 8;
ffs = 8;
uh = 18;

ex = get(0,'defaultuicontrolfontsize')*1.5;  % height extent per line of
% uicontrol text, in pixels (approximate)

fp = get(0,'defaultfigureposition');
w = 2*(fus+ffs)+listsize(1);
h = 2*ffs+6*fus+ex*length(promptstring)+listsize(2)+uh+(smode==2)*(fus+uh)+uh;
fp = [fp(1) fp(2)+fp(4)-h w h];  % keep upper left corner fixed

fig_props = { ...
      'name'                   '' ...
      'resize'                 'off' ...
      'numbertitle'            'off' ...
      'windowstyle'            'modal' ...
      'createfcn'              ''    ...
      'position'               fp   ...
      'closerequestfcn'        'set(gcf,''userdata'',''cancel'')' ...
   };

fig = figure(fig_props{:});

uicontrol('style','frame',...
   'position',[0 0 fp([3 4])])
uicontrol('style','frame',...
   'position',[ffs ffs 2*fus+listsize(1) 2*fus+uh])
uicontrol('style','frame',...
   'position',[ffs ffs+3*fus+uh 2*fus+listsize(1) ...
      listsize(2)+3*fus+ex*length(promptstring)+uh])

if length(promptstring)>0
   prompt_text = uicontrol('style','text','string',promptstring,...
      'horizontalalignment','left','units','pixels',...
      'position',[ffs+fus fp(4)-(ffs+fus+ex*length(promptstring)) ...
         listsize(1) ex*length(promptstring)]);
end

btn_wid = (fp(3)-2*(ffs+fus)-fus)/2;
ok_btn = uicontrol('style','pushbutton',...
   'string',okstring,...
   'position',[ffs+fus ffs+fus btn_wid uh],...
   'callback','listdlg(0)');
cancel_btn = uicontrol('style','pushbutton',...
   'string',cancelstring,...
   'position',[ffs+2*fus+btn_wid ffs+fus btn_wid uh],...
   'callback','listdlg(1)');

listbox = uicontrol('style','listbox',...
   'position',[ffs+fus ffs+3*uh+4*fus listsize(1) listsize(2)-uh],...
   'string',liststring,...
   'backgroundcolor','w',...
   'max',smode,...
   'tag','listbox', ...
   'callback', 'ALVAWlistdlg');

textbox = uicontrol('style','edit',...
   'position',[ffs+fus ffs+uh+4*fus listsize(1) 18],...
   'backgroundcolor','w',...
   'tag','textbox',...
   'HorizontalAlignment','left',...
   'string','appletdata.ad');

waitfor(fig,'userdata')

switch get(fig,'userdata')
   
case 'ok'
   value = 1;
   selection = get(textbox,'string');
case 'cancel'
   value = 0;
   selection = [];
end

delete(fig);

filename = strcat(ExDir,'/',selection);

%
% Writes down
%
FH = fopen(filename,'r');
answer=ALVrcItems.AWButtonOK;
if (FH~=-1)
   answer = questdlg(ALVrcItems.AWMsgOverwrite,'Warning',...
      ALVrcItems.AWButtonOK,ALVrcItems.AWButtonCancel,ALVrcItems.AWButtonCancel);
fclose(FH);   
end

if (strcmpi(answer,ALVrcItems.AWButtonOK))
   FH = fopen(filename,'w');
   if (FH==-1)
      ALVwarning(ALVrcItems.AWMsgOpenError);
   else
      fprintf(FH,'%% ALV 0.0.0 Applet Data File\n');
      fprintf(FH,'%% Data for %s\n',ExDir);
      fn = fieldnames(AppletData)
      ni = length(fn);
      for i=1:ni
         fprintf(FH,'Variable=%s\n',char(fn(i)));
         var = getfield(AppletData,char(fn(i)));
         [n,m]=size(var);
         fprintf(FH,'  Size=[%d,%d]\n',n,m);
         VarTL    = getfield(AppletDataTL,char(fn(i)));
         Vartype  = VarTL.type;
         Varlimits= VarTL.limits;
         for j=1:n
            for k=1:m
               if (strcmpi(Vartype,'Int'))
                  fprintf(FH,'    Element(%d,%d)=%d\n',j,k,var(j,k));
               elseif (strcmpi(Vartype,'Real'))
                  fprintf(FH,'    Element(%d,%d)=%g\n',j,k,var(j,k));
               elseif (strcmpi(Vartype,'Cplx'))
                  if (Varlimits(5)==0)
                     fprintf(FH,'    Element(%d,%d)=[%g,%g]\n',j,k,abs(var(j,k)),...
                        atan2(imag(var(j,k)),real(var(j,k))));
                  else
                     fprintf(FH,'    Element(%d,%d)=[%g,%g]\n',j,k,...
                        real(var(j,k)),imag(var(j,k)));
                  end
               end
            end
         end
      end
      
      fclose(FH);
      
   end
end
