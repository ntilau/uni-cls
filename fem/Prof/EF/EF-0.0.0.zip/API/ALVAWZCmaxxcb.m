%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%LICENCE
% Experiment Framework
% Copyright (C) 2001-2002-2003  Stefano Selleri
%
%This program is free software; you can redistribute it and/or
%modify it under the terms of the GNU General Public License
%as published by the Free Software Foundation; either version 2
%of the License, or (at your option) any later version.
%
%This program is distributed in the hope that it will be useful,
%but WITHOUT ANY WARRANTY; without even the implied warranty of
%MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%GNU General Public License for more details.
%
%You should have received a copy of the GNU General Public License
%along with this program; if not, write to the Free Software
%Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Ambiente Laboratorio Virtuale
%
function ALVAWZCmaxxcb
%
% Crea un grafico zoomabile intelligente
%
% 03-07-2001 Stefano Selleri
% Versione 00.00.00
%
% Ref: WN-A
%
global ScrollMinX;
global ScrollMaxX;
global AxesHandler;
global AxesLimits;

MinX=get(ScrollMinX,'Value')
MaxX=get(ScrollMaxX,'Value')

if (MinX>=MaxX) 
    if (MaxX>=0.01)
        MinX=MaxX-.01;
        set(ScrollMinX,'Value',MinX);
    else
        MinX=MaxX;
        set(ScrollMinX,'Value',MinX);
        MaxX=MaxX+.01;
        set(ScrollMaxX,'Value',MaxX);
    end
end

newmin = MinX*(AxesLimits(2)-AxesLimits(1))+AxesLimits(1);
newmax = MaxX*(AxesLimits(2)-AxesLimits(1))+AxesLimits(1);

set(AxesHandler,'Xlim',[newmin newmax]);
    

