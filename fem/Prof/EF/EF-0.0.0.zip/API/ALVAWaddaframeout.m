%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%LICENCE
% Experiment Framework
% Copyright (C) 2001-2002-2003  Stefano Selleri
%
%This program is free software; you can redistribute it and/or
%modify it under the terms of the GNU General Public License
%as published by the Free Software Foundation; either version 2
%of the License, or (at your option) any later version.
%
%This program is distributed in the hope that it will be useful,
%but WITHOUT ANY WARRANTY; without even the implied warranty of
%MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%GNU General Public License for more details.
%
%You should have received a copy of the GNU General Public License
%along with this program; if not, write to the Free Software
%Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Ambiente Laboratorio Virtuale
%
function [Bi,Li]=ALVAWaddaframeout(Window,M,FrameHeight,FrameWidth,LabelWidth,BoxWidth,...
   Xposition,Yposition,Varlabel,Varvalue,Vartype,Varlimits);
%
% Piazza un frame di input
%
% 20-06-2001 Stefano Selleri
% Versione 00.00.00
%
% Ref: WN-A
%
[n,m]=size(Varvalue);
% cornicina
if (n*m>1 & (n==1 | m==1))
   nn = ceil(max(n,m)/M);
   mm = M;
else
   nn=n;
   mm=m;
end
Wframe1=uicontrol(Window,'Style','frame','BackgroundColor',[0.8,0.8,0.8],...
   'Position',[Xposition+1,Yposition-FrameHeight*(nn-1),FrameWidth*mm-1,FrameHeight*nn-1]);

idiesis=findstr('#',Varlabel);
for i=1:n
   for j=1:m
      ThisLabel=Varlabel;
      if (idiesis>0)
         if (n==1 | m==1)
            % E' un vettore
            if (n>m)
               idx = num2str(i);
            else
               idx = num2str(j);
            end
         else
            % E' un maritozzo
            idx = strcat('(',num2str(i),',',num2str(j),')');
         end
         ThisLabel=[Varlabel(1:idiesis-1) ' ' idx ' ' ...
               Varlabel(idiesis+1:length(Varlabel))];
      end
      if (strcmpi(Vartype,'Cplx'))   
         % E' un complesso
         if (Varlimits(5)==0)
            suffix = ' (M,F)';
         else
            suffix = ' (R,I)';
         end
         ThisLabel = [ThisLabel suffix];
      end
      
      if (n*m>1 & (n==1 | m==1))
         idx=max(i,j);
         ii=ceil(idx/M);
         jj=idx-(ii-1)*M;
      else
         ii=i;
         jj=j;
      end
      Wlabel=uicontrol(Window,'Style','text','String',ThisLabel,...
         'Position',[Xposition+2+(jj-1)*FrameWidth,Yposition+1-(ii-1)*FrameHeight,...
            LabelWidth,FrameHeight-8],'HorizontalAlignment','right',...
         'BackgroundColor',[0.8,0.8,0.8]);
      
      if (strcmpi(Vartype,'Cplx'))   
         Wlabel2=uicontrol(Window,'Style','text','String','(',...
            'Position',[Xposition+2+(jj-1)*FrameWidth+LabelWidth,...
               Yposition+1-(ii-1)*FrameHeight,...
               5,FrameHeight-8],'HorizontalAlignment','right',...
            'BackgroundColor',[0.8,0.8,0.8]);
         Wlabel2=uicontrol(Window,'Style','text','String',',',...
            'Position',[Xposition+2+(jj-1)*FrameWidth+LabelWidth+BoxWidth/2-5,...
               Yposition+1-(ii-1)*FrameHeight,...
               5,FrameHeight-8],'HorizontalAlignment','right',...
            'BackgroundColor',[0.8,0.8,0.8]);
         Wlabel2=uicontrol(Window,'Style','text','String',')',...
            'Position',[Xposition+2+(jj-1)*FrameWidth+LabelWidth+BoxWidth-5,...
               Yposition+1-(ii-1)*FrameHeight,...
               5,FrameHeight-8],'HorizontalAlignment','right',...
            'BackgroundColor',[0.8,0.8,0.8]);
         if (Varlimits(5)==0)
            v1 = abs(Varvalue(i,j));
            v2 = atan2(imag(Varvalue(i,j)),real(Varvalue(i,j)));
         else
            v1 = real(Varvalue(i,j));
            v2 = imag(Varvalue(i,j));
         end
         Bt.m=uicontrol(Window,'Style','text','String',v1,...
            'Position',[Xposition+8+(jj-1)*FrameWidth+LabelWidth,...
               Yposition+1-(ii-1)*FrameHeight,BoxWidth/2-8,FrameHeight-8],...
            'HorizontalAlignment','left','BackgroundColor',[0.8,0.8,0.8]);
         Bt.f=uicontrol(Window,'Style','text','String',v2,...
            'Position',[Xposition+5+(jj-1)*FrameWidth+LabelWidth+BoxWidth/2,...
               Yposition+1-(ii-1)*FrameHeight,BoxWidth/2-5,FrameHeight-8],...
            'HorizontalAlignment','left','BackgroundColor',[0.8,0.8,0.8]);
      else
         Bt=uicontrol(Window,'Style','text','String',Varvalue(i,j),...
            'Position',[Xposition+8+(jj-1)*FrameWidth+LabelWidth,...
               Yposition+1-(ii-1)*FrameHeight,BoxWidth,FrameHeight-8],...
            'HorizontalAlignment','left','BackgroundColor',[.8,.8,.8]);

      end
      
      if (n*m>1 & (n==1 | m==1))
         idx=max(i,j);
         Bi(idx)=Bt;
         Li(idx)=Wlabel;
      else
         Bi(i,j)=Bt;
         Li(i,j)=Wlabel;
      end
   end
end
