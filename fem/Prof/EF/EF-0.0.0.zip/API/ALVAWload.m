%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%LICENCE
% Experiment Framework
% Copyright (C) 2001-2002-2003  Stefano Selleri
%
%This program is free software; you can redistribute it and/or
%modify it under the terms of the GNU General Public License
%as published by the Free Software Foundation; either version 2
%of the License, or (at your option) any later version.
%
%This program is distributed in the hope that it will be useful,
%but WITHOUT ANY WARRANTY; without even the implied warranty of
%MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%GNU General Public License for more details.
%
%You should have received a copy of the GNU General Public License
%along with this program; if not, write to the Free Software
%Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Ambiente Laboratorio Virtuale
%
function ALVAWload()
%
% Effettua il Salvataggio Dati
%
% 14-06-2001 Stefano Selleri
% Versione 00.00.00
%
% Ref: WN-A
%
%
global ALVrcItems;
global AppletData;
global AppletDataTL;
global ChDir;
global ExDir;

Dd = dir(strcat(ExDir,'/*.ad'));

cfiles={Dd.name};

selected = listdlg('PromptString',ALVrcItems.AWLabelFileSelect,'SelectionMode','Single',...
   'OKString',ALVrcItems.AWButtonOK,'CancelString',ALVrcItems.AWButtonCancel,...
   'ListString',cfiles);

if (selected)
   filename =  strcat(ExDir,'/',char(cfiles(selected)));
   FH = fopen(filename,'r');
   if (FH==-1)
      ALVwarning(ALVrcItems.AWMsgOpenError);
   else
      flag=0;
      head1c = '% ALV 0.0.0 Applet Data File';
      head2c = sprintf('%% Data for %s',ExDir);
      head1 = fgetl(FH);
      head2 = fgetl(FH);
      if (strcmpi(head1,head1c) & strcmpi(head2,head2c))
         fn = fieldnames(AppletData)
         ni = length(fn);
         for i=1:ni
            line = fgetl(FH);
            iequal = findstr('=',line);
            if (iequal) 
               tag   = line(1:iequal-1) ;
               value = line(iequal+1:length(line));
               % Gli spazi in testa e in coda non sono graditi
               tag   = ALVcrop(tag);
               value = ALVcrop(value);
               if (strcmpi(tag,'Variable'))
                  Varname = value;
                  line = fgetl(FH);
                  iequal = findstr('=',line);
                  if (iequal) 
                     tag   = line(1:iequal-1) ;
                     value = line(iequal+1:length(line));
                     % Gli spazi in testa e in coda non sono graditi
                     tag   = ALVcrop(tag);
                     value = ALVcrop(value);
                     if (strcmpi(tag,'Size'))
                        n=eval(value);
                        VarTL    = getfield(AppletDataTL,Varname);
                        Vartype  = VarTL.type;
                        Varlimits= VarTL.limits;
                        clear tmpvar;
                        for i=1:n(1)
                           for j=1:n(2)
                              if(strcmpi(Vartype,'Int'))
                                 line = fgetl(FH);
                                 iequal = findstr('=',line);
                                 if (iequal) 
                                    value = line(iequal+1:length(line));
                                    value = ALVcrop(value);
                                    tmpvar(i,j)=round(eval(value));
                                 else
                                    flag = 5
                                 end
                              elseif (strcmpi(Vartype,'Real'))
                                 line = fgetl(FH);
                                 iequal = findstr('=',line);
                                 if (iequal) 
                                    value = line(iequal+1:length(line));
                                    value = ALVcrop(value);
                                    tmpvar(i,j)=eval(value);
                                 else
                                    flag = 5
                                 end
                              else
                                 line = fgetl(FH);
                                 iequal = findstr('=',line);
                                 if (iequal) 
                                    value = line(iequal+1:length(line));
                                    value = ALVcrop(value);
                                    aux = eval(value); 
                                    if (Varlimits(5)==0)
                                       tmpvar(i,j)=aux(1)*exp(sqrt(-1)*aux(2));
                                    else
                                       tmpvar(i,j)=aux(1)+sqrt(-1)*aux(2);
                                    end
                                 end
                              end
                           end
                        end
                        AppletData = setfield(AppletData,Varname,tmpvar);
                     else
                        flag=1;
                     end
                  else
                     flag=2;
                  end
               else
                  flag=3;
               end
            else
               flag=4;
            end
         end
      end
      if (flag>0)
         flag
         ALVWarning('Errore');
      end
      fclose(FH);   
   end
end
