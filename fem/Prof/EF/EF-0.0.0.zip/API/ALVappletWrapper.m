%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%LICENCE
% Experiment Framework
% Copyright (C) 2001-2002-2003  Stefano Selleri
%
%This program is free software; you can redistribute it and/or
%modify it under the terms of the GNU General Public License
%as published by the Free Software Foundation; either version 2
%of the License, or (at your option) any later version.
%
%This program is distributed in the hope that it will be useful,
%but WITHOUT ANY WARRANTY; without even the implied warranty of
%MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%GNU General Public License for more details.
%
%You should have received a copy of the GNU General Public License
%along with this program; if not, write to the Free Software
%Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Ambiente Laboratorio Virtuale
%
function ALVappletWrapper(parent,directory,applet)
%
% Effettua la chiamata all'applet
%
% 14-06-2001 Stefano Selleri
% Versione 00.00.00
%
% Ref: WN-A
%
% Definizioni delle variabili globali all'applet
%
global ALVrcItems;
global Wtoolbar;
global Wapplet;
global AppletData;
global AppletDataTL;
global MaskData;
global HelpData;
global ButtonData;
global ChDir;
global ExDir;

ChDir = strcat(pwd,'\',parent);
ExDir = strcat(pwd,'\',parent,'/',directory);
addpath(ChDir,ExDir);

%
% Reads the ex.rc
%
ALVAWexrc;

scrsize  = get(0,'ScreenSize');
ToolWidth  = 150;
ToolHeight = scrsize(4)-250; 
if (ishandle(Wtoolbar)) 
   ALVwarning('C''� un''applet in esecuzione. Chiudere quella prima di lanciarne una nuova');
   return
end
Wtoolbar = figure('Name','ALS - Experiment Toolbar',...
   'Position',[15,150,ToolWidth,ToolHeight],...
   'MenuBar','none');
if (ishandle(Wapplet))
   close(Wapplet);
end
Wapplet = figure('Name','ALS - Experiment Window',...
   'Position',[230,150,ToolHeight,ToolHeight],...
   'MenuBar','none');

Bheight = 20;
Btop    = ToolHeight;
for i=1:length(MaskData);
   UserButton(i) = uicontrol(Wtoolbar,'Style','pushbutton',...
      'String',MaskData(i).Mask.Mask,'position',[1,Btop-Bheight*i,ToolWidth-2,Bheight],...
      'Callback',strcat('ALVAWinputMask(',num2str(i),')'));
end
for j=1:length(ButtonData)
   ButtonData(j).Button.Label;
   ExecButton = uicontrol(Wtoolbar,'Style','pushbutton',...
      'String',ButtonData(j).Button.Label,...
      'position',[1,Btop-Bheight*(i+1+j),ToolWidth-2,Bheight],...
      'Callback',strcat(ButtonData(j).Button.Command,'(',num2str(Wapplet),')'));
end

SaveButton = uicontrol(Wtoolbar,'Style','pushbutton',...
   'String',ALVrcItems.AWSaveLabel,'position',[1,Btop-Bheight*(i+j+3),ToolWidth-2,Bheight],...
   'Callback','ALVAWsave');
LoadButton = uicontrol(Wtoolbar,'Style','pushbutton',...
   'String',ALVrcItems.AWLoadLabel,'position',[1,Btop-Bheight*(i+j+4),ToolWidth-2,Bheight],...
   'Callback','ALVAWload');
HelpButton = uicontrol(Wtoolbar,'Style','pushbutton',...
   'String',ALVrcItems.AWHelpLabel,'position',[1,Btop-Bheight*(i+j+5),ToolWidth-2,Bheight],...
   'Callback','ALVAWhelp');
ExitButton = uicontrol(Wtoolbar,'Style','pushbutton',...
   'String',ALVrcItems.AWExitLabel,'position',[1,Btop-Bheight*(i+j+7),ToolWidth-2,Bheight],...
   'Callback',strcat('ALVAWclose(''',parent,''',''',strcat(parent,'/',directory),''')'));


