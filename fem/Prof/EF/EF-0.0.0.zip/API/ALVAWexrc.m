%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%LICENCE
% Experiment Framework
% Copyright (C) 2001-2002-2003  Stefano Selleri
%
%This program is free software; you can redistribute it and/or
%modify it under the terms of the GNU General Public License
%as published by the Free Software Foundation; either version 2
%of the License, or (at your option) any later version.
%
%This program is distributed in the hope that it will be useful,
%but WITHOUT ANY WARRANTY; without even the implied warranty of
%MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%GNU General Public License for more details.
%
%You should have received a copy of the GNU General Public License
%along with this program; if not, write to the Free Software
%Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Ambiente Laboratorio Virtuale
%
function ALVAWexrc()
%
% Effettua la lettura del file rc dell'applet
%
% 15-06-2001 Stefano Selleri
% Versione 00.00.00
%
% Ref: WN-A
%
% Definizioni delle variabili globali all'applet
%
global AppletData;
global AppletDataTL;
global MaskData;
global HelpData;
global ButtonData;
global ChDir;
global ExDir;

AppletData=struct('void','void');
AppletDataTL=struct('void','void');
MaskData=struct('void','void');
HelpData=struct('void','void');
ButtonData=struct('void','void');

FH = fopen(strcat(ExDir,'/ex.rc'),'rt');
if (FH<0) ALVerror('Unable to Open ex.rc file.'); end

i     = 1;
Dflag = 0;
im    = 0;
bt    = 0;
while(~feof(FH))
   line = fgetl(FH);
   % Stronca i commenti
   icomment = findstr('%',line);
   if ( icomment )
      line = line(1:icomment(1)-1);
   end
   %
   % Interpreta la struttura dati
   %
   if (Dflag==1)
      iequal = findstr('=',line);
      if (iequal) 
         tag   = line(1:iequal-1) ;
         value = line(iequal+1:length(line));
         % Gli spazi in testa e in coda non sono graditi
         tag   = ALVcrop(tag);
         value = ALVcrop(value);
         icolon = findstr(';',value);
         % divisione valore;tipo;limiti
         if (length(icolon)<2)
            ALVwarning('Riga Variable non conforme alle specifiche in ex.rc');
         else
            N = length(icolon);
            expr    = value(1:icolon(N-1)-1); 
            type     = value(icolon(N-1)+1:icolon(N)-1);
            limits   = value(icolon(N)+1:length(value));
            expr     = ALVcrop(expr);
            type     = ALVcrop(type);
            limits   = ALVcrop(limits);
            AppletData   = setfield(AppletData,tag,eval(expr));
            tmpds        = struct('type',type,'limits',eval(limits));
            AppletDataTL =setfield(AppletDataTL,tag,tmpds);
         end
      end
   end
   %
   % Interpreta le strutture maschera
   %
   if (Dflag==2)
      iequal = findstr('=',line);
      if (iequal) 
         tag   = line(1:iequal-1) ;
         value = line(iequal+1:length(line));
         % Gli spazi in testa e in coda non sono graditi
         tag   = ALVcrop(tag);
         value = ALVcrop(value);
         if (strcmpi(tag,'Mask')) 
            tmpMaskData.Mask=value;
         elseif (strcmpi(tag,'Title')) 
            tmpMaskData.Title=value;
         elseif (strcmpi(tag,'UserCallBack')) 
            tmpMaskData.UserCallBack=value;
         elseif (strcmpi(tag,'Variable')) 
            iv = iv+1;
            icolon = findstr(';',value);
            if (length(icolon)~=1)
               ALVwarning('Riga Variable non conforme alle specifiche in ex.rc');
            else
               label    = value(1:icolon(1)-1); 
               variable = value(icolon(1)+1:length(value));
               % Gli spazi in testa e in coda non sono graditi
               label    = ALVcrop(label);
               variable = ALVcrop(variable);
               Variables(iv) = struct('label',label,'variable',variable);
               tmpMaskData.Variable=Variables;
            end
         end
      end
   end
   %
   % Interpreta la maschera di aiuto
   %
   if (Dflag==3)
      iequal = findstr('=',line);
      if (iequal) 
         tag   = line(1:iequal-1);
         value = line(iequal+1:length(line));
         % Gli spazi in testa e in coda non sono graditi
         tag   = ALVcrop(tag);
         value = ALVcrop(value);
         if (strcmpi(tag,'Title')) 
            HelpData.Title=value;
         elseif (strcmpi(tag,'Line'))
            rets=findstr('\n',value);
            for i=1:length(rets)
               value(rets(i))=32;
               value(rets(i)+1)=13;
            end
            Text=[Text ' ' value];
         end
      end
   end
   %
   % Interpreta il Bottone di Esecuzione
   %
   if (Dflag==4)
      iequal = findstr('=',line);
      if (iequal) 
         tag   = line(1:iequal-1) ;
         value = line(iequal+1:length(line));
         % Gli spazi in testa e in coda non sono graditi
         tag   = ALVcrop(tag);
         value = ALVcrop(value);
         if (strcmpi(tag,'Label')) 
            tmpButtonData.Label=value;
         elseif (strcmpi(tag,'Command'))
            tmpButtonData.Command=value;
         end
      end  
   end
   %          
   % Toggle di stato
   %
   if (strcmpi(line,'Begin DataStruct'))
      Dflag=1;
   end
   if (strcmpi(line,'Begin InputMask'))
      Dflag = 2;
      im    = im+1;
      iv    = 0;
      clear Variables;
   end
   if (strcmpi(line,'Begin HelpMask'))
      Text=' ';
      Dflag = 3;
   end
   if (strcmpi(line,'Begin ExecButton'))
      Dflag = 4;
      bt    = bt+1;
      clear tmpButtonData;
   end
   if (strcmpi(line,'End DataStruct'))
      Dflag=0;
   end
   if (strcmpi(line,'End InputMask'))
      Dflag=0;
      MaskData(im).Mask=tmpMaskData;
   end
   if (strcmpi(line,'End HelpMask'))
      Dflag=0;
      HelpData.Text=Text;
   end
   if (strcmpi(line,'End ExecButton'))
      Dflag=0;
      ButtonData(bt).Button = tmpButtonData;
   end

end

fclose(FH); 
