%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%LICENCE
% Experiment Framework
% Copyright (C) 2001-2002-2003  Stefano Selleri
%
%This program is free software; you can redistribute it and/or
%modify it under the terms of the GNU General Public License
%as published by the Free Software Foundation; either version 2
%of the License, or (at your option) any later version.
%
%This program is distributed in the hope that it will be useful,
%but WITHOUT ANY WARRANTY; without even the implied warranty of
%MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%GNU General Public License for more details.
%
%You should have received a copy of the GNU General Public License
%along with this program; if not, write to the Free Software
%Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Ambiente Laboratorio Virtuale
%
function [newvalue]=ALVAWvalidateinput(oldvalue,proposedvalue,vartype,limits,label)
%
% Effettua la chiamata all'applet
%
% 22-06-2001 Stefano Selleri
% Versione 00.00.00
%
% Ref: WN-A
%
% Verifica gli imput
%

if (strcmpi(vartype,'Cplx'))
   % Caso complesso
   if (limits(5)==0)
      v1 = abs(proposedvalue);
      v2 = atan2(imag(proposedvalue),real(proposedvalue));
   else
      v1 = real(proposedvalue);
      v2 = imag(proposedvalue);
   end
   if (v1>=limits(1) & v1<=limits(2) & v2>=limits(3) & v2<=limits(4))
      newvalue = proposedvalue;
   else
      newvalue = oldvalue;
      ALVwarning (['Il valore (',num2str(v1),',',num2str(v2),') per "',label,...
            '" � al di fuori del range di valori accettati ([',...
               num2str(limits(1)),',',num2str(limits(2)),'],[',...
               num2str(limits(3)),',',num2str(limits(4)),'])']);

   end
elseif (strcmpi(vartype,'Real'))
   % Caso reale
   proposedvalue = real(proposedvalue);
   if (proposedvalue>=limits(1) & proposedvalue<=limits(2))
      newvalue = proposedvalue;
   else
      newvalue = oldvalue;
      ALVwarning (['Il valore ',num2str(proposedvalue),' per "',label,...
            '" � al di fuori del range di valori accettati [',...
            num2str(limits(1)),',',num2str(limits(2)),']']);
   end   
else
   % Caso intero
   proposedvalue = round(real(proposedvalue));
   if (proposedvalue>=limits(1) & proposedvalue<=limits(2))
      newvalue = proposedvalue;
   else
      newvalue = oldvalue;
      ALVwarning (['Il valore ',num2str(proposedvalue),' per "',label,...
            '" � al di fuori del range di valori accettati [',...
            num2str(limits(1)),',',num2str(limits(2)),']']);
   end
end

