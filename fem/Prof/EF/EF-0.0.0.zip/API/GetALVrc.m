%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%LICENCE
% Experiment Framework
% Copyright (C) 2001-2002-2003  Stefano Selleri
%
%This program is free software; you can redistribute it and/or
%modify it under the terms of the GNU General Public License
%as published by the Free Software Foundation; either version 2
%of the License, or (at your option) any later version.
%
%This program is distributed in the hope that it will be useful,
%but WITHOUT ANY WARRANTY; without even the implied warranty of
%MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%GNU General Public License for more details.
%
%You should have received a copy of the GNU General Public License
%along with this program; if not, write to the Free Software
%Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Ambiente Laboratorio Virtuale
%
function [ALVrcItems]=GetALVrc(filename)
%
% Accede a file .rc
%
% 13-06-2001 Stefano Selleri
% Versione 00.00.00
%
% Ref: WN-A
%

%
% Defaults
%
ALVrcItems=struct('FileMenu','File',...
   'ChapterMenu','Chapter',...
   'HelpMenu','Help',...
   'ExitLabel','Exit',...
   'HelpLabel','Help',...
   'AboutLabel','About',...
   'AWExitLabel','Exit',...
   'AWSaveLabel','Save',...
   'AWLoadLabel','Load',...
   'AWHelpLabel','Help',...
   'AWButtonOK','OK',...
   'AWButtonCancel','Cancel',...
   'AWButtonClose','Chiudi',...
   'AWLabelFileSelect','Select a File',...
   'AWLabelFileNew','Existing Files',...
   'AWLabelYes','Si',...
   'AWLabelNo','No',...
   'AWMsgOverwrite','Overwrite',...
   'AWMsgOpenError','Error opening file',...
   'AWMsgTypeError','File of wrong Type');

FH = fopen(filename,'rt');
if (FH<0) ALVerror('Unable to Open alv.rc file.'); end

while(~feof(FH))
   line = fgetl(FH);
   % Stronca i commenti
   icomment = findstr('%',line);
   if ( icomment )
      line = line(1:icomment(1)-1);
   end
   % Divide TAG da VALORE
   iequal = findstr('=',line);
   if (iequal) 
      tag   = line(1:iequal-1); 
      value = line(iequal+1:length(line));
      % Gli spazi in testa e in coda non sono graditi
      tag   = ALVcrop(tag);
      value = ALVcrop(value);
      % Interpretes TAG
      if (strcmpi('FileMenu',tag))
         ALVrcItems = setfield(ALVrcItems,'FileMenu',value);
      elseif (strcmpi('ChapterMenu',tag))
         ALVrcItems = setfield(ALVrcItems,'ChapterMenu',value);
      elseif (strcmpi('HelpMenu',tag))
         ALVrcItems = setfield(ALVrcItems,'HelpMenu',value);
      elseif (strcmpi('ExitLabel',tag))
         ALVrcItems = setfield(ALVrcItems,'ExitLabel',value);
      elseif (strcmpi('HelpLabel',tag))
         ALVrcItems = setfield(ALVrcItems,'HelpLabel',value);
      elseif (strcmpi('AboutLabel',tag))
         ALVrcItems = setfield(ALVrcItems,'AboutLabel',value);
      elseif (strcmpi('AWExitLabel',tag))
         ALVrcItems = setfield(ALVrcItems,'AWexitLabel',value);
      elseif (strcmpi('AWSaveLabel',tag))
         ALVrcItems = setfield(ALVrcItems,'AWSaveLabel',value);
      elseif (strcmpi('AWLoadLabel',tag))
         ALVrcItems = setfield(ALVrcItems,'AWLoadLabel',value);
      elseif (strcmpi('AWHelpLabel',tag))
         ALVrcItems = setfield(ALVrcItems,'AWHelpLabel',value);
      elseif (strcmpi('AWButtonOK',tag))
         ALVrcItems = setfield(ALVrcItems,'AWButtonOK',value);
      elseif (strcmpi('AWButtonCancel',tag))
         ALVrcItems = setfield(ALVrcItems,'AWButtonCancel',value);
      elseif (strcmpi('AWButtonClose',tag))
         ALVrcItems = setfield(ALVrcItems,'AWButtonClose',value);
      elseif (strcmpi('AWLabelFileSelect',tag))
         ALVrcItems = setfield(ALVrcItems,'AWLabelFileSelect',value);
      elseif (strcmpi('AWLabelFileNew',tag))
         ALVrcItems = setfield(ALVrcItems,'AWLabelFileNew',value);
      elseif (strcmpi('AWLabelYes',tag))
         ALVrcItems = setfield(ALVrcItems,'AWLabelYes',value);
      elseif (strcmpi('AWLabelNo',tag))
         ALVrcItems = setfield(ALVrcItems,'AWLabelNo',value);
      elseif (strcmpi('AWMsgOverwrite',tag))
         ALVrcItems = setfield(ALVrcItems,'AWMsgOverwrite',value);
      elseif (strcmpi('AWMsgOpenError',tag))
         ALVrcItems = setfield(ALVrcItems,'AWMsgOpenError',value);
      elseif (strcmpi('AWMsgTypeError',tag))
         ALVrcItems = setfield(ALVrcItems,'AWMsgTypeError',value);
      else
         ALVwarning(strcat('Tag sconosciuto in ',filename));
      end
   end
end;

fclose(FH);
   
      
