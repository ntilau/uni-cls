%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%LICENCE
% Experiment Framework
% Copyright (C) 2001-2002-2003  Stefano Selleri
%
%This program is free software; you can redistribute it and/or
%modify it under the terms of the GNU General Public License
%as published by the Free Software Foundation; either version 2
%of the License, or (at your option) any later version.
%
%This program is distributed in the hope that it will be useful,
%but WITHOUT ANY WARRANTY; without even the implied warranty of
%MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%GNU General Public License for more details.
%
%You should have received a copy of the GNU General Public License
%along with this program; if not, write to the Free Software
%Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Ambiente Laboratorio Virtuale
%
function ALVAWoutputMask(Title,Variables)
%
% Apre una finestra di input su alcuni dati
%
% 15-06-2001 Stefano Selleri
% Versione 00.00.00
%
% Ref: WN-A
%
% Maschera di Help
%
global ALVrcItems;
global AppletData;
global AppletDataTL;
global BoxIds;
global LabelIds;
%
% Dimensioni topiche
%
FrameWidth  = 250;
FrameHeight = 27;
LabelWidth  = 120;
BoxWidth    = 120;

% Dimensioni "naturali" della maschera

Nscal  = 0;
Nvec   = 0;
LenVec = [];
Nmat   = 0;
DimMat = [];

for i=1:length(Variables)
   Varname  = Variables(i).variable;
   Varvalue = getfield(AppletData,Varname);
   [n,m]    = size(Varvalue);
   if (n==1 & m==1)
      Nscal = Nscal + 1;
   elseif (n==1 | m==1)
      Nvec = Nvec + 1;
      LenVec(Nvec)=max(n,m);
   else
      Nmat = Nmat+1;
      DimMat(Nmat,1)=n;
      DimMat(Nmat,2)=m;
   end
end

[N,M]=ALVAWsquarify(Nscal,Nvec,LenVec,Nmat,DimMat);
DialogHeight = FrameHeight * N + 30 + 23;
DialogWidth  = FrameWidth * M;

scrsize  = get(0,'ScreenSize');
Wim = figure('Name','ALS - Experiment Outputs',...
   'Position',[(scrsize(3)-DialogWidth)/2,(scrsize(4)-DialogHeight)/2,...
      DialogWidth,DialogHeight],'MenuBar','none','WindowStyle','modal',...
   'Color',[0.8,0.8,0.8]);
WTitle = uicontrol(Wim,'Style','text','String',Title,...
   'Position',[1,DialogHeight-30,DialogWidth,30],'FontSize',18,...
   'BackgroundColor',[0.8,0.8,0.8]);

% First all SCALARS
irow=1;
icol=1;
for i=1:length(Variables)
   Varlabel = Variables(i).label;
   Varname  = Variables(i).variable;
   VarTL    = getfield(AppletDataTL,Varname);
   Vartype  = VarTL.type;
   Varlimits= VarTL.limits;
   Varvalue = getfield(AppletData,Varname);
   [n,m]    = size(Varvalue);
   if (n==1 & m==1)
      [Bt,Lt]=ALVAWaddaframeout(Wim,M,FrameHeight,FrameWidth,LabelWidth,BoxWidth,...
         FrameWidth*(icol-1),DialogHeight-30-irow*FrameHeight,...
         Varlabel,Varvalue,Vartype,Varlimits);
      icol = icol+1;
      BoxIds(i).Handle=Bt;
      LabelIds(i).Handle=Lt;
      if (icol>M)
         icol=icol-M;
         irow=irow+1;
      end
   end
end
      
% Then Arrays
icol=1;
for i=1:length(Variables)
   Varlabel = Variables(i).label;
   Varname  = Variables(i).variable;
   VarTL    = getfield(AppletDataTL,Varname);
   Vartype  = VarTL.type;
   Varlimits= VarTL.limits;
   Varvalue = getfield(AppletData,Varname);
   [n,m]    = size(Varvalue);
   if (n*m>1 & (n==1 | m==1))
      [Bt,Lt]=ALVAWaddaframeout(Wim,M,FrameHeight,FrameWidth,LabelWidth,BoxWidth,...
         FrameWidth*(icol-1),DialogHeight-30-irow*FrameHeight,...
         Varlabel,Varvalue,Vartype,Varlimits);
      irow = irow+ceil(max(n,m)/M);
      BoxIds(i).Handle=Bt;
      LabelIds(i).Handle=Lt;
   end
end
      
% Last Matrices
icol=1;
for i=1:length(Variables)
   Varlabel = Variables(i).label;
   Varname  = Variables(i).variable;
   VarTL    = getfield(AppletDataTL,Varname);
   Vartype  = VarTL.type;
   Varlimits= VarTL.limits;
   Varvalue = getfield(AppletData,Varname);
   [n,m]    = size(Varvalue);
   if (n>1 & m>1)
      [Bt,Lt]=ALVAWaddaframeout(Wim,M,FrameHeight,FrameWidth,LabelWidth,BoxWidth,...
         FrameWidth*(icol-1),DialogHeight-30-irow*FrameHeight,...
         Varlabel,Varvalue,Vartype,Varlimits);
      irow = irow+ceil(max(n,m)/M);
      BoxIds(i).Handle = Bt;
      LabelIds(i).Handle = Lt;
   end
end

% At last buttons
Cancelcb = strcat('close(',num2str(Wim),')');
Wcancel = uicontrol(Wim,'Style','pushbutton','String',ALVrcItems.AWButtonClose,...
   'Position',[1,1,DialogWidth,20],'Callback',Cancelcb);

