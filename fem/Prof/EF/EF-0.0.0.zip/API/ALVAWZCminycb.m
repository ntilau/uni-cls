%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%LICENCE
% Experiment Framework
% Copyright (C) 2001-2002-2003  Stefano Selleri
%
%This program is free software; you can redistribute it and/or
%modify it under the terms of the GNU General Public License
%as published by the Free Software Foundation; either version 2
%of the License, or (at your option) any later version.
%
%This program is distributed in the hope that it will be useful,
%but WITHOUT ANY WARRANTY; without even the implied warranty of
%MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%GNU General Public License for more details.
%
%You should have received a copy of the GNU General Public License
%along with this program; if not, write to the Free Software
%Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Ambiente Laboratorio Virtuale
%
function ALVAWZCminycb
%
% Crea un grafico zoomabile intelligente
%
% 03-07-2001 Stefano Selleri
% Versione 00.00.00
%
% Ref: WN-A
%
global ScrollMinY;
global ScrollMaxY;
global AxesHandler;
global AxesLimits;

MinY=get(ScrollMinY,'Value')
MaxY=get(ScrollMaxY,'Value')

if (MinY>=MaxY) 
    if (MinY<=.99)
        MaxY=MinY+.01;
        set(ScrollMaxY,'Value',MaxY);
    else
        MaxY=MinY;
        set(ScrollMaxY,'Value',MaxY);
        MinY=MinY-.01;
        set(ScrollMinY,'Value',MinY);
    end
end

newmin = MinY*(AxesLimits(4)-AxesLimits(3))+AxesLimits(3);
newmax = MaxY*(AxesLimits(4)-AxesLimits(3))+AxesLimits(3);

set(AxesHandler,'Ylim',[newmin newmax]);
    

