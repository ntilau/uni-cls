%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%LICENCE
% Experiment Framework
% Copyright (C) 2001-2002-2003  Stefano Selleri
%
%This program is free software; you can redistribute it and/or
%modify it under the terms of the GNU General Public License
%as published by the Free Software Foundation; either version 2
%of the License, or (at your option) any later version.
%
%This program is distributed in the hope that it will be useful,
%but WITHOUT ANY WARRANTY; without even the implied warranty of
%MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%GNU General Public License for more details.
%
%You should have received a copy of the GNU General Public License
%along with this program; if not, write to the Free Software
%Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% AmBoxIdsente Laboratorio Virtuale
%
function ALVAWsetinput(idx)
%
% Effettua la chiamata all'applet
%
% 15-06-2001 Stefano Selleri
% Versione 00.00.00
%
% Ref: WN-A
%
% Maschera di Help
%
global AppletData;
global AppletDataTL;
global MaskData;
global BoxIds;
global LabelIds;

ThisMaskData=MaskData(idx).Mask;
Variables = ThisMaskData.Variable;

for ii=1:length(Variables)
   Varlabel = Variables(ii).label;
   Varname  = Variables(ii).variable;
   VarTL    = getfield(AppletDataTL,Varname);
   Vartype  = VarTL.type;
   Varlimits= VarTL.limits;
   Varvalue = getfield(AppletData,Varname);
   [n,m]    = size(Varvalue);
   Handle   = BoxIds(ii).Handle;
   LHandle  = LabelIds(ii).Handle;
   
   for i=1:n
      for j=1:m
         if (n*m>1 & (n==1 | m==1))
            jj=max(i,j);
            if (strcmpi(Vartype,'Cplx'))
               % Complesso
               v1 = str2num(get(Handle(jj).m,'String'));
               v2 = str2num(get(Handle(jj).f,'String'));
               if (Varlimits(5)==0)
                  value = v1*exp(sqrt(-1)*v2);
               else
                  value = v1+sqrt(-1)*v2;
               end
               label = get(LHandle(jj),'String');
               Varvalue(jj) = ALVAWvalidateinput(Varvalue(jj),value,...
                  Vartype,Varlimits,label);
            else
               % Non complesso
               value = str2num(get(Handle(jj),'String'));
               label = get(LHandle(jj),'String');
               Varvalue(jj) = ALVAWvalidateinput(Varvalue(jj),value,...
                  Vartype,Varlimits,label);
            end
         else
            if (strcmpi(Vartype,'Cplx'))
               % Complesso
               v1 = str2num(get(Handle(i,j).m,'String'));
               v2 = str2num(get(Handle(i,j).f,'String'));
               if (Varlimits(5)==0)
                  value = v1*exp(sqrt(-1)*v2);
               else
                  value = v1+sqrt(-1)*v2;
               end
               label = get(LHandle(i,j),'String');
               Varvalue(i,j) = ALVAWvalidateinput(Varvalue(i,j),value,...
                  Vartype,Varlimits,label);
            else
               % Non complesso
               value = str2num(get(Handle(i,j),'String'));
               label = get(LHandle(i,j),'String');
               Varvalue(i,j) = ALVAWvalidateinput(Varvalue(i,j),value,...
                  Vartype,Varlimits,label);
            end
         end
      end
   end
   AppletData = setfield(AppletData,Varname,Varvalue);
end
