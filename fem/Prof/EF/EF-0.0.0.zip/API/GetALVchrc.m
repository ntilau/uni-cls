%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%LICENCE
% Experiment Framework
% Copyright (C) 2001-2002-2003  Stefano Selleri
%
%This program is free software; you can redistribute it and/or
%modify it under the terms of the GNU General Public License
%as published by the Free Software Foundation; either version 2
%of the License, or (at your option) any later version.
%
%This program is distributed in the hope that it will be useful,
%but WITHOUT ANY WARRANTY; without even the implied warranty of
%MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%GNU General Public License for more details.
%
%You should have received a copy of the GNU General Public License
%along with this program; if not, write to the Free Software
%Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Ambiente Laboratorio Virtuale
%
function [chapterlabel,ALVchrc]=GetALVchrc(chapterstruct)
%
% Accede a file .rc del Capitolo
%
% 13-06-2001 Stefano Selleri
% Versione 00.00.00
%
% Ref: WN-A
%

%
% Defaults
%
chapterlabel='void';
AlvChrc=struct('void','void');
dirname = getfield(chapterstruct,'name');

FH = fopen(strcat(dirname,'/ch.rc'),'rt');
if (FH<0) ALVerror('Unable to Open ch.rc file.'); end

i = 1;
while(~feof(FH))
   line = fgetl(FH);
   % Stronca i commenti
   icomment = findstr('%',line);
   if ( icomment )
      line = line(1:icomment(1)-1);
   end
   % Divide TAG da VALORE
   iequal = findstr('=',line);
   if (iequal) 
      tag   = line(1:iequal-1); 
      value = line(iequal+1:length(line));
      % Gli spazi in testa e in coda non sono graditi
      tag   = ALVcrop(tag);
      value = ALVcrop(value);
      if (strcmpi('ChapterLabel',tag))
         chapterlabel = value;
      elseif (strcmpi('Experiment',tag))
         icolon = findstr(';',value);
         if (length(icolon)~=1)
            ALVwarning('Riga non conforme alle specifiche in ch.rc');
         else
            label = value(1:icolon(1)-1); 
            direc = value(icolon(1)+1:length(value));
            % Gli spazi in testa e in coda non sono graditi
            label = ALVcrop(label);
            direc = ALVcrop(direc);
            ALVchrc(i) = struct('label',label,'dir',direc);
            i = i+1;
         end
      end
   end
end
fclose(FH);

      
