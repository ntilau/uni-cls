%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%LICENCE
% Experiment Framework
% Copyright (C) 2001-2002-2003  Stefano Selleri
%
%This program is free software; you can redistribute it and/or
%modify it under the terms of the GNU General Public License
%as published by the Free Software Foundation; either version 2
%of the License, or (at your option) any later version.
%
%This program is distributed in the hope that it will be useful,
%but WITHOUT ANY WARRANTY; without even the implied warranty of
%MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%GNU General Public License for more details.
%
%You should have received a copy of the GNU General Public License
%along with this program; if not, write to the Free Software
%Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Ambiente Laboratorio Virtuale
%
function [AxesHandler]=ALVAWzoomcart(parent,Xlab,Ylab,Limits)
%
% Crea un grafico zoomabile intelligente
%
% 03-07-2001 Stefano Selleri
% Versione 00.00.00
%
% Ref: WN-A
%
global ScrollMinX;
global ScrollMaxX;
global ScrollMinY;
global ScrollMaxY;
global AxesHandler;
global AxesLimits;

figure(parent);
if (exist('AxesHandler') & ishandle(AxesHandler))
    axes(AxesHandler);
else
    AxesLimits=Limits;
    Wdim = get(parent,'Position');
    % X
    ScrollMinX = uicontrol(parent,'Style','slider',...
        'Position',[32 1 Wdim(3)-72 16],'Min',0,'Max',1,...
        'Callback','ALVAWZCminxcb','Value',0);
    SMinXLab = uicontrol(parent,'Style','text','BackgroundColor',[0.8,0.8,0.8],...
        'Position',[Wdim(3)-40 1 40 16],'String','Min X');
    ScrollMaxX = uicontrol(parent,'Style','slider',...
        'Position',[32 17 Wdim(3)-72 16],'Min',0,'Max',1,...
        'Callback','ALVAWZCmaxxcb','Value',1);
    SMaxXLab = uicontrol(parent,'Style','text','BackgroundColor',[0.8,0.8,0.8],...
        'Position',[Wdim(3)-40 17 40 16],'String','Max X');
    % Y
    ScrollMinY = uicontrol(parent,'Style','slider',...
        'Position',[1 32 16 Wdim(4)-92],'Min',0,'Max',1,...
        'Callback','ALVAWZCminycb','Value',0);
    SMinYLab = uicontrol(parent,'Style','text','BackgroundColor',[0.8,0.8,0.8],...
        'Position',[1 Wdim(4)-60 16 60],'String','M   i   n  Y');
    ScrollMaxY = uicontrol(parent,'Style','slider',...
        'Position',[17 32 16 Wdim(4)-92 ],'Min',0,'Max',1,...
        'Callback','ALVAWZCmaxycb','Value',1);
    SMaxYLab = uicontrol(parent,'Style','text','BackgroundColor',[0.8,0.8,0.8],...
        'Position',[17 Wdim(4)-60 16 60],'String','M  a  x  Y');
    
    YGridButton = uicontrol(parent,'Style','pushbutton',...
        'Position',[63 Wdim(4)-30 50 20],...
        'String','Y Grid','Callback','ALVAWZCgridy');
    
    XGridButton = uicontrol(parent,'Style','pushbutton',...
        'Position',[113 Wdim(4)-30 50 20],...
        'String','X Grid','Callback','ALVAWZCgridx');
        
    ClearButton = uicontrol(parent,'Style','pushbutton',...
        'Position',[213 Wdim(4)-30 50 20],...
        'String','Clear','Callback','ALVAWZCclear');

    figure(parent);
    AxesHandler = axes('Position',...
        [83/Wdim(3),73/Wdim(4),(Wdim(3)-123)/Wdim(3),(Wdim(4)-113)/Wdim(4)],...
        'Xlim',[AxesLimits(1),AxesLimits(2)],...
        'XlimMode','manual',...
        'Ylim',[AxesLimits(3),AxesLimits(4)],...
        'YlimMode','manual',...
        'NextPlot','add');
    set(AxesHandler,'Xlabel',text('String',Xlab));
    set(AxesHandler,'Ylabel',text('String',Ylab));
    axis(axis);
end

return
