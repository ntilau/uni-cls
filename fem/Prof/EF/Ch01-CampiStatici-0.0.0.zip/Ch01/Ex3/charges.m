%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%LICENCE
% Experiment Framework
% Copyright (C) 2001-2002-2003  Stefano Selleri
%
%This program is free software; you can redistribute it and/or
%modify it under the terms of the GNU General Public License
%as published by the Free Software Foundation; either version 2
%of the License, or (at your option) any later version.
%
%This program is distributed in the hope that it will be useful,
%but WITHOUT ANY WARRANTY; without even the implied warranty of
%MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%GNU General Public License for more details.
%
%You should have received a copy of the GNU General Public License
%along with this program; if not, write to the Free Software
%Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function charges (WH)
%
% Risolve Nabla^2f = 0 
% in un box quadrato di lato 1 
% con le differenze finite su NxN punti
% con un buco centrale di MxM punti e f=1 
% dentro f=0 fuori
%
% (C) Feb. 2003 Stefano Selleri
%
global AppletData

N = AppletData.N;

d = 1/(N-1);

% Crea il sistema

for i=1:N
    for j=1:N
        idx = (j-1)*N + i;
        %diagonale
        A(idx,idx) = 1;
        % elemento i-1
        if (i-1>0)
            A(idx,idx-1) = -1/4;
        end;
        % elemento i+1
        if (i<N)
            A(idx,idx+1) = -1/4;
        end;
        % elemento j-1
        if (j-1>0)
            A(idx,idx-N) = -1/4;
        end;
        % elemento j+1
        if (j<N)
            A(idx,idx+N) = -1/4;
        end;
    end;
end;

% CaC
%
% Impone potenziale fisso pari a 0 sul conduttore esterno
%
b = zeros(N*N,1);
for i=1:N
    idx = i;
    A(idx,:)=zeros(1,N*N);
    A(idx,idx)=1;
    idx = (N-1)*N+i;
    A(idx,:)=zeros(1,N*N);
    A(idx,idx)=1;
end;

for j=1:N
    idx = (j-1)*N+1;
    A(idx,:)=zeros(1,N*N);
    A(idx,idx)=1;
    idx = (j-1)*N+N;
    A(idx,:)=zeros(1,N*N);
    A(idx,idx)=1;
end;


%
% Impone potenziale fisso pari a q nei punti topici
%
CN = AppletData.CN
Cx = AppletData.Cx;
Cy = AppletData.Cy;
Cq = AppletData.Cq;
for i=1:CN;
    ii = round(Cx(i)*N);
    ij = round(Cy(i)*N);
    idx = (ij-1)*N+ii;
    A(idx,:)=zeros(1,N*N);
    A(idx,idx)=1;
    b(idx)=Cq(i);
end;

f = inv(A)*b;

for i=1:N
    for j=1:N
        idx = (j-1)*N + i;
        x(i,j) = (i-1)/(N-1);
        y(i,j) = (j-1)/(N-1);
        z(i,j) = f(idx);
    end;
end;

f = inv(A)*b;

for i=1:N
    for j=1:N
        idx = (j-1)*N + i;
        x(i,j) = (i-1)/(N-1);
        y(i,j) = (j-1)/(N-1);
        z(i,j) = f(idx);
    end;
end;

qu = 0.*z;
qv = 0.*z;
for i=2:N-1
    for j=2:N-1
        idx0 = (j-1)*N + i;
        idx1 = idx0+1;
        idx2 = idx0+N;
        idx3 = idx0-1;
        idx4 = idx0-N;
        qu(i,j) = f(idx1)-f(idx3);
        qv(i,j) = f(idx2)-f(idx4);
    end;
end;
AH = ALVAWzoomcart(WH,'x',...
    'y',[0,1,0,1]);
contour(x,y,z);
quiver(x,y,qu,qv);
axis('equal');
axis('square');

set(gca,'xtick',[0,.25,.5,.75,1]);
set(gca,'ytick',[0,.25,.5,.75,1]);