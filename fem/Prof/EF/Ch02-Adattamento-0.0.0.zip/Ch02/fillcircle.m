%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%LICENCE
% Experiment Framework
% Copyright (C) 2001-2002-2003-2004  Stefano Selleri
%
%This program is free software; you can redistribute it and/or
%modify it under the terms of the GNU General Public License
%as published by the Free Software Foundation; either version 2
%of the License, or (at your option) any later version.
%
%This program is distributed in the hope that it will be useful,
%but WITHOUT ANY WARRANTY; without even the implied warranty of
%MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%GNU General Public License for more details.
%
%You should have received a copy of the GNU General Public License
%along with this program; if not, write to the Free Software
%Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Smith
%
function fillcircle(xc,yc,r,N,col,w)
%
% Uso:
%
%     fillcircle(xc,yc,r,N,col,w);
%
% Disegna e campisce un cerchio di centro (xc,yc)
% e raggio r p in N segmenti.
%
% Linee di colore col e spessore w
%
% (C) 2002 Stefano Selleri
%


for i=0:N
    phi    = 2*pi*i/N;
    x(i+1) = xc + r*cos(phi);
    y(i+1) = yc + r*sin(phi);
end;

line (x,y,'Color',col,'LineWidth',w);

for i=0:50;
    xa = 2*r*i/50-r;
    ya = sqrt(r^2-xa^2);

    x1 = xa/sqrt(2)-ya/sqrt(2);
    y1 = xa/sqrt(2)+ya/sqrt(2);

    x2 = xa/sqrt(2)+ya/sqrt(2);
    y2 = xa/sqrt(2)-ya/sqrt(2);

    line([x1+xc,x2+xc],[y1+yc,y2+yc],'Color',col,'LineWidth',1);
    
end
