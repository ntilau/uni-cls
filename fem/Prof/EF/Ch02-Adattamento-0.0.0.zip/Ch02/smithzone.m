%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%LICENCE
% Experiment Framework
% Copyright (C) 2001-2002-2003-2004  Stefano Selleri
%
%This program is free software; you can redistribute it and/or
%modify it under the terms of the GNU General Public License
%as published by the Free Software Foundation; either version 2
%of the License, or (at your option) any later version.
%
%This program is distributed in the hope that it will be useful,
%but WITHOUT ANY WARRANTY; without even the implied warranty of
%MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%GNU General Public License for more details.
%
%You should have received a copy of the GNU General Public License
%along with this program; if not, write to the Free Software
%Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Smith
%
function smithzone(V,Vmax)
%
%
% Uso:
%
%    smithzone(V,Vmax)
%
% Disegna i cerchi r=V e x=+V,-V
% Non avvicinandosi alla singolarit�
% nel tracciare le linee pi� di
% Vmax
%
% (C) 2002 Stefano Selleri
%

xc = V/(1+V);
yc = 0;
rd = 1/(1+V);
if (Vmax==0)
    circle(xc,yc,rd,0,2*pi,120,[0.5,0.5,0.5],1);
else
    xb  = (-1+V^2+Vmax^2)/(1+2*V+V^2+Vmax^2);
    yb  = 2*Vmax/(1+2*V+V^2+Vmax^2);
    phi = atan2(yb-yc,xb-xc);
    circle(xc,yc,rd,phi,2*pi-phi,120,[0.5,0.5,0.5],1);
end;

if (V>0)
    xc = 1;
    yc = 1/V;
    rd = 1/V;
    if (Vmax==0)
        circle(xc,yc,rd,3*pi/2 - 2*atan(V),3*pi/2,120,[0.5,0.5,0.5],1);
        circle(xc,-yc,rd,pi/2,pi/2 + 2*atan(V),120,[0.5,0.5,0.5],1);
    else
        xb  = (-1+Vmax^2+V^2)/(1+2*Vmax+Vmax^2+V^2);
        yb  = 2*V/(1+2*Vmax+Vmax^2+V^2);
        phi = atan2(yb-yc,xb-xc);
        circle(xc,yc,rd,3*pi/2 - 2*atan(V),2*pi+phi,120,[0.5,0.5,0.5],1);
        circle(xc,-yc,rd,-phi,pi/2 + 2*atan(V),120,[0.5,0.5,0.5],1); 
    end;
end;