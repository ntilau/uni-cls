%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%LICENCE
% Experiment Framework
% Copyright (C) 2001-2002-2003-2004  Stefano Selleri
%
%This program is free software; you can redistribute it and/or
%modify it under the terms of the GNU General Public License
%as published by the Free Software Foundation; either version 2
%of the License, or (at your option) any later version.
%
%This program is distributed in the hope that it will be useful,
%but WITHOUT ANY WARRANTY; without even the implied warranty of
%MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%GNU General Public License for more details.
%
%You should have received a copy of the GNU General Public License
%along with this program; if not, write to the Free Software
%Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Doppio Stub
%
function Adatta2S(z,i,d,c,m1,m2,Dfpc)

%
% Adatta l'impedenza normalizzata z con un doppio stub
%
% A mutua distanza d lambda, con la (i=1) prima o
% (i=2) seconda intersezione 
% In corto circuito (c=1) o circuito aperto (c=0)
% lunghi l1 + m1 lambda /2 e l2 + m2 lambda/2
%
% Se Dfpc >0 valuta l'adattamento per f = f(1 +- Dfpc/100)
%

smith3;

if (c==1)
    chiuso = 'Corto Circuito';
else
    chiuso = 'Circuito aperto';
end

if (i==1)
    inter = 'prima';
else
    inter = 'seconda';
end

tit = ['Adattamento con Doppio Stub parallelo in ', chiuso,...
       ' mutua distanza ', num2str(d), ' alla ', inter,...
       ' intersezione (con ',num2str(m1),' e ',num2str(m2),' giri aggiuntivi)'];
  
% Cerchio ruotato
xc = 0.5*cos(4*pi*d);
yc = 0.5*sin(4*pi*d);
circle (xc,yc,0.5,0,2*pi,120,[0.5,0,0.5],3);

% Si pu� fare?
gc = 1./(sin(2*pi*d))^2;
fillcircle(gc/(1+gc),0,1/(1+gc),120,[0.25,0.25,0.25],3);

circle (-1.2,1.2,0.015,0,2*pi,32,[0.25,0.25,0.25],3);
text (-1.1,1.2,'Zona di non adattabilit�','Color',[0.25,0.25,0.25]);    
circle (-1.2,1.15,0.015,0,2*pi,32,[0.5,0,0.5],3);
text (-1.1,1.15,'Circonferenza ruotata','Color',[0.5,0,0.5]);    

gamma = (z-1)/(z+1);
circle (real(gamma),imag(gamma),0.015,0,2*pi,32,'y',3);
line([0,real(gamma)],[0,imag(gamma)],'Color','y','LineWidth',2);
text (real(gamma)+0.02,imag(gamma)+0.02,num2str(z),'Color','y');
y = 1/z;
gamma = (y-1)/(y+1);
circle (real(gamma),imag(gamma),0.015,0,2*pi,32,'r',3);
line([0,real(gamma)],[0,imag(gamma)],'Color','y','LineWidth',2);
text (real(gamma)+0.02,imag(gamma)+0.02,num2str(y),'Color','r');

circle (-1.2,1.1,0.015,0,2*pi,32,'y',3);
text (-1.1,1.1,'(1) Carico zL','Color','y');    
circle (-1.2,1.05,0.015,0,2*pi,32,'r',3);
text (-1.1,1.05,'(2) Carico yL','Color','r');    

if (real(y)>gc)
    warndlg('In zona di NON adattabilit�','OPS!');
else
    % mi sposto nel punto di adattamento
    td = tan(2*pi*d);
    gl = real(y);
    bl = imag(y);
    sq = sqrt((1+td^2)*gl - gl^2*td^2);
    b10 = -bl + (1+sq)/td;
    b11 = -bl + (1-sq)/td;
    if (abs(b10)<abs(b11))
        b1v=[b10,b11];
    else
        b1v=[b11,b10];
    end
    b1 = b1v(i);
      
    % Valuto lo Stub necessario
    if (c==1)
        d1 = acot(-b1)/(2*pi);
    else
        d1 = atan(b1)/(2*pi);
    end
    if (d1<0)
        d1 = d1 + 0.5;
    end
    d1 = d1 +  m1*0.5;
    if (c==1)
        MoveToGen(1,0,d1,120,'r',2,'l1=',1.05);
    else
        MoveToGen(1,pi,d1,120,'r',2,'l1=',1.05);
    end     

    MoveForStub(y,b1,60,'r',2,b1);
    y1 = y + j*b1;
    g1 = (y1-1)/(y1+1);
    circle (real(g1),imag(g1),0.015,0,2*pi,32,'m',3);
    text (real(g1)+0.02,imag(g1)+0.02,num2str(y1),'Color','m');

    circle (0.2,1.2,0.015,0,2*pi,32,'m',3);
    text (0.3,1.2,'(3) Effetto 1� stub (yL+jb1)','Color','m');    

    % ruoto a ritroso di d
    MoveToGen(abs(g1),atan2(imag(g1),real(g1)),d,64,'m',2,'d=',1.1);
    g2 = g1 * exp(-sqrt(-1)*4*pi*d); 
    circle (real(g2),imag(g2),0.015,0,2*pi,32,[1.,0.7,0],3);
    y2 = (1+g2)/(1-g2);
    text (real(g2)+0.02,imag(g2)+0.02,num2str(y2),'Color',[1.,0.7,0]);
    b2 = imag(y2);
    
    circle (0.2,1.15,0.015,0,2*pi,32,[1.,0.7,0],3);
    text (0.3,1.15,'(4) Spostamento di d','Color',[1.,0.7,0]);    

    % Valuto lo Stub necessario
    if (c==1)
        d2 = acot(b2)/(2*pi);
    else
        d2 = atan(-b2)/(2*pi);
    end
    if (d2<0)
        d2 = d2 + 0.5;
    end
    d2 = d2 +  m1*0.5;
    if (c==1)
        MoveToGen(1,0,d2,120,[1.,0.7,0],2,'l2=',1.15);
    else
        MoveToGen(1,pi,d2,120,[1.,0.7,0],2,'l2=',1.15);
    end     

    MoveToAdapt(y2,120,[1.,0.7,0],2,1.0);

    circle (0,0,0.015,0,2*pi,32,'b',3);

    circle (0.2,1.1,0.015,0,2*pi,32,'b',3);
    text (0.3,1.1,'(5) Effetto 2� stub','Color','b');    

% Frequenza    
    for i = -120:120;
        lambda = 1 - (i/120.0)*(Dfpc/100);
        y2 = y + 1/StubL(c,d1/lambda);
        y3 = ZetaL(y2,d/lambda);
        y4 = y3 + 1/StubL(c,d2/lambda);
        g2 = (y4-1)/(y4+1);
        x5(i+121) = real(g2);
        y5(i+121) = imag(g2);
    end
    line (x5,y5,'Color','b','LineWidth',2);
    for i = -round(Dfpc):round(Dfpc)
        lambda = 1 - i/100.0;
        y2 = y + 1/StubL(c,d1/lambda);
        y3 = ZetaL(y2,d/lambda);
        y4 = y3 + 1/StubL(c,d2/lambda);
        g2 = (y4-1)/(y4+1);
        circle (real(g2),imag(g2),0.01,0,2*pi,16,'g',2);
        text (real(g2)+0.02,imag(g2),[num2str(i),'%'],'Color',[0,0,0.5]);
    end    
end

title(tit);
