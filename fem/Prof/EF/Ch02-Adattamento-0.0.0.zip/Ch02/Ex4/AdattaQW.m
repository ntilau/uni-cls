%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%LICENCE
% Experiment Framework
% Copyright (C) 2001-2002-2003-2004  Stefano Selleri
%
%This program is free software; you can redistribute it and/or
%modify it under the terms of the GNU General Public License
%as published by the Free Software Foundation; either version 2
%of the License, or (at your option) any later version.
%
%This program is distributed in the hope that it will be useful,
%but WITHOUT ANY WARRANTY; without even the implied warranty of
%MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%GNU General Public License for more details.
%
%You should have received a copy of the GNU General Public License
%along with this program; if not, write to the Free Software
%Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Trasformatore a lambda quarti
%
function AdattaQW(z,n,Z0,Dfpc)

%
% Adatta l'impedenza normalizzata z con trasformatore a lambda quarti
%
% posto all' n-esima intersezione del cerchio a Gamma costante
% Con l'asse reale
%
% Se Dfpc >0 valuta l'adattamento per f = f(1 +- Dfpc/100)
%

smith3;

% posizione iniziale
gamma = (z-1)/(z+1);
circle (real(gamma),imag(gamma),0.015,0,2*pi,32,'r',3);
text (real(gamma)+0.02,imag(gamma)+0.02,num2str(z),'Color','r');

% mi sposto nel punto di adattamento
l = MoveToReal(z,n);
phii = atan2(imag(gamma),real(gamma));
MoveToGen(abs(gamma),phii,l,120,'r',2,'d=',1.05);
gamma1 = gamma * exp(-sqrt(-1)*4*pi*l);
z1 = (1+gamma1)/(1-gamma1);
circle (real(gamma1),imag(gamma1),0.015,0,2*pi,32,'m',3);
text (real(gamma1)+0.02,imag(gamma1)+0.02,num2str(real(z1)),'Color','m');

% Calcolo l'impedenza del tratto
Zt = Z0*sqrt(real(z1));

gamma = (sqrt(real(z1))-1)/(sqrt(real(z1))+1);
circle (real(gamma),imag(gamma),0.015,0,2*pi,32,'g',3);
line([0,real(gamma)],[0,imag(gamma)],'Color','g','LineWidth',2)
text (real(gamma)+0.02,imag(gamma)+0.02,num2str(sqrt(real(z1))),'Color','g');

% Ultimo cerchio
circle (0,0,0.015,0,2*pi,32,'b',3);

% Frequenza
for i = -120:120
    lambda = 1 - (i/120.0)*(Dfpc/100);
    z2 = ZetaL(z,l/lambda);
    z3 = z2 * Z0/Zt;
    z4 = ZetaL(z3,0.25/lambda);
    z5 = z4 *Zt/Z0;
    g2 = (z5-1)/(z5+1);
    x3(i+121) = real(g2);
    y3(i+121) = imag(g2);
end
line (x3,y3,'Color','b','LineWidth',2);
for i = -round(Dfpc):round(Dfpc)
    lambda = 1 - i/100.0;
    z2 = ZetaL(z,l/lambda);
    z3 = z2 * Z0/Zt
    z4 = ZetaL(z3,0.25/lambda);
    z5 = z4 *Zt/Z0;
    g2 = (z5-1)/(z5+1);
    circle (real(g2),imag(g2),0.01,0,2*pi,16,'g',2);
    text (real(g2)+0.02,imag(g2),[num2str(i),'%'],'Color',[0,0,0.5]);
end    


% Legenda
circle (-1.2,1.2,0.015,0,2*pi,32,'r',3);
text (-1.1,1.2,'(1) Carico zL','Color','r');
circle (-1.2,1.15,0.015,0,2*pi,32,'m',3);
text (-1.1,1.15,'(2) zAA - puramente reale','Color','m');
circle (-1.2,1.1,0.015,0,2*pi,32,'g',3);
text (-1.1,1.1,['(3) Zt - Impedenza del trasformatore ',num2str(Zt),' Ohm'] ,'Color','g');
circle (-1.2,1.05,0.015,0,2*pi,32,'b',3);
text (-1.1,1.05,'(4) zBB - adattata' ,'Color','b');
