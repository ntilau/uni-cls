%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%LICENCE
% Experiment Framework
% Copyright (C) 2001-2002-2003-2004  Stefano Selleri
%
%This program is free software; you can redistribute it and/or
%modify it under the terms of the GNU General Public License
%as published by the Free Software Foundation; either version 2
%of the License, or (at your option) any later version.
%
%This program is distributed in the hope that it will be useful,
%but WITHOUT ANY WARRANTY; without even the implied warranty of
%MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%GNU General Public License for more details.
%
%You should have received a copy of the GNU General Public License
%along with this program; if not, write to the Free Software
%Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Singolo Stub
%
function Adatta1S(z,s,i,n,c,m,Dfpc)

%
% Adatta l'impedenza normalizzata z con uno stub
%
% Serie (s=1) o parallelo (s=0)
% A distanza l_i + n lanbda / 2, con i=1,2 e n>=0
% In corto circuito (c=1) o circuito aperto (c=0)
% lungo d + m lambda /2
%
% Se Dfpc >0 valuta l'adattamento per f = f(1 +- Dfpc/100)
%

smith3;
if (s==1)
    type = 'Serie';
else
    type = 'Parallelo';
end

if (c==1)
    chiuso = 'Corto Circuito'
else
    chiuso = 'Circuito aperto'
end

if (i==1)
    inter = 'prima'
else
    inter = 'seconda'
end

if (s==1)
    % Stub serie
    % posizione iniziale
    gamma = (z-1)/(z+1);
    circle (real(gamma),imag(gamma),0.015,0,2*pi,32,'r',3);
    text (real(gamma)+0.02,imag(gamma)+0.02,num2str(z),'Color','r');
    % mi sposto nel punto di adattamento
    l = MoveTo1(z,i)+n*0.5;
    phii = atan2(imag(gamma),real(gamma));
    MoveToGen(abs(gamma),phii,l,120,'r',2,'d=',1.05);
    gamma1 = gamma * exp(-sqrt(-1)*4*pi*l);
    z1 = (1+gamma1)/(1-gamma1);
    circle (real(gamma1),imag(gamma1),0.015,0,2*pi,32,'m',3);
    text (real(gamma1)+0.02,imag(gamma1)+0.02,num2str(z1),'Color','m');
    % Valuto lo Stub necessario
    x = imag (z1);
    if (c==1)
        d = -atan(x)/(2*pi);
    else
        d = acot(x)/(2*pi);
    end
    if (d<0)
        d = d + 0.5;
    end
    d = d +  m*0.5;
    if (c==1)
        MoveToGen(1,pi,d,120,'m',2,'ls=',1.10);
    else
        MoveToGen(1,0,d,120,'m',2,'ls=',1.10);
    end     
    MoveToAdapt(z1,120,'m',2,1.0);
    circle (0,0,0.015,0,2*pi,32,'b',3);
    
    for i = -120:120
        lambda = 1 - (i/120)*(Dfpc/100);
        z2 = ZetaL(z,l/lambda) + StubL(c,d/lambda);
        g2 = (z2-1)/(z2+1);
        x2(i+121) = real(g2);
        y2(i+121) = imag(g2);
    end
    line (x2,y2,'Color','b','LineWidth',2);
    for i = -round(Dfpc):round(Dfpc)
        lambda = 1 - i/100.0;
        z2 = ZetaL(z,l/lambda) + StubL(c,d/lambda);
        g2 = (z2-1)/(z2+1);
        circle (real(g2),imag(g2),0.01,0,2*pi,16,'g',2);
        text (real(g2)+0.02,imag(g2),[num2str(i),'%'],'Color',[0,0,0.5]);
    end
else
    % Stub parallelo
    % posizione iniziale
    gamma = (z-1)/(z+1);
    circle (real(gamma),imag(gamma),0.015,0,2*pi,32,'y',3);
    line([0,real(gamma)],[0,imag(gamma)],'Color','y','LineWidth',2)
    text (real(gamma)+0.02,imag(gamma)+0.02,num2str(z),'Color','y');
    y = 1/z;
    gamma = (y-1)/(y+1);
    circle (real(gamma),imag(gamma),0.015,0,2*pi,32,'r',3);
    line([0,real(gamma)],[0,imag(gamma)],'Color','y','LineWidth',2)
    text (real(gamma)+0.02,imag(gamma)+0.02,num2str(y),'Color','r');
    % mi sposto nel punto di adattamento
    l = MoveTo1(y,i)+n*0.5;
    phii = atan2(imag(gamma),real(gamma));
    MoveToGen(abs(gamma),phii,l,120,'r',2,'d=',1.05);
    gamma1 = gamma * exp(-sqrt(-1)*4*pi*l);
    y1 = (1+gamma1)/(1-gamma1);
    circle (real(gamma1),imag(gamma1),0.015,0,2*pi,32,'m',3);
    text (real(gamma1)+0.02,imag(gamma1)+0.02,num2str(y1),'Color','m');
    % Valuto lo Stub necessario
    b = imag (y1);
    if (c==1)
        d = acot(b)/(2*pi);
    else
        d = atan(-b)/(2*pi);
    end
    if (d<0)
        d = d + 0.5;
    end
    d = d +  m*0.5;
    if (c==1)
        MoveToGen(1,0,d,120,'m',2,'ls=',1.10);
    else
        MoveToGen(1,pi,d,120,'m',2,'ls=',1.10);
    end     
    MoveToAdapt(y1,120,'m',2,1.0);
    circle (0,0,0.015,0,2*pi,32,'b',3);
    
    for i = -120:120
        lambda = 1 - (i/120.0)*(Dfpc/100);
        y2 = ZetaL(y,l/lambda) + 1/StubL(c,d/lambda);
        g2 = (y2-1)/(y2+1);
        x3(i+121) = real(g2);
        y3(i+121) = imag(g2);
    end
    line (x3,y3,'Color','b','LineWidth',2);
    for i = -round(Dfpc):round(Dfpc)
        lambda = 1 - i/100.0;
        y2 = ZetaL(y,l/lambda) + 1/StubL(c,d/lambda);
        g2 = (y2-1)/(y2+1);
        circle (real(g2),imag(g2),0.01,0,2*pi,16,'g',2);
        text (real(g2)+0.02,imag(g2),[num2str(i),'%'],'Color',[0,0,0.5]);
    end    
end

%Legenda
if (s==1)
    circle (-1.2,1.2,0.015,0,2*pi,32,'r',3);
    text (-1.1,1.2,'(1) Carico zL','Color','r');
    circle (-1.2,1.15,0.015,0,2*pi,32,'m',3);
    text (-1.1,1.15,'(2) zAA-','Color','m');
    circle (-1.2,1.1,0.015,0,2*pi,32,'b',3);
    text (-1.1,1.1,'(3) zAA+','Color','b');
else
    circle (-1.2,1.2,0.015,0,2*pi,32,'y',3);
    text (-1.1,1.2,'(1) Carico zL','Color','y');    
    circle (-1.2,1.15,0.015,0,2*pi,32,'r',3);
    text (-1.1,1.15,'(2) Carico yL','Color','r');    
    circle (-1.2,1.1,0.015,0,2*pi,32,'m',3);
    text (-1.1,1.1,'(3) zAA-','Color','m');
    circle (-1.2,1.05,0.015,0,2*pi,32,'b',3);
    text (-1.1,1.05,'(4) zAA+','Color','b');
end
