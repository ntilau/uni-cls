%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%LICENCE
% Experiment Framework
% Copyright (C) 2001-2002-2003-2004  Stefano Selleri
%
%This program is free software; you can redistribute it and/or
%modify it under the terms of the GNU General Public License
%as published by the Free Software Foundation; either version 2
%of the License, or (at your option) any later version.
%
%This program is distributed in the hope that it will be useful,
%but WITHOUT ANY WARRANTY; without even the implied warranty of
%MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%GNU General Public License for more details.
%
%You should have received a copy of the GNU General Public License
%along with this program; if not, write to the Free Software
%Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Smith
%
function smith(dr,Nr,dx,Nx)
%
%
% Uso:
%
%    smith (dr,Nr,dx,Nx)
%
% Disegna una carta di Smith con
% Nr cerchi a resistenza costante e Nx
% cerchi a reattanza costante.
%
% Le resistenze partono da 0 e aumentano
% con passo dr
%
% Le reattanze partono da 0 e aumentano
% e diminuiscono con passo dx
%
% (C) 2002 Stefano Selleri
%

for ir=0:Nr
    r = ir*dr;
    xc = r/(1+r);
    yc = 0;
    rd = 1/(1+r);
    circle(xc,yc,rd,0,2*pi,120);
end;
axis('equal');

line ([-1,1],[0,0]);
for ix=1:Nx
    x = ix*dx;
    xc = 1;
    yc = 1/x;
    rd = 1/x;
    circle(xc,yc,rd,3*pi/2 - 2*atan(x),3*pi/2,120);
    circle(xc,-yc,rd,pi/2,pi/2 + 2*atan(x),120);
end;
axis('equal');