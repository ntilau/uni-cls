%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%LICENCE
% Experiment Framework
% Copyright (C) 2001-2002-2003-2004  Stefano Selleri
%
%This program is free software; you can redistribute it and/or
%modify it under the terms of the GNU General Public License
%as published by the Free Software Foundation; either version 2
%of the License, or (at your option) any later version.
%
%This program is distributed in the hope that it will be useful,
%but WITHOUT ANY WARRANTY; without even the implied warranty of
%MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%GNU General Public License for more details.
%
%You should have received a copy of the GNU General Public License
%along with this program; if not, write to the Free Software
%Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Smith
%
function MoveForStub(z,b,N,col,w,quote)
%
% Uso:
%
%     MoveToAdapt(z,N,col,w);
%
% Disegna un arco di cerchio di centro opportuno per real(z)
% e raggio adeguato parterndo da imag(z) e muovendosi in senso
% opportuno di b
% in N segmenti.
%
% Linee di colore col e spessore w
%
% (C) 2002 Stefano Selleri
%

r = real(z);
x = imag(z);

xc = r/(1+r);
yc = 0;
rd = 1/(1+r);

g1 = (z-1)/(z+1);
g2 = (z+sqrt(-1)*b-1)/(z+sqrt(-1)*b+1);

phi0 = atan2(imag(g1)-yc,real(g1)-xc);
phi1 = atan2(imag(g2)-yc,real(g2)-xc);

if (phi1-phi0>pi)
     circle(xc,yc,rd,phi0,-pi,120,col,w);
     circle(xc,yc,rd,pi,phi1,120,col,w);
    xt = xc + rd*cos(-pi);
    yt = yc + rd*sin(-pi);
    text (xt+0.02,yt+0.02,num2str(b),'Color',col);
else
    circle(xc,yc,rd,phi0,phi1,120,col,w);
    xt = xc + rd*cos((phi0+phi1)/2);
    yt = yc + rd*sin((phi0+phi1)/2);
    text (xt+0.02,yt+0.02,num2str(b),'Color',col);
end
