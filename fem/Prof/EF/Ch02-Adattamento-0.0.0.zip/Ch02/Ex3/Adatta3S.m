%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%LICENCE
% Experiment Framework
% Copyright (C) 2001-2002-2003-2004  Stefano Selleri
%
%This program is free software; you can redistribute it and/or
%modify it under the terms of the GNU General Public License
%as published by the Free Software Foundation; either version 2
%of the License, or (at your option) any later version.
%
%This program is distributed in the hope that it will be useful,
%but WITHOUT ANY WARRANTY; without even the implied warranty of
%MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%GNU General Public License for more details.
%
%You should have received a copy of the GNU General Public License
%along with this program; if not, write to the Free Software
%Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Triplo Stub
%
function Adatta3S(z,i,d1,d2,c,m1,m2,m3,Dfpc)

%
% Adatta l'impedenza normalizzata z con un doppio stub
%
% A mutua distanza d lambda, con la (i=1) prima o
% (i=2) seconda intersezione 
% In corto circuito (c=1) o circuito aperto (c=0)
% lunghi l1 + m1 lambda /2 e l2 + m2 lambda/2
%
% Se Dfpc >0 valuta l'adattamento per f = f(1 +- Dfpc/100)
%

smith3;

if (c==1)
    chiuso = 'Corto Circuito'
else
    chiuso = 'Circuito aperto'
end

if (i==1)
    inter = 'prima'
else
    inter = 'seconda'
end

tit = ['Adattamento con Triplo Stub parallelo in ', chiuso,...
       ' mutua distanze ', num2str(d1), ' e ',num2str(d1), ' alla ', inter,...
       ' intersezione (con ',num2str(m1),', ',num2str(m2),' e ',num2str(m3),'giri aggiuntivi)'];
  
% Cerchio ruotato una volta
xc = 0.5*cos(4*pi*d1);
yc = 0.5*sin(4*pi*d1);
circle (xc,yc,0.5,0,2*pi,120,[0.5,0,0.5],3);

% Cerchio ruotato due volte
xc = 0.5*cos(4*pi*(d1+d2));
yc = 0.5*sin(4*pi*(d1+d2));
circle (xc,yc,0.5,0,2*pi,120,[0.75,0,0.35],3);

% Si pu� fare?
gc = 1./(sin(2*pi*d2))^2
xc = gc/(1+gc);
yc = 0;
fillcircle(xc,yc,1/(1+gc),120,[0.65,0.65,0.65],3);

% Si pu� fare?
gc = 1./(sin(2*pi*d2))^2
xc = gc/(1+gc)*cos(4*pi*d1);
yc = gc/(1+gc)*sin(4*pi*d1);
fillcircle(xc,yc,1/(1+gc),120,[0.65,0.65,0.65],3);

circle (-1.2,1.2,0.015,0,2*pi,32,[0.65,0.65,0.65],3);
text (-1.1,1.2,'Zone di "non" adattabilit�','Color',[0.65,0.65,0.65]);    
circle (-1.2,1.15,0.015,0,2*pi,32,[0.5,0,0.5],3);
text (-1.1,1.15,'Circonferenza ruotata di d1','Color',[0.5,0,0.5]);    
circle (-1.2,1.10,0.015,0,2*pi,32,[0.75,0,0.35],3);
text (-1.1,1.10,'Circonferenza ruotata di d1+d2','Color',[0.75,0,0.35]);    

gamma = (z-1)/(z+1);
circle (real(gamma),imag(gamma),0.015,0,2*pi,32,'y',3);
line([0,real(gamma)],[0,imag(gamma)],'Color','y','LineWidth',2)
text (real(gamma)+0.02,imag(gamma)+0.02,num2str(z),'Color','y');
y = 1/z;
gamma = (y-1)/(y+1);
circle (real(gamma),imag(gamma),0.015,0,2*pi,32,'r',3);
line([0,real(gamma)],[0,imag(gamma)],'Color','y','LineWidth',2)
text (real(gamma)+0.02,imag(gamma)+0.02,num2str(y),'Color','r');

circle (-1.2,1.05,0.015,0,2*pi,32,'y',3);
text (-1.1,1.05,'(1) Carico zL','Color','y');    
circle (-1.2,1.0,0.015,0,2*pi,32,'r',3);
text (-1.1,1.0,'(2) Carico yL','Color','r');    

%Serve il primo stub???
dist = sqrt((xc-real(gamma))^2+(yc-imag(gamma))^2)
if (dist<=1/(1+gc))
    % SI
    'First stub is needed'
    % Valuto lo Stub necessario
    b1=-imag(y)
    if (c==1)
        l1 = acot(-b1)/(2*pi);
    else
        l1 = atan(b1)/(2*pi);
    end
    if (l1<0)
        l1 = l1 + 0.5;
    end
    l1 = l1 +  m1*0.5;
    if (c==1)
        MoveToGen(1,0,l1,120,'r',2,'l1=',1.05);
    else
        MoveToGen(1,pi,l1,120,'r',2,'l1=',1.05);
    end     
    MoveForStub(y,b1,60,'r',2,b1);
    y1 = y + j*b1
    g1 = (y1-1)/(y1+1);
    circle (real(g1),imag(g1),0.015,0,2*pi,32,'m',3);
    text (real(g1)+0.02,imag(g1)+0.02,num2str(y1),'Color','m');
else
    %NO
    'first stub uneeded'
    % Valuto lo Stub necessario
    if (c==1)
        l1 = 0.25;
    else
        l1 = 0;
    end
    if (l1<0)
        l1 = l1 + 0.5;
    end
    l1 = l1 +  m1*0.5;
    if (c==1)
        MoveToGen(1,0,l1,120,'r',2,'l1=',1.05);
    else
        MoveToGen(1,pi,l1,120,'r',2,'l1=',1.05);
    end     
    circle (real(gamma),imag(gamma),0.015,0,pi,32,'m',3);
    g1 = (y-1)/(y+1);
end
    
circle (-1.2,0.95,0.015,0,2*pi,32,'m',3);
text (-1.1,0.95,'(3) Effetto 1� stub (yL+jb1)','Color','m');    

% Spostamento di d1;
MoveToGen(abs(g1),atan2(imag(g1),real(g1)),d1,64,'m',2,'d1=',1.1)
g2 = g1 * exp(-sqrt(-1)*4*pi*d1); 
circle (real(g2),imag(g2),0.015,0,2*pi,32,[1.,0.7,0],3);
y2 = (1+g2)/(1-g2)
text (real(g2)+0.02,imag(g2)+0.02,num2str(y2),'Color',[1.,0.7,0]);
%b2 = imag(y2);
    
circle (0.2,1.2,0.015,0,2*pi,32,[1.,0.7,0],3);
text (0.3,1.2,'(4) Spostamento di d1','Color',[1.,0.7,0]);    

% mi sposto nel punto di adattamento
td = tan(2*pi*d2);
g2 = real(y2);
b2 = imag(y2);
sq = sqrt((1+td^2)*g2 - g2^2*td^2);
b10 = -b2 + (1+sq)/td;
b11 = -b2 + (1-sq)/td;
if (abs(b10)<abs(b11))
    b1v=[b10,b11];
else
    b1v=[b11,b10];
end
b3 = b1v(i)
      
% Valuto lo Stub necessario
if (c==1)
    l2 = acot(-b3)/(2*pi);
else
    l2 = atan(b3)/(2*pi);
end
if (l2<0)
  l2 = l2 + 0.5;
end
l2 = l2 +  m2*0.5;
if (c==1)
  MoveToGen(1,0,l2,120,[1.,0.7,0],2,'l2=',1.15);
else
  MoveToGen(1,pi,l2,120,[1.,0.7,0],2,'l2=',1.15);
end     

MoveForStub(y2,b3,60,[1.,0.7,0],2,b3);
y3 = y2 + j*b3
g3 = (y3-1)/(y3+1);
circle (real(g3),imag(g3),0.015,0,2*pi,32,[0.,.8,0.4],3);
text (real(g3)+0.02,imag(g3)+0.02,num2str(y3),'Color',[0.,.8,0.4]);

circle (0.2,1.15,0.015,0,2*pi,32,[0.,.8,0.4],3);
text (0.3,1.15,'(5) Effetto 2� stub ','Color',[0.,.8,0.4]);    

% ruoto a ritroso di d2
MoveToGen(abs(g3),atan2(imag(g3),real(g3)),d2,64,[0.,.8,0.4],2,'d2=',1.15)
g4 = g3 * exp(-sqrt(-1)*4*pi*d2); 
circle (real(g4),imag(g4),0.015,0,2*pi,32,[0,0.5,0],3);
y4 = (1+g4)/(1-g4);
text (real(g4)+0.02,imag(g4)+0.02,num2str(y4),'Color',[0,0.5,0]);
b4 = imag(y4);
    
circle (0.2,1.1,0.015,0,2*pi,32,[0.,0.5,0],3);
text (0.3,1.1,'(6) Spostamento di d2','Color',[0.,0.5,0]);    

% Valuto lo Stub necessario
if (c==1)
  l3 = acot(b4)/(2*pi);
else
  l3 = atan(-b4)/(2*pi);
end
if (l3<0)
  l3 = l3 + 0.5;
end

l3 = l3 +  m3*0.5;
if (c==1)
    MoveToGen(1,0,l3,120,[0.,0.8,0.4],2,'l3=',1.2);
else
    MoveToGen(1,pi,l3,120,[0.,0.8,0.4],2,'l3=',1.2);
end     

MoveToAdapt(y4,120,[0.,0.5,0],2,1.0);

circle (0,0,0.015,0,2*pi,32,'b',3);

circle (0.2,1.05,0.015,0,2*pi,32,'b',3);
text (0.3,1.05,'(5) Effetto 3� stub','Color','b');    
    
% Frequenza    
    for i = -120:120;
        lambda = 1 - (i/120.0)*(Dfpc/100);
        y2 = y + 1/StubL(c,l1/lambda);
        y3 = ZetaL(y2,d1/lambda);
        y4 = y3 + 1/StubL(c,l2/lambda);
        y5 = ZetaL(y4,d2/lambda);
        y6 = y5 + 1/StubL(c,l3/lambda);
        g2 = (y6-1)/(y6+1);
        x7(i+121) = real(g2);
        y7(i+121) = imag(g2);
    end
    line (x7,y7,'Color','b','LineWidth',2);
    for i = -round(Dfpc):round(Dfpc)
        lambda = 1 - i/100.0;
        y2 = y + 1/StubL(c,l1/lambda);
        y3 = ZetaL(y2,d1/lambda);
        y4 = y3 + 1/StubL(c,l2/lambda);
        y5 = ZetaL(y4,d2/lambda);
        y6 = y5 + 1/StubL(c,l3/lambda);
        g2 = (y6-1)/(y6+1);
        circle (real(g2),imag(g2),0.01,0,2*pi,16,'g',2);
        text (real(g2)+0.02,imag(g2),[num2str(i),'%'],'Color',[0,0,0.5]);
    end    
%    for i = -120:120
%        lambda = 1 - (i/120.0)*(Dfpc/100);
%        y2 = ZetaL(y,l/lambda) + 1/StubL(c,d/lambda);
%        g2 = (y2-1)/(y2+1);
%        x3(i+121) = real(g2);
%        y3(i+121) = imag(g2);
%    end
%    line (x3,y3,'Color','b','LineWidth',2);
%    for i = -round(Dfpc):round(Dfpc)
%        lambda = 1 - i/100.0;
%        y2 = ZetaL(y,l/lambda) + 1/StubL(c,d/lambda);
%        g2 = (y2-1)/(y2+1);
%        circle (real(g2),imag(g2),0.01,0,2*pi,16,'g',2);
%        text (real(g2)+0.02,imag(g2),[num2str(i),'%'],'Color',[0,0,0.5]);
%    end    
end

title(tit);




