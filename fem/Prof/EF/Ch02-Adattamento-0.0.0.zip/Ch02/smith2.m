%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%LICENCE
% Experiment Framework
% Copyright (C) 2001-2002-2003-2004  Stefano Selleri
%
%This program is free software; you can redistribute it and/or
%modify it under the terms of the GNU General Public License
%as published by the Free Software Foundation; either version 2
%of the License, or (at your option) any later version.
%
%This program is distributed in the hope that it will be useful,
%but WITHOUT ANY WARRANTY; without even the implied warranty of
%MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%GNU General Public License for more details.
%
%You should have received a copy of the GNU General Public License
%along with this program; if not, write to the Free Software
%Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Carta di Smith
%
function smith2(d,N)
%
%
% Uso:
%
%    smith2 (d,N)
%
% Disegna una carta di Smith a zone. I parametri
% d e N sono vettori di lunghezza M
%
% Traccia le linnee a r=0, x=0
% Traccia M zone, ognuna ha N(i) linee
% distanti d(i) l'una dall'altra.
%
% (C) 2002 Stefano Selleri
%

circle(0,0,1,0,2*pi,120,[0.5,0.5,0.5],1);
line ([-1,1],[0,0],'Color',[0.5,0.5,0.5],'LineWidth',1);

M = length(N);

lastV = 0;
for i=1:M
    if (i==M)
        nextV=0;
    else
        nextV=N(i)*d(i);
    end
    for j=0:N(i)
        V = d(i)*j;
        smithzone(V,nextV);
    end
    lastV=nextV;
end

axis('equal');