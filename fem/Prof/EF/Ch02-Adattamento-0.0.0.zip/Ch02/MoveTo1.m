%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%LICENCE
% Experiment Framework
% Copyright (C) 2001-2002-2003-2004  Stefano Selleri
%
%This program is free software; you can redistribute it and/or
%modify it under the terms of the GNU General Public License
%as published by the Free Software Foundation; either version 2
%of the License, or (at your option) any later version.
%
%This program is distributed in the hope that it will be useful,
%but WITHOUT ANY WARRANTY; without even the implied warranty of
%MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%GNU General Public License for more details.
%
%You should have received a copy of the GNU General Public License
%along with this program; if not, write to the Free Software
%Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Smith
%
function [l] = MoveTo1(z,i)

%
% Moves z to r(g)=1 circle, i-th intersection
%

gamma = (z-1)/(z+1);
Mgamma = abs(gamma);
Fgamma = atan2(imag(gamma),real(gamma));

if (Fgamma>=0)
    % Vado verso z elevate
    z1 = (1+Mgamma)/(1-Mgamma);
    r = Fgamma/(4*pi);
else
    % Vado verso z basse
    z1 = (1-Mgamma)/(1+Mgamma);
    r = (pi + Fgamma)/(4*pi);
%    circle(0,0,Mgamma,-pi,Fgamma,32,'r',3)
end

l1 = atan(1/sqrt(z1))/(2*pi);
if (l1<0) 
    l1 = l1 + 0.5;
end
l2 = atan(-1/sqrt(z1))/(2*pi);
if (l2<0) 
    l2 = l2 + 0.5;
end
l1 = l1 + r;
l2 = l2 + r;
if (l1>0.5)
    l1 = l1-0.5;
end
if (l2>0.5)
    l2 = l2-0.5;
end

if (l1<l2)
    lv=[l1,l2];
else
    lv=[l2,l1];
end

l = lv(i);
