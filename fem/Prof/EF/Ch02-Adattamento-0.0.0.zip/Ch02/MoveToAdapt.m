%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%LICENCE
% Experiment Framework
% Copyright (C) 2001-2002-2003-2004  Stefano Selleri
%
%This program is free software; you can redistribute it and/or
%modify it under the terms of the GNU General Public License
%as published by the Free Software Foundation; either version 2
%of the License, or (at your option) any later version.
%
%This program is distributed in the hope that it will be useful,
%but WITHOUT ANY WARRANTY; without even the implied warranty of
%MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%GNU General Public License for more details.
%
%You should have received a copy of the GNU General Public License
%along with this program; if not, write to the Free Software
%Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Smith
%
function MoveToGen(z,N,col,w,quote)
%
% Uso:
%
%     MoveToAdapt(z,N,col,w);
%
% Disegna un arco di cerchio di centro (0.5,0)
% e raggio 0.5 parterndo da z e muovendosi in senso
% opportuno fiino a z=(1,0)
% in N segmenti.
%
% Linee di colore col e spessore w
%
% (C) 2002 Stefano Selleri
%

if (abs(real(z)-1) > 1e-6) 
    print "ERROR";
else
    xc = 0.5;
    yc = 0;
    rd = 0.5;

    Vmax = imag(z);
    
    xb  = (-1+0.5^2+Vmax^2)/(1+2*0.5+0.5^2+Vmax^2);
    yb  = 2*Vmax/(1+2*0.5+0.5^2+Vmax^2);
    phi = atan2(yb-yc,xb-xc);
    if (phi>0)
        circle(xc,yc,rd,phi,pi,120,col,2);
    else
        circle(xc,yc,rd,pi,2*pi+phi,120,col,2);
    end
end;

