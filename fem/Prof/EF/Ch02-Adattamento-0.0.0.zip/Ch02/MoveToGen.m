%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%LICENCE
% Experiment Framework
% Copyright (C) 2001-2002-2003-2004  Stefano Selleri
%
%This program is free software; you can redistribute it and/or
%modify it under the terms of the GNU General Public License
%as published by the Free Software Foundation; either version 2
%of the License, or (at your option) any later version.
%
%This program is distributed in the hope that it will be useful,
%but WITHOUT ANY WARRANTY; without even the implied warranty of
%MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%GNU General Public License for more details.
%
%You should have received a copy of the GNU General Public License
%along with this program; if not, write to the Free Software
%Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Smith
%
function MoveToGen(r,phi0,d,N,col,w,label,quote)
%
% Uso:
%
%     MoveToGen(r,phi0,d,N,col,w);
%
% Disegna un arco di cerchio di centro (0,0)
% e raggio r parterndo da phi e muovendosi in senso
% antiorario di d (d = 0.5 -> 1 giro!)
% in N segmenti.
%
% Linee di colore col e spessore w
%
% (C) 2002 Stefano Selleri
%


for i=0:N
    phi    = phi0 - 4*pi*d*i/N;
    x(i+1) = r*cos(phi);
    y(i+1) = r*sin(phi);
    x1(i+1)= quote*cos(phi);
    y1(i+1)= quote*sin(phi);
end;

line (x,y,'Color',col,'LineWidth',w);
line (x1,y1,'Color',col,'LineWidth',1);
line ([0,x1(1)],[0,y1(1)],'Color',col,'LineWidth',1);
line ([0,x1(N+1)],[0,y1(N+1)],'Color',col,'LineWidth',1);
text (x1(floor((N+1)/2))+0.02,y1(floor((N+1)/2))+0.02,strcat(label,num2str(d)),'Color',col);