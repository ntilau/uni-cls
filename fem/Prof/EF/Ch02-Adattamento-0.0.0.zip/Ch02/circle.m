%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%LICENCE
% Experiment Framework
% Copyright (C) 2001-2002-2003-2004  Stefano Selleri
%
%This program is free software; you can redistribute it and/or
%modify it under the terms of the GNU General Public License
%as published by the Free Software Foundation; either version 2
%of the License, or (at your option) any later version.
%
%This program is distributed in the hope that it will be useful,
%but WITHOUT ANY WARRANTY; without even the implied warranty of
%MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%GNU General Public License for more details.
%
%You should have received a copy of the GNU General Public License
%along with this program; if not, write to the Free Software
%Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Smith
%
function circle(xc,yc,r,phi1,phi2,N,col,w)
%
% Uso:
%
%     circle(xc,yc,r,start,end,N,col,w);
%
% Disegna un arco di cerchio di centro (xc,yc)
% e raggio r parterndo da phi1 e finendo a phi2
% radianti in N segmenti.
%
% Linee di colore col e spessore w
%
% (C) 2002 Stefano Selleri
%


for i=0:N
    phi    = (phi2-phi1)*i/N+phi1;
    x(i+1) = xc + r*cos(phi);
    y(i+1) = yc + r*sin(phi);
end;

line (x,y,'Color',col,'LineWidth',w);