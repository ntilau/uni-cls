function bof(zc,d)

smith3;

for i = 1:361
    y(i) = 1+sqrt(-1)*(i-180)/10;
    z(i) = 1/y(i);
    za(i)=z(i)-real(zc);
    zb(i)=z(i)-zc;
    gamma(i)  = (z(i)-1)/(z(i)+1);
    gammaa(i) = (za(i)-1)/(za(i)+1);
    gammab(i) = (zb(i)-1)/(zb(i)+1);
    gammac(i) = gammab(i)*exp(-sqrt(-1)*4*pi*d);
end
line(real(gamma),imag(gamma));
line(real(gammaa),imag(gammaa));
line(real(gammab),imag(gammab));
line(real(gammac),imag(gammac));
axis([-1,1,-1,1]);
    