package assfalg.esempi.sincronizzazione.variabile_condizione;

/**
 *	Classe che realizza una variabile di condizione.
 *
 *	La variabile di condizione consente ad diversi threads di accodarsi sulla
 *	variabile in attesa del verificarsi di una determinata condizione.
 *	Per la protezione della sezione critica, la variabile accetta come parametro
 *	un lock di mutua esclusione. Attraverso la combinazione di lock e variabile
 *	di condizione &egrave; possibile differenziare le condizioni di attesa per
 *	diversi threads pur mantenendo uno stesso lock di mutua esclusione.
 *
 *	@see Mutex
 *
 *	@author	J&uml;urgen Assfalg
 *	@version 1.1 - 18/03/2003
 */

public
class
VariabileCondizione
{
	public
	VariabileCondizione
	(
		Mutex mutex
	)
	{
		this.mutex = mutex;
	}

	//*	pone il thread invocante in attesa della condizione
	public
	void
	attendi()
	throws
		InterruptedException
	{
		int i = 0;
		InterruptedException eccezione = null;
		synchronized( this )
		{
			//	per liberare il lock, bisogna possederlo
			if ( mutex.proprietario() != Thread.currentThread() )
				throw new IllegalMonitorStateException(
					"il thread corrente non e' il proprietario"
				);
			//	rilascia il lock di mutua esclusione...
			while ( mutex.proprietario() == Thread.currentThread() )
			{
				i++;
				mutex.rilascia();
			}
			//	...e si pone in attesa
			try
			{
				wait();
			}
			catch ( InterruptedException ie )
			{
				//	cattura e memorizza l'eccezione
				eccezione = ie;
			}
		}
		/*	a seguito di notifica, il sbloccato thread riacquista il lock
			che deteneva quando si e' messo in attesa della condizione
		*/
		while ( i > 0 )
		{
			mutex.attendi();
			i--;
		}
		//	se precedentemente e' stata catturata un'eccezione, la rilancia
		if ( null != eccezione )
			throw eccezione;
	}

	//*	notifica il veridicarsi della condizione a un thread sospeso
	public
	synchronized
	void
	notifica()
	{
		if ( mutex.proprietario() != Thread.currentThread() )
			throw new IllegalMonitorStateException(
				"il thread corrente non e' il proprietario"
			);
		notify();
	}

	//*	notifica il veridicarsi della condizione ai thread sospesi
	public
	synchronized
	void
	notificaTutti()
	{
		if ( mutex.proprietario() != Thread.currentThread() )
			throw new IllegalMonitorStateException(
				"il thread corrente non e' il proprietario"
			);
		notifyAll();
	}

	//*	il lock di mutua esclusione
	private Mutex mutex;
}
