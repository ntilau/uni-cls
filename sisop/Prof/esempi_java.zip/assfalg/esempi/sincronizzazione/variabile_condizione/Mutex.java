package assfalg.esempi.sincronizzazione.variabile_condizione;

/**
 *	Classe che realizza un lock di mutua esclusione.
 *	In pratica questa classe realizza un semaforo binario, con i classici
 *	metodi di wait (attendi) e signal (rilascia). A questi si aggiunge un
 *	metodo per tentare di accedere alla sezione critica in maniera non
 *	bloccante (in caso di successo restituisce un valore vero, altrimenti
 *	falso).
 *	La classe consente ad un Thread che possiede il lock di accedervi anche
 *	pi&ugrave; volte, consentendo cos&igrave; lock annidati. A questo fine
 *	dispone di un contatore per tener traccia del livello di annidamento.
 *
 *	@author	J&uml;urgen Assfalg
 *	@version 1.1 - 18/03/2003
 */

public
class
Mutex
{
	//*	acquisizione bloccante del lock
	public
	synchronized
	void
	attendi()
	{
		//	cerca di acquisire il lock
		while ( false == acquisisci() )
		{
			try
			{
				//	se non e' possibile, attendi
				wait();
			}
			catch ( Exception e ) {}
		}
	}

	//*	acquisizione non bloccante del lock
	public
	synchronized
	boolean
	acquisisci()
	{
		//	se nessun thread detiene il lock...
		if ( null == proprietario )
		{
			//	...acquisisce il lock, registrando il detentore...
			proprietario = Thread.currentThread();
			//	...e inizializzando il contatore
			contatore = 1;
			return true;
		}
		//	se il lock e' gia' detenuto dallo stesso thread...
		if ( proprietario == Thread.currentThread() )
		{
			//	...incrementa il contatore dei livelli di annidamento
			contatore++;
			return true;
		}
		//	altrimenti indica che non e' stato possibile acquisire il lock
		return false;
	}

	//*	rilascio del lock
	public
	synchronized
	void
	rilascia()
	{
		//	il lock puo' essere rilasciato solo dal thread detentore
		if ( proprietario() == Thread.currentThread() )
		{
			//	decrementa il contatore dei livelli di annidamento
			contatore--;
			if ( 0 == contatore )
			{
				proprietario = null;
				//	notifica thread in attesa del lock
				notify();
			}
		}
	}

	//*	resituisce il proprietario del lock
	public
	synchronized
	Thread
	proprietario()
	{
		return proprietario;
	}

	//*	thread che detiene il lock
	private Thread proprietario = null;
	//*	livello di annidamento
	private int contatore = 0;
}
