package assfalg.esempi.sincronizzazione.variabile_condizione;

/**
 *	Realizzazione di memoria circolare mediante variabili di condizione.
 *	La classe dispone di due variabili di condizione, cvPieno e cvVuoto,
 *	usate per notificare ai thread in attesa che si sono verificate
 *	rispettivamente le condizioni di nuovo dato disponibile e nuova locazione
 *	libera.	Le due variabili condividono lo stesso lock di mutua escluzione
 *	per l'accesso alla sezione critica di aggiornamento della memoria.
 *
 *	@author	J&uml;urgen Assfalg
 *	@version 1.1 - 18/03/2003
 */

public
class
MemoriaCircolare
{
	//*	il costruttore richiede che sia specificata la dimensione del buffer
	public
	MemoriaCircolare
	(
		int dimensione
	)
	{
		this.dimensione = dimensione;
		ingresso = 0;
		uscita = 0;
		buffer = new Object[ dimensione ];
		mutex = new Mutex();
		cvPieno = new VariabileCondizione( mutex );
		cvVuoto = new VariabileCondizione( mutex );
	}

	//*	metodo per depositare un dato in memoria
	public
	void
	deposita
	(
		Object dato
	)
	{
		//	attende di poter accedere alla sezione critica
		mutex.attendi();
		//	in caso di buffer pieno...
		while ( pieno() )
		{
			try
			{
				//	...attende che si liberi una locazione
				cvVuoto.attendi();
			}
			catch ( InterruptedException ie ) {}
		}
		//	inserisce il dato in memoria
		buffer[ ingresso ] = dato;
		ingresso = ( ingresso + 1 ) % dimensione;
		//	notifica la disponibilita' di un nuovo dato
		cvPieno.notifica();
		//	rilascia la sezione critica
		mutex.rilascia();
	}

	//*	metodo per prelevare un dato dalla memoria
	public
	Object
	preleva()
	{
		//	attende di poter accedere alla sezione critica
		mutex.attendi();
		//	in caso di buffer vuoto...
		while ( vuoto() )
		{
			try
			{
				//	...attende che si renda disponibile un dato
				cvPieno.attendi();
			}
			catch ( InterruptedException ie ) {}
		}
		//	legge il dato dalla memoria
		Object dato = buffer[ uscita ];
		uscita = ( uscita + 1 ) % dimensione;
		//	notifica che e' stata liberata una locazione di memoria
		cvVuoto.notifica();
		//	rilascia la sezione critica
		mutex.rilascia();
		return dato;
	}

	private
	boolean
	pieno()
	{
		return ( ( ingresso + 1 ) % dimensione == uscita );
	}

	private
	boolean
	vuoto()
	{
		return ( ingresso == uscita );
	}

	//*	dimensione della memoria circolare
	private int dimensione = 0;
	//*	le locazioni di memoria in cui memorizzare i dato
	private Object[] buffer = null;
	//*	indice della prima locazione libera (in cui inserire un dato)
	private int ingresso = 0;
	//*	indice della prima locazione occupata (da cui leggere un dato)
	private int uscita = 0;
	//*	lock di mutua esclusione per l'accesso alla sezione critica
	private Mutex mutex;
	//*	variabile di condizione per segnalare disponibilit&agrave; di dati
	private VariabileCondizione cvPieno;
	//*	variabile di condizione per segnalare esistenza di locazioni libere
	private VariabileCondizione cvVuoto;
}
