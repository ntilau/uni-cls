package assfalg.esempi.sincronizzazione.regione_critica;

/**
 *	Crea la memoria circolare per lo scambio di dati ed i thread
 *	produttore e consumatore
 *
 *	@author	J&uml;urgen Assfalg
 *	@version 1.1 - 17/03/2003
 */

public
class
Main
{  
	/**	costante utilizzata nel calcolo del tempo per il quale i thread
		produttore e consumatore si sospendono (in secondi)	*/
	public static final int SLEEP_TIME = 5;

	public
	static
	void
	main
	(
		String[] argomenti
	)
	{
		//	crea la memoria condivisa
		MemoriaCircolare buffer = new MemoriaCircolare( 20 );
		//	crea i thread produttore e consumatore
		for ( int i = 0; i < 5; i++ )
		{
			Produttore produttore = new Produttore( buffer, SLEEP_TIME, i );
			produttore.start();
		}
		for ( int i = 0; i < 20; i++ )
		{
			Consumatore consumatore = new Consumatore( buffer, 0, i );
			consumatore.start();
		}
		/*	si osservi come, in questo caso, pur essendo terminata l'esecuzione               
			del thread principale (questo), il processo non termina, perche'
			altri 2 thread sono ancora in esecuzione	*/
	}
}
