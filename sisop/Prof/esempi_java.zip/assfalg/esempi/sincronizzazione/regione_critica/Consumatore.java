package assfalg.esempi.sincronizzazione.regione_critica;


/**
 *
 *	@author	J&uml;urgen Assfalg
 *	@version 1.2 - 17/03/2003
 */

public
class
Consumatore
extends
	Thread
{
	//*	costruttore della classe
	public
	Consumatore
	(
		MemoriaCircolare m,
		int mst,
		int id
	)
	{
		buffer = m;
		maxSleepTime = mst;
		this.id = id;
	}

	public
	void
	run()
	{
		String data;
		//	il consumatore viene eseguito all'infinito
		while ( true )
		{
			//	il thread sospende l'esecuzione per un periodo di tempo casuale
			int sleeptime = (int) ( maxSleepTime * Math.random() );
			System.out.println(
				"Consumatore " + id + " sospeso per " + sleeptime + " secondi"
			);
			try
			{ 
				sleep( sleeptime * 1000 ); 
			}
			catch(InterruptedException e) {}
			System.out.println( "Consumatore interroga il buffer" );
			//	se la memoria e' vuota, allora il thread si pone in busy wait
			while ( buffer.vuoto() );
			//	si definisce una regione critica per accedere al buffer
			synchronized( buffer )
			{
				try
				{
					//	preleva un dato dalla memoria 
					data = (String) buffer.preleva();
				}
				catch ( Exception e )
				{
					/*	qualcun'altro potrebbe aver svuotato la memoria nel
						periodo di tempo tra l'ultima interrogazione e
						l'acquisizione del lock
					*/
					System.err.println( "ERRORE: memoria vuota." );
					data = null;
				}
			}
			if ( null != data )
				System.out.println(
					"Consumatore " + id + " consuma il messaggio " + data
				);
		}
	}

	private MemoriaCircolare buffer;
	private int maxSleepTime;
	private int id;
}
