package assfalg.esempi.sincronizzazione.elementare;


/**
 *	Il programma mostra una semplice forma di sincronizzazione tra threads,
 *	in cui un primo thread attende il completamento dell'esecuzione di un
 *	secondo thread, ad esempio per poter leggere il risultato dell'elaborazione
 *	di quest'ultimo.
 *
 *	@version 2.0 - 25/05/2004
 *	@author Jurgen Assfalg
 */

public
class
Main
{
	public
	static
	void
	main
	(
		String[] argomenti
	)
	{
		if ( 3 != argomenti.length )
		{
			System.out.println(
				"usage:\n\tjava assfalg.esempi.sincronizzazione.elementare.Main <max_iter> <max_tempo> <periodo>"
			);
			System.exit( 1 );
		}
		int maxIterazioni = Integer.parseInt( argomenti[ 0 ] );
		int maxTempo = Integer.parseInt( argomenti[ 1 ] );
		int periodo = Integer.parseInt( argomenti[ 2 ] );
		CalcoloPiGreco c = new CalcoloPiGreco();
		Thread t = new Thread( c );
		t.start();
		Supervisore s = new Supervisore(
			maxIterazioni, maxTempo, periodo, c
		);
		s.start();
		//	si attende il completamento del thread supervisiore
		System.out.println(
			"thread principale si sospende in attesa del completamento del supervisore"
		);
		try
		{
			s.join();
		}
		catch ( InterruptedException ie ) {}
		//	interrompe l'elaborazione del calcolatore alla prossima iterazione
		c.interrompi();
		System.out.println(
			"thread principale si sospende in attesa del completamento del calcolatore"
		);
		//	si attende il completamento del thread calcolatore
		try
		{
			t.join();
		}
		catch ( InterruptedException ie ) {}
		System.out.println(
			"il valore di pi greco  e' " + c.valorePiGreco()
		);
	}
}
