/*
 * Supervisore.java
 *
 *	@version 2.0 - 25/05/2004
 *	@author Jurgen Assfalg
 */

package assfalg.esempi.sincronizzazione.elementare;

/**
 *	supervisiona il calcolo di pi greco, interrompendolo se &egrave; stato
 *	raggiunto un tempo massimo o se &egrave; stata raggiunta una determinata
 *	iterazione.
 *
 */
public
class
Supervisore
extends
	Thread
{
	
	/** Creates a new instance of Supervisore */
	public
	Supervisore
	(
		int maxIterazioni,
		int maxTempo,
		int periodo,
		CalcoloPiGreco cpg
	)
	{
		this.maxIterazioni = maxIterazioni;
		this.maxTempo = maxTempo;
		this.periodo = periodo;
		this.cpg = cpg;
	}

	public
	void
	run()
	{
		while( continua )
		{
			System.out.println( "il supervisore e' stato attivo per " + tempo + " secondi" );
			//	se sono soddisfatte le condizioni di arresto...
			if ( tempo >= maxTempo || cpg.iterazione() >= maxIterazioni )
			{
				System.out.println( "il supervisore ha rilevato una condizione di terminazione" );
				//	...determina la terminazione del thread
				continua = false;
			}
			else
			{
				//	si sospende per il periodo di tempo specificato
				try
				{
					Thread.sleep( 1000 * periodo );
				}
				catch ( InterruptedException ie ) {}
				tempo += periodo;
			}
		}
	}

	//	limite massimo di iterazioni
	private int maxIterazioni;
	//	periodo di tempo, espresso in secondi
	private int periodo;
	//	limite massimo di tempo, espresso in secondi
	private int maxTempo;
	//	tempo trascorso, espresso in secondi
	private int tempo = 0;
	//	riferimento all'oggetto che esegue il calcolo di pi greco
	private CalcoloPiGreco cpg;
	//	viene impostata a false quando si intende interrompere l'esecuzione
	boolean continua = true;
}
