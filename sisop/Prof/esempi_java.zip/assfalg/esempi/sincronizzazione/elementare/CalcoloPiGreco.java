package assfalg.esempi.sincronizzazione.elementare;

/**
 *	la classe consente di calcolare il valore di pi greco fino ad una
 *	determinata precisione, specificata come parametro al costruttore.
 *
 *	@version 2.0 - 25/05/2004
 *	@author Jurgen Assfalg
*/

public
class
CalcoloPiGreco
implements
	Runnable
{
	public
	CalcoloPiGreco()
	{
	}

	public
	String
	valorePiGreco()
	{
		return pi;
	}

	public
	void
	interrompi()
	{
		continua = false;
	}

	public
	int
	iterazione()
	{
		return iterazione;
	}

	public
	void
	run()
	{
		while ( continua )
		{
			iterazione++;
			System.out.println( "esecuzione dell'iterazione numero " + iterazione );
			int ritardo = (int) ( 10.0 * Math.random() );
			System.out.println( "simulazione dell'iterazione con un ritardo di " + ritardo + " secondi" );
			try
			{
				Thread.sleep( 1000 * ritardo );
			}
			catch( InterruptedException ie ) {}
			//	simula il valore di pi greco con un valore casuale
			pi = Double.toString( Math.random() );
		}
	}

	//	contiene la rappresentazione di Pi Greco sotto forma di stringa
	private String pi;
	//	indica l'iterazione corrente nel calcolo
	private int iterazione = 0;
	//	viene impostata a false quando si intende interrompere l'esecuzione
	private boolean continua = true;
}
