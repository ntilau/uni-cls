package assfalg.esempi.sincronizzazione.monitor;

/**
 *
 *	@author	J&uml;urgen Assfalg
 *	@version 1.0 - 17/03/2003
 */

public
class
Produttore
extends
	Thread
{
	//*	costruttore
	public
	Produttore
	(
		MemoriaCircolare m,
		int mst,
		int id
	)
	{
		buffer = m;
		maxSleepTime = mst;
		this.id = id;
	}              
   
	/**
	 *	metodo eseguito quando il thread e' avviato con il metodo start ed ad
	 *	ogni successivo scheduling per l'esecuzione
	 */
	public
	void
	run()
	{
		String data;
		//	il produttore genera messaggi all'infinito
		while ( true )
		{
			//	sospenda il produttore per un certo periodo di tempo
			int sleeptime = (int) ( maxSleepTime * Math.random() );
			System.out.println(
				"Produttore " + id + " sospeso per " + sleeptime + " secondi"
			);
			try
			{
				sleep(sleeptime*1000); 
			}
			catch(InterruptedException e) {}
			counter++;
			data = new String( "[prodotto " + counter + " del produttore " + id + "]" );
			System.out.println("Produttore " + id + " produce " + data );
			//	deposita il messaggio sulla memoria
			buffer.deposita( data );
		}
	}
   
	private MemoriaCircolare buffer;
	private int maxSleepTime;
	private int id;
	private int counter = 0;
}
