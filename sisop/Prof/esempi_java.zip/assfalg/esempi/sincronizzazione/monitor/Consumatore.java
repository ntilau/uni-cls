package assfalg.esempi.sincronizzazione.monitor;


/**
 *
 *	@author	J&uml;urgen Assfalg
 *	@version 1.0 - 17/03/2003
 */

public
class
Consumatore
extends
	Thread
{
	//*	costruttore della classe
	public
	Consumatore
	(
		MemoriaCircolare m,
		int mst,
		int id
	)
	{
		buffer = m;
		maxSleepTime = mst;
		this.id = id;
	}

	public
	void
	run()
	{
		String data;
		//	il consumatore viene eseguito all'infinito
		while ( true )
		{
			//	il thread sospende l'esecuzione per un periodo di tempo casuale
			int sleeptime = (int) ( maxSleepTime * Math.random() );
			System.out.println(
				"Consumatore " + id + " sospeso per " + sleeptime + " secondi"
			);
			try
			{ 
				sleep( sleeptime * 1000 ); 
			}
			catch(InterruptedException e) {}
			System.out.println( "Consumatore interroga il buffer" );
			//	preleva un dato dalla memoria 
			data = (String) buffer.preleva();
			if ( null != data )
				System.out.println(
					"Consumatore " + id + " consuma il messaggio " + data
				);
		}
	}

	private MemoriaCircolare buffer;
	private int maxSleepTime;
	private int id;
}
