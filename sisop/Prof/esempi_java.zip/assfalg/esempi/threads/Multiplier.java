/*
 * Multiplier.java
 *
 * Created on 7 marzo 2004, 18.50
 */

package assfalg.esempi.threads;

import java.math.BigInteger;

/**
 *
 * @author  jurgen
 */
public class Multiplier implements Runnable
{
	
	private int base;
	
	private int limit;
	
	private BigInteger product;
	
	/** Creates a new instance of Multiplier */
	public
	Multiplier
	(
		int base,
		int limit
	)
	{
		this.base = base;
		this.limit = limit;
	}
	
	public void run()
	{
		product = new BigInteger( "1" );
		for ( int i = base; i <= limit; i++ )
		{
			Integer operand = new Integer( i );
			product = product.multiply( new BigInteger( operand.toString() ) );
			System.out.println( product );
		}
	}
	
	public BigInteger getProduct()
	{
		return product;
	}

	public static void main( String[] args )
	{
		Multiplier m = new Multiplier( 1, 10 );
		m.run();
		System.out.println( m.getProduct() );
	}
}
