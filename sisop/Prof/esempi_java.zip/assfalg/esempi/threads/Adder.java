/*
 * Adder.java
 *
 * Created on 7 marzo 2004, 19.25
 */

package assfalg.esempi.threads;

/**
 * Sommatore parallelo.
 * La classe esemplifica l'uso dei threads per parallelizzare l'esecuzione
 * dell'operazione di somma su un vettore di interi.
 *
 * @author  J&uuml;rgen Assfalg
 */
public class Adder extends Thread
{
	
	private int[] data;

	private int start;

	private int end;

	private int sum;

	private int id = 0;

	/** Creates a new instance of Adder */
	public Adder(int[] data, int start, int end, int id)
	{
		this.data = data;
		this.start = start;
		this.end = end;
		this.id = id;
	}
	
	public void run()
	{
		sum = 0;
		for ( int i = start; i <= end; i++ )
		{
			sum += data[ i ];
		}
		try
		{
			Thread.sleep( 10 * sum );
		}
		catch ( InterruptedException ie ) {}
		System.out.println( "Adder thread #" + id + " completed." );
	}
	
	public int getSum()
	{
		return sum;
	}
	
	public static void main(String[] args)
	{
		int m = 99;
		int n = 10;
		int[] data = new int[ m ];
		Adder[] adders = new Adder[ n ];
		for ( int i = 0; i < m; i++ )
		{
			//	data[ i ] = (int) ( Math.random() * 100 );
			data[ i ] = i;
		}
		int job_size = m / n + ( 0 == ( m % n ) ? 0 : 1 );
		for ( int j = 0; j < n; j++ )
		{
			int start = j * job_size;
			int end = start + ( ( j + 1 == n ) && ( 0 != m % n ) ? m % n : job_size ) - 1;
			adders[ j ] = new Adder( data, start , end, j );
			adders[ j ].start();
		}
		int sum = 0;
		for ( int j = 0; j < n; j++ )
		{
			try
			{
				adders[ j ].join();
			}
			catch ( InterruptedException ie ) {}
			sum += adders[ j ].getSum();
			System.out.println( "Partial sum: " + sum );
		}
		System.out.println( "Total: " + sum );
	}
}
