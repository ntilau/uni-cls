package assfalg.esempi.semafori;

/**
 *	Verifica l'uso del semaforo in uno scenario tipo sezione critica.
 */
public
class
PrimaProvaSemaforo
extends
	Thread
{
	public
	PrimaProvaSemaforo
	(
		Semaforo s,
		int n
	)
	{
		this.s = s;
		this.n = n;
	}

	public
	void
	run()
	{
		System.out.println( "sono il thread " + n + ", e cerco di accedere alla sezione critica" );
		try
		{
			s.attendi();
			System.out.println( "sono il thread " + n + ", e sono in sezione critica" );
			Thread.sleep( 1000 );
		}
		catch ( InterruptedException ie ) {}
		System.out.println( "sono il thread " + n + ", e sto per lasciare la sezione critica" );
		s.segnala();
		System.out.println( "sono il thread " + n + ", ed ho lasciato la sezione critica" );
	}

	protected Semaforo s;
	protected int n;

	public
	static
	void
	main
	(
		String[] args
	)
	{
		Semaforo s = new Semaforo( 1 );
		for ( int i = 0; i < 3; i++ )
		{
			Thread t = new PrimaProvaSemaforo( s, i );
			t.start();
		}
	}
}
