package assfalg.esempi.semafori;

import java.util.LinkedList;

/**
 *	Implementazione di un semaforo con contatore.
 *
 *	La classe implementa un semaforo con contatore, nell'ipotesi di non
 *	conoscere la politica di accodamento utilizzata dai monitor di Java.
 *	Per poter implementare la politica FIFO, &egrave; allora necessario
 *	che, a seguito di una SIGNAL, siano risvegliati tutti i threads, e
 *	ciascuno verifica se &egrave; il primo della coda. Solo il primo
 *	potr&agrave; procedere, mentre gli altri si rimetteranno in attesa.
 *
 *	@author J&uuml;rgen Assfalg
 */

public
class
Semaforo
{
	public
	Semaforo
	(
		int contatore
	)
	{
		this.contatore = contatore;
		this.coda = new LinkedList();
		threadSbloccato = null;
	}

	//*	esegue la WAIT sul semaforo
	public
	synchronized
	void
	attendi()
	throws
		InterruptedException
	{
		//	anzitutto si decrementa il contatore associato al semaforo
		contatore--;
		//	se il contatore ha valore negativo, il thread deve essere bloccato
		if ( 0 > contatore )
		{
			//	si inserisce il thread corrente in coda,
			coda.add( Thread.currentThread() );
			boolean sbloccato = false;
			//	si mantiene bloccato finche' non diviene il primo della coda
			while ( ! sbloccato )
			{
				this.wait();
				/* si verifica se il thread corrente e' il primo della coda,
				 * e nessun altro thread e' stato sbloccato (infatti, solo
				 * se threadSbloccato assume il valore null, il thread
				 * corrente e' veramente il primo, altrimenti e' il secondo,
				 * perche' il primo si e' gia' tolto dalla coda)
				 */
				sbloccato = (
					Thread.currentThread() == (Thread) coda.getFirst()
					&& null == threadSbloccato
				);
			}
			//	poiche' soddisfa la condizione e viene rimosso dalla coda
			threadSbloccato = (Thread) coda.removeFirst();
		}
	}

	//*	esegue la SIGNAL sul semaforo
	public
	synchronized
	void
	segnala()
	{
		//	si incrementa il valore del contatore
		contatore++;
		//	se questo e' non positivo, c'e' almeno un thread in coda
		if ( 0 >= contatore )
		{
			//	si deve quindi individuare il thread da sbloccare
			threadSbloccato = null;
			//	non conoscendo la politica di accodamento si risvegliano tutti
			this.notifyAll();
		}
	}

	//*	la variabile contatore associata al semaforo
	protected int contatore;
	//*	la coda dei threads in attesa sul semaforo
	protected LinkedList coda;
	//*	il thread che pu&ograve; essere sbloccato (cioe' il primo della coda)
	protected Thread threadSbloccato;
}
