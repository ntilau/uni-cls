package assfalg.esempi.semafori;

/**
 *	Verifica l'uso del semaforo in uno scenario tipo numero di risorse (usa e getta) limitate
 */

public
class
SecondaProvaSemaforo
extends
	Thread
{
	public
	SecondaProvaSemaforo
	(
		Semaforo s,
		int n
	)
	{
		this.s = s;
		this.n = n;
	}

	public
	void
	run()
	{
		try
		{
			s.attendi();
		}
		catch ( InterruptedException ie ) {}
		System.out.println( "sono il thread " + n + ", e sono passato" );
	}

	protected Semaforo s;
	protected int n;

	public
	static
	void
	main
	(
		String[] args
	)
	{
		Semaforo s = new Semaforo( 2 );
		for ( int i = 0; i < 3; i++ )
		{
			Thread t = new SecondaProvaSemaforo( s, i );
			t.start();
		}
		try
		{
			System.out.println( "SecondaProvaSemaforo.main] il thread principale si sospende" );
			Thread.sleep( 1000 );
			System.out.println( "SecondaProvaSemaforo.main] il thread principale si riattiva" );
		}
		catch ( InterruptedException iex ) {}
		//	crea una nuova risorsa
		s.segnala();
	}
}
