package assfalg.esempi.tcpserver;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.net.InetSocketAddress;

/**
 *
 * @author  jurgen
 */
public
class
NIOMOTDServer
{
	public static final String MOTD = "Mot of the day\r\n";

	/** Creates a new instance of NIOMOTDServer */
	public
	NIOMOTDServer
	(
		int port
	)
	{
		this.port = port;
		buffer = ByteBuffer.wrap( MOTD.getBytes() );
	}

	public
	void
	run()
	{
		try
		{
			ServerSocketChannel server_channel = ServerSocketChannel.open();
			server_channel.socket().bind( new InetSocketAddress( port ) );
			server_channel.configureBlocking( false );
			while( true )
			{
				SocketChannel client_channel = server_channel.accept();
				if ( null != client_channel )
				{
					buffer.rewind();
					client_channel.write( buffer );
					client_channel.close();
				}
				else
				{
					try
					{
						Thread.sleep( 5000 );
					}
					catch ( InterruptedException ie ) {}
				}
			}
		}
		catch ( IOException ioe )
		{
			System.err.println( "ERROR: some I/O error occurred." );
		}
	}

	//*	the port the service must listen to
	private int port;
	//*	temporary data buffer
	private ByteBuffer buffer;

	public
	static
	void
	main
	(
		String[] args
	)
	{
		if ( 1 != args.length )
		{
			System.err.println( "ERROR: service port not specified." );
			System.exit( 1 );
		}
		try
		{
			int port = Integer.parseInt( args[ 0 ] );
			NIOMOTDServer server = new NIOMOTDServer( port );
			server.run();
		}
		catch ( NumberFormatException nfe )
		{
			System.err.println( "ERROR: service port must be an integer value." );
		}
	}
}
