package assfalg.esempi.tcpserver;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.nio.channels.Selector;
import java.nio.channels.SelectionKey;
import java.nio.channels.SelectableChannel;
import java.net.InetSocketAddress;
import java.util.Iterator;

/**
 *
 * @author  jurgen
 */
public
class
NIOEchoServer
{
	public
	class
	SessionState
	{
		public
		void
		updateReceivedChars
		(
			int receivedBytes
		)
		{
			this.receivedBytes += receivedBytes;
		}

		public
		int
		getReceivedBytes()
		{
			return receivedBytes;
		}

		private int receivedBytes = 0;
	}
	
	/** Creates a new instance of NIOEchoServer */
	public
	NIOEchoServer
	(
		int port
	)
	{
		this.port = port;
		buffer = ByteBuffer.allocateDirect( 1024 );
	}

	public
	void
	run()
	{
		Selector selector = null;
		try
		{
			ServerSocketChannel server_channel = ServerSocketChannel.open();
			server_channel.socket().bind( new InetSocketAddress( port ) );
			server_channel.configureBlocking( false );
			selector = Selector.open();
			server_channel.register( selector, SelectionKey.OP_ACCEPT );
		}
		catch ( IOException ioe )
		{
			System.err.println( "ERROR: could not open server port." );
		}
		System.out.println ( "INFO: server listening on port " + port );
		while( true )
		{
			try
			{
				int n = selector.select();
				Iterator it = selector.selectedKeys().iterator();
				while( it.hasNext() )
				{
					SelectionKey key = (SelectionKey) it.next();
					it.remove();
					if( key.isAcceptable() )
					{
						ServerSocketChannel server = (ServerSocketChannel) key.channel();
						SocketChannel client_channel = server.accept();
						if ( null == client_channel )
						{
							System.err.println( "WARNING: could not get client channel." );
						}
						client_channel.configureBlocking( false );
						client_channel.register( selector, SelectionKey.OP_READ );
					}
					if( key.isReadable() )
					{
						handle( key );
					}
				}
			}
			catch ( IOException ioe )
			{
			}
		}
	}

	protected
	void
	handle
	(
		SelectionKey key
	)
	throws
		IOException
	{
		SessionState session_state = (SessionState) key.attachment();
		if ( null == session_state )
		{
			session_state = new SessionState();
			key.attach( session_state );
		}
		SocketChannel channel = (SocketChannel) key.channel();
		buffer.clear();
		int count;
		while ( ( count = channel.read( buffer ) ) > 0 )
		{
			buffer.flip();
			session_state.updateReceivedChars( buffer.limit() );
			while ( buffer.hasRemaining() )
			{
				channel.write( buffer );
			}
			buffer.clear();
		}
		if ( count < 0 )
		{
			System.out.println( "INFO: " + session_state.getReceivedBytes()
				+ " bytes received during session." );
			channel.close();
			key.attach( null );
		}
	}

	//*	the port the service must listen to
	private int port;
	//*	temporary data buffer
	private ByteBuffer buffer;

	public
	static
	void
	main
	(
		String[] args
	)
	{
		if ( 1 != args.length )
		{
			System.err.println( "ERROR: service port not specified." );
			System.exit( 1 );
		}
		try
		{
			int port = Integer.parseInt( args[ 0 ] );
			NIOEchoServer server = new NIOEchoServer( port );
			server.run();
		}
		catch ( NumberFormatException nfe )
		{
			System.err.println( "ERROR: service port must be an integer value." );
		}
	}
}
