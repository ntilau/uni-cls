package assfalg.esempi.tcpserver;

import java.net.ServerSocket;
import java.net.Socket;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/**
 *	Single threaded echo server.
 *
 *	This class exemplifies a single threaded TCP server, implementing a trivial echo service.
 *
 *	@author  J&uuml;rgen Assfalg
 */
public
class
STEchoServer
{
    
    /** Creates a new instance of STServer */
	public
	STEchoServer
	(
		int port
	)
	{
		this.port = port;
	}

	public
	void
	run()
	{
		int chars_total = 0;
		ServerSocket server_socket = null;
		try
		{
			server_socket = new ServerSocket( port );
		}
		catch ( IOException ioe )
		{
			System.err.println( "ERROR: could not bind to server socket." );
			return;
		}
		while ( true )
		{
			InputStream is = null;
			OutputStream os = null;
			Socket client_socket = null;
			int chars_session = 0;
			try
			{
				client_socket = server_socket.accept();
				System.out.println( "INFO: session started." );
				is = client_socket.getInputStream();
				os = client_socket.getOutputStream();
				int data = is.read();
				while ( -1 != data )
				{
					os.write( (byte) data );
					chars_session++;
					data = is.read();
				}
			}
			catch ( IOException ioe )
			{
			}
			finally
			{
				try
				{
					if ( null != is )
						is.close();
					if ( null != os )
						os.close();
					if ( null != client_socket )
						client_socket.close();
				}
				catch (  IOException ioe )
				{
				}
				chars_total += chars_session;
				System.out.println( "INFO: session closed." );
				System.out.println( "INFO: sent " + chars_session + " characters"
					+ " (total " + chars_total + ")"
				);
			}
		}
	}

	//*	the port the service must listen to
	private int port;

	public
	static
	void
	main
	(
		String[] args
	)
	{
		if ( 1 != args.length )
		{
			System.err.println( "ERROR: service port not specified." );
			System.exit( 1 );
		}
		try
		{
			int port = Integer.parseInt( args[ 0 ] );
			STEchoServer server = new STEchoServer( port );
			server.run();
		}
		catch ( NumberFormatException nfe )
		{
			System.err.println( "ERROR: service port must be an integer value." );
		}
	}

}
