package assfalg.esempi.prodcons;

public
class
Produttore
extends
	Thread
{
	public
	Produttore
	(
		Memoria b,
		int mst
	)
	{
		buffer = b;
		maxSleepTime = mst;
	}

	public
	void
	run()
	{
		//	finche' il thread non viene interrotto...
		while ( continua )
		{
			//	... produce informazione, ...
			Double d = new Double( Math.random() );
			//	... attende che ci sia spazio in memoria, ...
			while ( buffer.pieno() );
			try
			{
				//	... ed infine deposita il dato.
				buffer.deposita( d );
			}
			catch ( Exception e ) {}
			System.out.println( "Inserito il valore " + d );

			int sleeptime = (int) ( maxSleepTime * Math.random() );
			System.out.println(
				"Produttore sospeso per " + sleeptime + " secondi"
			);
			try
			{ 
				sleep( sleeptime * 1000 ); 
			}
			catch(InterruptedException e) {}
		}
	}

	public
	void
	interrompi()
	{
		continua = false;
	}

	Memoria buffer = null;
	boolean continua = true;
	private int maxSleepTime;
}
