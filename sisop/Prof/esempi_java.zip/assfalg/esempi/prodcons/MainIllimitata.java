package assfalg.esempi.prodcons;

public class MainIllimitata
{  
	/**	costante utilizzata nel calcolo del tempo per il quale i thread
		produttore e consumatore si sospendono (in secondi)	*/
	public static final int SLEEP_TIME = 5;

	public
	static
	void
	main
	(
		String[] argomenti
	)
	{
		//	crea la memoria temporanea
		Memoria buffer = new MemoriaIllimitata();
		//	crea gli oggetti thread per produttore e consumatore
		Produttore produttore = new Produttore( buffer, SLEEP_TIME );
		Consumatore consumatore = new Consumatore( buffer, SLEEP_TIME );
		//	crea i thread nella JVM che puo' schedularli per l'esecuzione
		produttore.start();
		consumatore.start();
		/*	si osservi come, in questo caso, pur essendo terminata l'esecuzione               
			del thread principale (questo), il processo non termina, perche'
			altri 2 thread sono ancora in esecuzione	*/
	}
}

