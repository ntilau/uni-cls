package assfalg.esempi.prodcons;

public
class
Consumatore
extends
	Thread
{
	public
	Consumatore
	(
		Memoria b,
		int mst
	)
	{
		buffer = b;
		maxSleepTime = mst;
	}

	public
	void
	run()
	{
		//	finche' il thread non e' interrotto o ci sono dati in memoria, ...
		while ( continua || ( ! buffer.vuoto() ) )
		{
			//	... attende la disponibilita' di nuovi dati
			while ( buffer.vuoto() );
			Double d;
			try
			{
				//	... per prelevarli.
				d = (Double) buffer.preleva();
				System.out.println( "Prelevato il valore " + d );
			}
			catch ( Exception e ) {}

			int sleeptime = (int) ( maxSleepTime * Math.random() );
			System.out.println(
				"Consumatore sospeso per " + sleeptime + " secondi"
			);
			try
			{ 
				sleep( sleeptime * 1000 ); 
			}
			catch(InterruptedException e) {}
		}
	}

	public
	void
	interrompi()
	{
		continua = false;
	}

	Memoria buffer = null;
	boolean continua = true;
	private int maxSleepTime;
}
