package assfalg.esempi.prodcons;

public class MainLimitata
{
	public static void main( String[] args )
	{
		//	crea una memoria condivisa di capacita' limitata
		MemoriaCircolare b = new MemoriaCircolare( 20 );
		/*	crea un oggetto di tipo Produttore, indicando la memoria condivisa
			in cui depositare i dati	*/
		Produttore p = new Produttore( b );
		/*	crea un oggetto di tipo Consumatore, indicando la memoria condivisa
			da cui prelevare i dati	*/
		Consumatore c = new Consumatore( b );
		//	avvia il thread consumatore
		c.start();
		//	avvia il thread produttore
		p.start();
		//	il thread principale (cioe' questo) si pone in attesa (10 secondi)
		try
		{
			Thread.sleep( 10000 );
		}
		catch ( InterruptedException ie ) {}
		//	interrompe i threads produttore e consumatore
		p.interrompi();
		c.interrompi();
		/*	il thread principale si blocca in attesa che il thread consumatore
			termini la sua esecuzione	*/
		try
		{
			c.join();
		}
		catch ( InterruptedException ie ) {}
	}
}
