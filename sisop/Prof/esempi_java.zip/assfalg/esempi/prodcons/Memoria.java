/*
 * Memoria.java
 *
 * Created on 21 marzo 2004, 21.40
 */

package assfalg.esempi.prodcons;

/**
 * Quest'interfaccia definisce i metodi per gestire un buffer nel problema
 * produttore-consumeatore.
 *
 * @author  J&uuml;rgen Assfalg
 */
public interface Memoria
{
	public void deposita( Object o ) throws Exception;
	public Object preleva() throws Exception;
	public boolean pieno();
	public boolean vuoto();
}
