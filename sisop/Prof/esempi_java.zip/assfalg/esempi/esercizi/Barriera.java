package assfalg.esempi.esercizi;

public
class
Barriera
{
	public
	Barriera
	(
		int numThreads
	)
	{
		this.numThreads = numThreads;
		inAttesa = 0;
	}

	public
	synchronized
	void
	attendi()
	{
		if ( inAttesa + 1 == numThreads )
		{
			System.out.println( "sblocco i threads bloccati" );
			inAttesa = 0;
			this.notifyAll();
			
		}
		else
		{
			inAttesa++;
			System.out.println( inAttesa + " threads bloccati" );
			try
			{
				this.wait();
			}
			catch( InterruptedException ie ) {};
		}
	}

	protected int numThreads;
	protected int inAttesa;
}
