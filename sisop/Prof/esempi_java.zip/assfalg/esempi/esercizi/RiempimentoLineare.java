/*
 * RiempimentoLineare.java
 *
 * Created on 15 giugno 2004, 22.30
 */

package assfalg.esempi.esercizi;

public
class
RiempimentoLineare
extends
	Thread
{
	public
	RiempimentoLineare
	(
		int[] dati,
		Blocco inizio,
		Blocco fine
	)
	{
		this.dati = dati;
		this.inizio = inizio;
		this.fine = fine;
	}

	public
	void
	run()
	{
		System.out.println( "avviato riempimento" );
		inizio.attendi();
		System.out.println( "sbloccato riempimento" );
		for( int i = 0; i < dati.length; i++ )
			dati[ i ] = i;
		int[] copia = new int[ dati.length ];
		System.arraycopy( dati, 0, copia, 0, dati.length );
		fine.segnala();
		System.out.println( "terminato riempimento" );
		for( int i = 0; i < dati.length; i++ )
			System.out.println( "v[" + i + "]=" + copia[ i ] );
		System.out.println( "fine valori" );
	}

	protected int[] dati;
	protected Blocco inizio;
	protected Blocco fine;
}