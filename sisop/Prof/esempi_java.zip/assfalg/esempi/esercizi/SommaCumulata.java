/*
 * SommaCumulata.java
 *
 * Created on 15 giugno 2004, 22.32
 */

package assfalg.esempi.esercizi;

public
class
SommaCumulata
extends
	Thread
{
	public
	SommaCumulata
	(
		int[] dati,
		Blocco inizio,
		Blocco fine
	)
	{
		this.dati = dati;
		this.inizio = inizio;
		this.fine = fine;
	}

	public
	void
	run()
	{
		System.out.println( "avviata somma" );
		inizio.attendi();
		System.out.println( "sbloccata somma" );
		int somma = 0;
		for( int i = 0; i < dati.length; i++ )
		{
			somma += dati[ i ];
			dati[ i ] = somma;
		}
		fine.segnala();
		System.out.println( "terminata somma" );
		for( int i = 0; i < dati.length; i++ )
			System.out.println( "s[" + i + "]=" + dati[ i ] );
		System.out.println( "terminati valori somma" );
	}

	protected int[] dati;
	protected Blocco inizio;
	protected Blocco fine;
}