/*
 * Compito.java
 *
 * Created on 28 aprile 2004, 22.06
 */

package src.assfalg.esempi.esercizi;

class
Locazione
{
	public
	Locazione()
	{
		occupata = false;
	}

	public
	void
	deposita
	(
		String o
	)
	{
		occupata = true;
		dato = o;
	}

	public
	String
	preleva()
	{
		occupata = false;
		return dato;
	}

	public
	boolean
	occupata()
	{
		return occupata;
	}

	private String dato = null;
	boolean occupata = false;
}

class
Pila
{
	public
	Pila
	(
		int n
	)
	{
		riempimento = 0;
		dimensione = n;
		dati = new String[ dimensione ];
	}

	public
	synchronized
	void
	deposita
	(
		String o
	)
	{
		dati[ riempimento ] = o;
		riempimento++;
	}

	public
	synchronized
	String
	preleva()
	{
		riempimento--;
		String dato = dati[ riempimento ];
		return dato;
	}

	public
	boolean
	piena()
	{
		return ( riempimento == dimensione );
	}

	private String[] dati = null;
	private int riempimento;
	private int dimensione;
}

public
class
Compito
extends
Thread
{
	public
	Compito
	(
		Locazione l,
		Pila p,
		int i
	)
	{
		locazione = l;
		pila = p;
		id = i;
	}

	public
	void
	run()
	{
		System.out.println( "iniziato thread # " + id );
		synchronized( locazione )
		{
			if ( ! locazione.occupata() )
			try
			{
				locazione.wait();
			}
			catch ( InterruptedException ie ) {}
		}
		System.out.println( "prosecuzione thread # " + id );
		String s = locazione.preleva();
		pila.deposita( s.toUpperCase() );
		synchronized( pila )
		{
			if ( pila.piena() )
				pila.notify();
		}
		System.out.println( "terminato thread # " + id );
	}

	private Locazione locazione;
	private Pila pila;
	private int id;

	static final int N = 5;
	static final String ALFABETO = "abcdefghijklmnopqrstuvwxyz";

	public
	static
	void
	main
	(
		String[] args
	)
	{
		Pila p = new Pila( N );
		Locazione[] locazioni = new Locazione[ N ];
		Thread[] threads = new Thread[ N ];
		for ( int i = 0; i < N; i++ )
		{
			locazioni[ i ] = new Locazione();
			threads[ i ] = new Compito( locazioni[ i ], p, i );
			threads[ i ].start();
			System.out.println( "avviato thread # " + i );
		}
		System.out.println( "completata creazione threads" );
		for ( int i = 0; i < N; i++ )
		{
			synchronized( locazioni[ i ] )
			{
				locazioni[ i ].deposita( ALFABETO.substring( i, i + 1 ) );
				locazioni[ i ].notify();
			}
		}
		try
		{
			synchronized( p )
			{
				if ( ! p.piena() )
					p.wait();
			}
		}
		catch ( InterruptedException ie ) {}
		for ( int i = 0; i < N; i++ )
		{
			System.out.println( p.preleva().toString() );
		}
	}
	
}
