/*
 * SommaCumulata.java
 *
 * Created on 15 giugno 2004, 22.11
 */

package assfalg.esempi.esercizi;

/**
 *
 * @author  jurgen
 */
public
class
SommaCumulataMain
{
	/**
	 * @param args the command line arguments
	 */
	public static void main(String[] args)
	{
		int N = Integer.parseInt( args[ 0 ] );
		int[] dati = new int[ N ];
		Blocco b1 = new Blocco();
		Blocco b2 = new Blocco();
		Blocco b3 = new Blocco();
		Thread t1 = new RiempimentoLineare( dati, b1, b2 );
		Thread t2 = new SommaCumulata( dati, b2, b3 );
		t1.start();
		t2.start();
		b1.segnala();
		b3.attendi();
		System.out.println( "la somma e' " + dati[ dati.length - 1 ] );
	}
	
}
