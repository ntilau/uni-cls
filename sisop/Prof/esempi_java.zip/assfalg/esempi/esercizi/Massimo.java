/*
 * Massimo.java
 *
 * Created on 2 giugno 2004, 18.50
 */

package assfalg.esempi.esercizi;

/**
 *	Determina il valore massimo.
 *	La classe descrive un thread che determina il massimo valore fra quelli
 *	contenuti negli elementi di un vettore di double.
 *
 *	@author  J&uuml;rgen Assfalg
 */
public
class
Massimo
extends
	Thread
{
	
	/** Creates a new instance of Massimo */
	public
	Massimo
	(
		double[] vettore
	)
	{
		this.vettore = vettore;
	}

	public
	void
	run()
	{
		massimo = Double.MIN_VALUE;
		for( int i = 0; i < vettore.length; i++ )
		{
			if ( vettore[ i ] > massimo )
				massimo = vettore[ i ];
			System.out.println( "#" + i + " massimo: " + massimo );
		}
		System.out.println( "completata la determinazione del massimo." );
	}

	public
	double
	massimo()
	{
		return massimo;
	}

	private double[] vettore;
	private double massimo;
}
