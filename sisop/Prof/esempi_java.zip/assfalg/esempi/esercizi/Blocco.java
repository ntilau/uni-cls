/*
 * Blocco.java
 *
 * Created on 15 giugno 2004, 22.31
 */

package assfalg.esempi.esercizi;

public
class
Blocco
{
	public
	Blocco()
	{
		bloccato = true;
	}

	public
	synchronized
	void
	segnala()
	{
		bloccato = false;
		notifyAll();
	}

	public
	synchronized
	void
	attendi()
	{
		if ( bloccato )
			try
			{
				wait();
			}
			catch ( InterruptedException ie ) {}
	}

	protected boolean bloccato = true;
}
