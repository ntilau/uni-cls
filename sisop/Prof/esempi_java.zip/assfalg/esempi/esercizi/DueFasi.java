package assfalg.esempi.esercizi;

import java.math.BigInteger;
import assfalg.esempi.threads.Multiplier;

public
class
DueFasi
extends
	Thread
{
    public
    DueFasi
    (
		Barriera barriera,
		int numero
    )
    {
		this.barriera = barriera;
		this.numero = numero;
    }

    public
    void
    run()
    {
		Multiplier m = new Multiplier( 1, numero );
		m.run();
		System.out.println( "n=" + numero + "; fatto!" );
		barriera.attendi();
		BigInteger f = m.getProduct();
		System.out.println( "n=" + numero + "; fattoriale=" + f );
    }

	public
	static
	void
	main
	(
		String[] args
	)
	{
        int M = 10;
        Barriera b = new Barriera( M );
        for ( int i = 1; i <= M; i++ )
        {
            DueFasi df = new DueFasi( b, i );
			df.start();
		}
	}

    protected Barriera barriera;
    protected int numero;
}
