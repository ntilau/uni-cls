public class VirtualMachine {

	// 	opcodes: arithmetic

	public static final int opcodeAdd = 1000;
	public static final int opcodeSub = 1001;
	public static final int opcodeMul = 1002;
	public static final int opcodeDiv = 1003;

	//	opcodes: control
	public static final int opcodeHalt = 2000;

	//	opcodes: in/out
	public static final int opcodeOut = 3000;

	//	opcodes: memory	
	public static final int opcodeLoadImmediate = 4000;

	private int[] codeMemory  = null;

	//	cpu internal registers
	private int programCounter = 0;
	private int accumulator = 0;

	public VirtualMachine( int[] code )
	{
		codeMemory = code;
	}

	protected void loadImmediate()
	{
		accumulator = codeMemory[ programCounter ];
		programCounter++;
	}

	protected void add()
	{
		accumulator += codeMemory[ programCounter ];
		programCounter++;
	}

	protected void sub()
	{
		accumulator -= codeMemory[ programCounter ];
		programCounter++;
	}

	protected void mul()
	{
		accumulator *= codeMemory[ programCounter ];
		programCounter++;
	}

	protected void div()
	{
		accumulator /= codeMemory[ programCounter ];
		programCounter++;
	}

	protected void halt()
	{
		System.out.println( "Execution terminated normally." );
		System.exit( 0 );
	}

	protected void out()
	{
		System.out.println( accumulator );
	}

	private void run() throws Exception
	{
		while ( true )
		{
			//	fetch
			int opcode = codeMemory[ programCounter ];
			//	update program counter
			programCounter++;
			//	decode and execute instructions
			switch( opcode )
			{
				case VirtualMachine.opcodeAdd:
					add();
					break;
				case VirtualMachine.opcodeSub:
					sub();
					break;
				case VirtualMachine.opcodeMul:
					mul();
					break;
				case VirtualMachine.opcodeDiv:
					div();
					break;
				case VirtualMachine.opcodeHalt:
					halt();
					break;
				case VirtualMachine.opcodeOut:
					out();
					break;
				case VirtualMachine.opcodeLoadImmediate:
					loadImmediate();
					break;
				default :
					throw new Exception( "unknown opcode." );
			}
		}
	}	


	public static void main( String[] args )
	{
		int[] code = new int[ 10 ];
		code[ 0 ] = VirtualMachine.opcodeLoadImmediate;
		code[ 1 ] = 6;	//	acc = 6
		code[ 2 ] = VirtualMachine.opcodeAdd;
		code[ 3 ] = 2;	//	acc = 8
		code[ 4 ] = VirtualMachine.opcodeMul;
		code[ 5 ] = 3;	//	acc = 24
		code[ 6 ] = VirtualMachine.opcodeSub;
		code[ 7 ] = 30;//	acc = -6
		code[ 8 ] = VirtualMachine.opcodeOut;
		code[ 9 ] = VirtualMachine.opcodeHalt;
		VirtualMachine vm = new VirtualMachine( code );
		try
		{
			vm.run();
		}
		catch ( Exception e )
		{
			System.out.println( "Execution terminated abnormally." );
			e.printStackTrace();
			System.exit( 1 );
		}
	}
}