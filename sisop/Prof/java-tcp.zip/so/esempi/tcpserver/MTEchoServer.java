package so.esempi.tcpserver;

import java.net.ServerSocket;
import java.net.Socket;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/**
 *	Multi-threaded echo server.
 *
 *	This class exemplifies a multi-threaded TCP server, implementing a trivial echo service.
 *
 *	@author  J&uuml;rgen Assfalg
 */
public
class
MTEchoServer
{
	/**
	 *	Statistical data,
	 *
	 *	This class holds statistical data (i.e. the number of active threads, and the number of bytes sent during sessions already completed.
	 */
	public
	class
	StatData
	{
		synchronized
		public
		void
		threadStarted()
		{
			threads++;
		}

		synchronized
		public
		void
		threadCompleted
		(
			int bytesSent
		)
		{
			threads--;
			bytes += bytesSent;
		}

		public
		int
		getNumberOfActiveThreads()
		{
			return threads;
		}

		public
		int
		getNumberOfBytesSent()
		{
			return bytes;
		}

		private int threads = 0;
		private int bytes = 0;
	}

	/**
	 *	Request handler.
	 *
	 *	Handles the request of a single client.
	 *	Updates statistical data before and after serving the client.
	 */
	public
	class
	Handler
	extends
	Thread
	{
		Handler
		(
			Socket clientSocket,
			StatData statData
		)
		{
			this.clientSocket = clientSocket;
			this.statData = statData;
		}

		public
		void
		run()
		{
			statData.threadStarted();
			InputStream is = null;
			OutputStream os = null;
			int chars_session = 0;
			try
			{
				is = clientSocket.getInputStream();
				os = clientSocket.getOutputStream();
				int data = is.read();
				while ( -1 != data )
				{
					os.write( (byte) data );
					chars_session++;
					data = is.read();
				}
			}
			catch ( IOException ioe )
			{
			}
			finally
			{
				try
				{
					if ( null != is )
						is.close();
					if ( null != os )
						os.close();
					if ( null != clientSocket )
						clientSocket.close();
				}
				catch (  IOException ioe )
				{
				}
			}
			statData.threadCompleted( chars_session );
		}

		private Socket clientSocket;
		private StatData statData;
	}
	/** Creates a new instance of MTEchoServer */
	public
	MTEchoServer
	(
		int port
	)
	{
		this.port = port;
		stats = new StatData();
	}
	
	public
	void
	run()
	{
		int chars_total = 0;
		ServerSocket server_socket = null;
		try
		{
			server_socket = new ServerSocket( port );
		}
		catch ( IOException ioe )
		{
			System.err.println( "ERROR: could not bind to server socket." );
			return;
		}
		while ( true )
		{
			try
			{
				Socket client_socket = server_socket.accept();
				Handler handler = new Handler( client_socket, stats );
				handler.start();
				System.out.println( "INFO: active threads=" + stats.getNumberOfActiveThreads()
					+ "; bytes sent=" + stats.getNumberOfBytesSent()
				);
			}
			catch ( IOException ioe )
			{
				System.err.println( "ERROR: could not not accept client connection." );
			}
		}
	}

	//*	the port the service must listen to
	private int port;
	private StatData stats;

	public
	static
	void
	main
	(
		String[] args
	)
	{
		if ( 1 != args.length )
		{
			System.err.println( "ERROR: service port not specified." );
			System.exit( 1 );
		}
		try
		{
			int port = Integer.parseInt( args[ 0 ] );
			MTEchoServer server = new MTEchoServer( port );
			server.run();
		}
		catch ( NumberFormatException nfe )
		{
			System.err.println( "ERROR: service port must be an integer value." );
		}
	}
}
