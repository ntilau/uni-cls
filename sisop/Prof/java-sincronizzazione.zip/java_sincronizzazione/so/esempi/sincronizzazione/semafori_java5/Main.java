package so.esempi.sincronizzazione.semafori_java5;

import java.util.concurrent.Semaphore;

import so.esempi.prodcons.Memoria;
import so.esempi.prodcons.MemoriaCircolare;

/**
 * Produttori/consumatori con semafori.
 * Programma che illustra l'uso dei semafori per risolvere il problema
 * produttori/consumatori utilizzando la classe Semaphore del package
 * java.util.concurrent di Java 5.
 * Richiede Java 5.
 * 
 * @author jurgen assfalg
 *
 */

public class Main
{
	/**	costanti utilizzate nel calcolo del tempo per il quale i thread
	 	principale, produttore e consumatore si sospendono (in secondi)	*/
	public static final int ATTESA_PRINCIPALE = 2;
	public static final int ATTESA_PRODUTTORE = 1;
	public static final int ATTESA_CONSUMATORE = 20;
	//*	dimensioni della memoria circolare
	public static final int DIMENSIONE_BUFFER = 5;
	/**	numero di iterazioni che il thread principale esegue prima di
	 	interrompere gli altri */
	public static final int NUMERO_ITERAZIONI = 10;

	public static void main( String[] args )
	{
		//	crea una memoria condivisa di capacita' limitata,
		Memoria b = new MemoriaCircolare( DIMENSIONE_BUFFER );
		//	... un semaforo per controllare l'accesso in mutua esclusione,
		Semaphore mutex = new Semaphore( 1 );
		//	... un semaforo per tener traccia della disponibilit' di prodotti,
		Semaphore piene = new Semaphore( 0 );
		//	... e un semaforo per tener traccia del numero di celle libere
		Semaphore vuote = new Semaphore( DIMENSIONE_BUFFER );
		/*	crea un oggetto di tipo Produttore, indicando la memoria condivisa
			in cui depositare i dati	*/
		Produttore p = new Produttore( b, mutex, piene, vuote, ATTESA_PRODUTTORE );
		/*	crea un oggetto di tipo Consumatore, indicando la memoria condivisa
			da cui prelevare i dati	*/
		Consumatore c = new Consumatore( b, mutex, piene, vuote, ATTESA_CONSUMATORE );
		//	avvia il thread consumatore
		c.start();
		//	avvia il thread produttore
		p.start();
		//	il thread principale (cioe' questo) si pone in attesa (10 secondi)
		try
		{
			for ( int i = 0; i < NUMERO_ITERAZIONI; i++ )
			{
				Thread.sleep( ATTESA_PRINCIPALE * 1000 );
				int prodotti = p.getProdotti();
				int consumati = c.getConsumati();
				System.out.println( "Prodotti: " + prodotti + "; Consumati: " + consumati );
			}
			//	interrompe i threads produttore e consumatore
			p.interrompi();
			c.interrompi();
			/*	il thread principale si blocca in attesa che i threads terminino
				la propria esecuzione	*/
			p.join();
			c.join();
		}
		catch ( InterruptedException ie ) {}
		System.out.println( "programma terminato.");
		System.out.println( "Prodotti: " + p.getProdotti() + "; Consumati: " + c.getConsumati() );
	}
}
