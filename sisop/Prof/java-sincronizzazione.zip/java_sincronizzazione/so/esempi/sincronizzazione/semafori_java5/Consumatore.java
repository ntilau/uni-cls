package so.esempi.sincronizzazione.semafori_java5;

import java.util.concurrent.Semaphore;

import so.esempi.prodcons.Memoria;

public
class
	Consumatore
extends
	Thread
{
	public
	Consumatore
	(
		Memoria b,
		Semaphore m,
		Semaphore p,
		Semaphore v,
		int mst
	)
	{
		buffer = b;
		piene = p;
		vuote = v;
		mutex = m;
		maxSleepTime = mst;
	}

	public
	void
	run()
	{
		//	finche' il thread non viene interrotto e la memoria e' vuota ...
		while ( continua || ! buffer.vuota() )
		{
			try
			{
				//	...attende la disponibilita' di dati da prelevare,
				piene.acquire();
				//	...quindi richiede la mutua esclusione
				mutex.acquire();
				//	... per prelevarli.
				Double d = (Double) buffer.preleva();
				//	una volta prelevato rilascia la mutua esclusione
				mutex.release();
				//	... e segnala la presenza di una cella vuota
				vuote.release();
				consumati++;
				System.out.println( "Prelevato il valore " + d );
				int sleeptime = (int) ( maxSleepTime * Math.random() );
				System.out.println(
					"Consumatore sospeso per " + sleeptime + " secondi"
				);
				Thread.sleep( sleeptime * 1000 ); 
			}
			catch ( Exception e )
			{
				System.err.println( e );
				e.printStackTrace( System.err );
			}
		}
	}

	public
	void
	interrompi()
	{
		continua = false;
	}

	public
	int
	getConsumati()
	{
		return consumati;
	}

	Memoria buffer = null;
	private Semaphore piene = null;
	private Semaphore vuote = null;
	private Semaphore mutex = null;
	private int consumati = 0;
	boolean continua = true;
	private int maxSleepTime;

}
