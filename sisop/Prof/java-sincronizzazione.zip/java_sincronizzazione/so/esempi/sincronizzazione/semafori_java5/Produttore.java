package so.esempi.sincronizzazione.semafori_java5;

import java.util.concurrent.Semaphore;

import so.esempi.prodcons.Memoria;

public
class
Produttore
extends
	Thread
{
	public
	Produttore
	(
		Memoria b,
		Semaphore m,
		Semaphore p,
		Semaphore v,
		int mst
	)
	{
		buffer = b;
		piene = p;
		vuote = v;
		mutex = m;
		maxSleepTime = mst;
	}

	public
	void
	run()
	{
		//	finche' il thread non viene interrotto...
		while ( continua )
		{
			//	... produce informazione, ...
			Double d = new Double( Math.random() );
			prodotti++;
			//	... attende che ci sia spazio in memoria, ...
			try
			{
				//	... attende la disponibilita' di celle vuote in cui depositare,
				vuote.acquire();
				//	... quindi attende l'accesso in mutua esclusione
				mutex.acquire();
				//	... e deposita il dato.
				buffer.deposita( d );
				//	... successivamente rilascia la mutua esclusione
				mutex.release();
				//	... e segnala la presenza di un nuovo prodotto
				piene.release();

				System.out.println( "Inserito il valore " + d );
				int sleeptime = (int) ( maxSleepTime * Math.random() );
				System.out.println(
					"Produttore sospeso per " + sleeptime + " secondi"
				);
				Thread.sleep( sleeptime * 1000 ); 
			}
			catch ( Exception e ) {}
		}
	}

	public
	void
	interrompi()
	{
		continua = false;
	}

	public
	int
	getProdotti()
	{
		return prodotti;
	}

	Memoria buffer = null;
	private Semaphore piene;
	private Semaphore vuote;
	private Semaphore mutex;
	private int prodotti = 0;
	boolean continua = true;
	private int maxSleepTime;

}
