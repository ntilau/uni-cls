package so.esempi.sincronizzazione.regione_critica_2;

import so.esempi.prodcons.Memoria;

/**
 *	Produttore.
 * 
 *	La classe esemplifica una possibile (parziale) soluzione al problema della
 *	sincronizzazione.
 *	Spostando la verifica della condizione di memoria piena all'interno del
 *	blocco <tt>synchronized</tt> si evitano i problemi legati al fatto che tra
 *	la verifica della condizione ed il successivo accesso alla sezione critica
 *	la condizione possa nuovamente cambiare.
 *	Per limitare l'attesa attiva il thread cede il processore qualora non
 *	abbia potuto depositare i dati nel buffer.
 */

public
class
	Produttore
extends
	Thread
{
	public
	Produttore
	(
		Memoria m,
		int tam,
		int id
	)
	{
		memoria = m;
		tempoAttesaMax = tam;
		this.id = id;
	}              
   
	public
	void
	run()
	{
		String dato;
		//	il produttore genera messaggi all'infinito
		while ( true )
		{
			//	sospenda il produttore per un certo periodo di tempo
			int tempoAttesa = (int) ( tempoAttesaMax * Math.random() );
			System.out.println(
				"Produttore " + id + " sospeso per " + tempoAttesa + " secondi"
			);
			try
			{
				sleep ( tempoAttesa * 1000 ); 
			}
			catch ( InterruptedException e ) {}
			contatore++;
			dato = new String( "[prodotto " + contatore
				+ " del produttore " + id + "]" );
			System.out.println( "Produttore " + id + " produce " + dato );
			//	ripeti finche' non e' stato possibile depositare il dato
			for( boolean fatto = false; ! fatto; )
			{
				synchronized ( memoria )
				{
					//	una volta in sezione critica, verifica se c'e' spazio
					if ( ! memoria.piena() )
					{
						try
						{
							//	...ed eventualmente inserisce il dato
							memoria.deposita( dato );
							fatto = true;
						}
						catch ( Exception e )
						{
							System.err.println( "ERRORE: memoria piena." );
						}
					}
				}
				/*	se non e' stato possibile depositare il dato perche' la
				 *	memoria e' piena, allora cede il processore ad un altro
				 *	thread, nella speranza che un consumatore liberi memoria
				 *	(si cerca cosi' di ridurre l'attesa attiva.
				 */
				if ( ! fatto )
					Thread.yield();
			}
		}
	}
   
	private Memoria memoria;
	private int tempoAttesaMax;
	private int id;
	private int contatore = 0;
}
