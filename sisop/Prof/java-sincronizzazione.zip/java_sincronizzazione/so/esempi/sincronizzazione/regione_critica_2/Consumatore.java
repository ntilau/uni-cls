package so.esempi.sincronizzazione.regione_critica_2;

import so.esempi.prodcons.Memoria;

public
class
	Consumatore
extends
	Thread
{
	//*	costruttore della classe
	public
	Consumatore
	(
		Memoria m,
		int tam,
		int id
	)
	{
		memoria = m;
		tempoAttesaMax = tam;
		this.id = id;
	}

	public
	void
	run()
	{
		//	il consumatore viene eseguito all'infinito
		while ( true )
		{
			String dato = null;
			//	il thread sospende l'esecuzione per un periodo di tempo casuale
			int tempoAttesa = (int) ( tempoAttesaMax * Math.random() );
			System.out.println(
				"Consumatore " + id + " sospeso per " + tempoAttesa + " secondi"
			);
			try
			{ 
				sleep( tempoAttesa * 1000 ); 
			}
			catch( InterruptedException e ) {}
			System.out.println( "Consumatore interroga il buffer" );
			for( boolean fatto = false; ! fatto; )
			{
				synchronized ( memoria )
				{
					if ( ! memoria.vuota() )
					{
						try
						{
							dato = (String) memoria.preleva();
							fatto = true;
						}
						catch ( Exception e )
						{
							System.err.println( "ERRORE: memoria vuota." );
						}
					}
				}
				/*	se non e' stato possibile depositare il dato perche' la
				 *	memoria e' piena, allora cede il processore ad un altro
				 *	thread, nella speranza che un consumatore liberi memoria
				 *	(si cerca cosi' di ridurre l'attesa attiva.
				 */
				if ( ! fatto )
					Thread.yield();
			}
			if ( null != dato )
				System.out.println(
					"Consumatore " + id + " consuma il messaggio " + dato
				);
		}
	}

	private Memoria memoria;
	private int tempoAttesaMax;
	private int id;
}
