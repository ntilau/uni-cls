package so.esempi.sincronizzazione.monitor;

import so.esempi.prodcons.Memoria;


public
class
Consumatore
extends
	Thread
{
	//*	costruttore della classe
	public
	Consumatore
	(
		Memoria m,
		int mst,
		int id
	)
	{
		memoria = m;
		maxSleepTime = mst;
		this.id = id;
	}

	public
	void
	run()
	{
		//	il consumatore viene eseguito all'infinito
		while ( true )
		{
			String dato = null;
			/*	il thread sospende la propria esecuzione per un periodo di
			 *	tempo di lunghezza casuale
			 */
			int sleeptime = (int) ( maxSleepTime * Math.random() );
			System.out.println(
				"Consumatore " + id + " sospeso per " + sleeptime + " secondi"
			);
			try
			{ 
				sleep( sleeptime * 1000 ); 
			}
			catch(InterruptedException e) {}
			System.out.println( "Consumatore " + id + " interroga il buffer" );
			try
			{
				dato = (String) memoria.preleva();
			}
			catch ( Exception e )
			{
				System.err.println( e.toString() );
			}
			if ( null != dato )
				System.out.println(
					"Consumatore " + id + " consuma il messaggio " + dato
				);
		}
	}

	private Memoria memoria;
	private int maxSleepTime;
	private int id;
}
