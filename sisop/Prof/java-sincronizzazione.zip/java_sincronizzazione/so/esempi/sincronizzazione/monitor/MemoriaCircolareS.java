package so.esempi.sincronizzazione.monitor;

import so.esempi.prodcons.Memoria;
import so.esempi.prodcons.MemoriaCircolare;

/**
 *	Memoria circolare sincronizzata
 *	Estende la classe MemoriaCircolare per introdurre la sincronizzazione dei
 *	metodi per prelevare e depositare gli oggetti.
 */
public
class
MemoriaCircolareS
extends
	MemoriaCircolare
implements
	Memoria
{
	public
	MemoriaCircolareS
	(
		int dimensione
	)
	{
		super( dimensione );
	}

	/**
	 *	Deposita l'oggetto in memoria.
	 *	Il metodo puo' generare un 
	 */
	public
	synchronized
	void
	deposita
	(
		Object o
	)
	throws
		Exception
	{
		while ( super.piena() )
		{
			try
			{
				this.wait();
			}
			catch ( InterruptedException ie ) {}
		}
		super.deposita( o );
		this.notify();
	}


	public
	synchronized
	Object
	preleva()
	throws
		Exception
	{
		while ( super.vuota() )
		{
			try
			{
				this.wait();
			}
			catch ( InterruptedException ie ) {}
		}
		Object valore = super.preleva();
		this.notify();
		return valore;
	}

}
