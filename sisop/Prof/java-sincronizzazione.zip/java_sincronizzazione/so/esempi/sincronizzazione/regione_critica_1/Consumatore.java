package so.esempi.sincronizzazione.regione_critica_1;

import so.esempi.prodcons.Memoria;

public
class
	Consumatore
extends
	Thread
{
	//*	costruttore della classe
	public
	Consumatore
	(
		Memoria m,
		int tam,
		int id
	)
	{
		memoria = m;
		tempoAttesaMax = tam;
		this.id = id;
	}

	public
	void
	run()
	{
		String dato;
		//	il consumatore viene eseguito all'infinito
		while ( true )
		{
			//	il thread sospende l'esecuzione per un periodo di tempo casuale
			int sleeptime = (int) ( tempoAttesaMax * Math.random() );
			System.out.println(
				"Consumatore " + id + " sospeso per " + sleeptime + " secondi"
			);
			try
			{ 
				sleep( sleeptime * 1000 ); 
			}
			catch(InterruptedException e) {}
			System.out.println( "Consumatore interroga il buffer" );
			//	se la memoria e' vuota, allora il thread si pone in busy wait
			while ( memoria.vuota() );
			//	si definisce una regione critica per accedere al buffer
			synchronized( memoria )
			{
				try
				{
					//	preleva un dato dalla memoria 
					dato = (String) memoria.preleva();
				}
				catch ( Exception e )
				{
					/*	qualcun'altro potrebbe aver svuotato la memoria nel
						periodo di tempo tra l'ultima interrogazione e
						l'acquisizione del lock
					*/
					System.err.println( "ERRORE: memoria vuota." );
					dato = null;
				}
			}
			if ( null != dato )
				System.out.println(
					"Consumatore " + id + " consuma il messaggio " + dato
				);
		}
	}

	private Memoria memoria;
	private int tempoAttesaMax;
	private int id;
}
