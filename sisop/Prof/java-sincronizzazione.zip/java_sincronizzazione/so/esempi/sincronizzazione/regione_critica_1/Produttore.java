package so.esempi.sincronizzazione.regione_critica_1;

import so.esempi.prodcons.Memoria;

/**
 *	Produttore.
 * 
 *	La classe esemplifica una possibile (parziale) soluzione al problema della
 *	sincronizzazione attraverso uno dei due possibili usi della parola chiave
 *	<tt>synchronized</tt>.
 *	L'uso descritto nell'esempio riprende il modello della <i>regione
 *	critica</i>.
 *	L'interfaccia <tt>Memoria</tt> e' ripresa dal package
 *	<tt>so.esempi.prodcons</tt>
 */
public
class
	Produttore
extends
	Thread
{
	public
	Produttore
	(
		Memoria m,
		int tam,
		int id
	)
	{
		memoria = m;
		tempoAttesaMax = tam;
		this.id = id;
	}              
   
	public
	void
	run()
	{
		String dato;
		//	il produttore genera messaggi all'infinito
		while ( true )
		{
			//	sospenda il produttore per un certo periodo di tempo
			int tempoAttesa = (int) ( tempoAttesaMax * Math.random() );
			System.out.println(
				"Produttore " + id + " sospeso per " + tempoAttesa + " secondi"
			);
			try
			{
				sleep( tempoAttesa * 1000 ); 
			}
			catch ( InterruptedException e ) {}
			contatore++;
			dato = new String( "[prodotto " + contatore
				+ " del produttore " + id + "]" );
			System.out.println("Produttore " + id + " produce " + dato );
			/*	come alternativa al busy wait, il thread puo' cedere ("yield")
				la CPU, in attesa che si verifichi la condizione necessaria per
				procedere al deposito di un dato in memoria
			*/
			while ( memoria.piena() )
				Thread.yield();
			//	si definisce una regione critica per accedere al buffer
			synchronized ( memoria )
			{
				try
				{
					//	deposita il messaggio sulla memoria
					memoria.deposita( dato );
				}
				catch ( Exception e )
				{
					/*	qualche altro thread potrebbe aver riempito la memoria
						nel periodo di tempo tra l'ultima interrogazione e
						l'acquisizione del lock
					*/
					System.err.println( "ERRORE: memoria piena." );
				}
			}
		}
	}
   
	private Memoria memoria;
	private int tempoAttesaMax;
	private int id;
	private int contatore = 0;
}
