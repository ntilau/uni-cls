package so.esempi.sincronizzazione.variabile_condizione;

public
class
Produttore
extends
	Thread
{
	//*	costruttore
	public
	Produttore
	(
		MemoriaCircolare m,
		int tam,
		int id
	)
	{
		memoria = m;
		tempoAttesaMax = tam;
		this.id = id;
	}              
   
	/**
	 *	metodo eseguito quando il thread e' avviato con il metodo start ed ad
	 *	ogni successivo scheduling per l'esecuzione
	 */
	public
	void
	run()
	{
		//	il produttore genera messaggi all'infinito
		while ( true )
		{
			String dato;
			//	sospenda il produttore per un certo periodo di tempo
			int tempoAttesa = (int) ( tempoAttesaMax * Math.random() );
			System.out.println(
				"Produttore " + id + " sospeso per " + tempoAttesa + " secondi"
			);
			try
			{
				sleep( tempoAttesa * 1000 ); 
			}
			catch(InterruptedException e) {}
			contatore++;
			dato = new String( "[prodotto " + contatore + " del produttore " + id + "]" );
			System.out.println( "Produttore " + id + " produce " + dato );
			//	deposita il messaggio sulla memoria
			memoria.deposita( dato );
		}
	}
   
	private MemoriaCircolare memoria;
	private int tempoAttesaMax;
	private int id;
	private int contatore = 0;
}
