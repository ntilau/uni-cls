package so.esempi.sincronizzazione.variabile_condizione;


public
class
	Consumatore
extends
	Thread
{
	//*	costruttore della classe
	public
	Consumatore
	(
		MemoriaCircolare m,
		int tam,
		int id
	)
	{
		memoria = m;
		tempoAttesaMax = tam;
		this.id = id;
	}

	public
	void
	run()
	{
		//	il consumatore viene eseguito all'infinito
		while ( true )
		{
			String dato = null;
			//	il thread viene sospeso per un periodo di tempo casuale
			int tempoAttesa = (int) ( tempoAttesaMax * Math.random() );
			System.out.println(
				"Consumatore " + id + " sospeso per "
				+ tempoAttesa + " secondi"
			);
			try
			{ 
				sleep( tempoAttesa * 1000 ); 
			}
			catch ( InterruptedException e ) {}
			System.out.println( "Consumatore interroga il buffer" );
			//	preleva un dato dalla memoria 
			dato = (String) memoria.preleva();
			if ( null != dato )
				System.out.println(
					"Consumatore " + id + " consuma il messaggio " + dato
				);
		}
	}

	private MemoriaCircolare memoria;
	private int tempoAttesaMax;
	private int id;
}
