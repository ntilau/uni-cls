package so.esempi.sincronizzazione.monitor_java5;

import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import so.esempi.prodcons.Memoria;
import so.esempi.prodcons.MemoriaCircolare;

public class MemoriaCircolareC
extends
MemoriaCircolare
	implements
		Memoria
{

    private Lock mutex = new ReentrantLock();
    private Condition piene = mutex.newCondition();
    private Condition vuote = mutex.newCondition();

    public MemoriaCircolareC( int dimensione )
	{
		super( dimensione );
	}

	public void deposita( Object o )
		throws Exception
	{
        //acquisisce il blocco sulla risorsa
        mutex.lock();
        try {
            //	se il buffer e' pieno attende
            while( piena() )
                vuote.await();
            super.deposita( o );
            piene.signal();
        } 
        catch (Exception e ) { e.printStackTrace(); System.exit( 1 ); }
        //	rilascia comunque il blocco sulla risorsa
        finally{
            mutex.unlock();
        }
	}

	public Object preleva()
		throws Exception
	{
		Object o = null;
        //acquisisce il blocco sulla risorsa
        mutex.lock();
        try {
            //	se il buffer e' vuoto attende
            while( vuota() )
                piene.await();
            o = super.preleva();
            vuote.signal();
        } 
        catch (Exception e ) { e.printStackTrace(); System.exit( 1 ); }
        //	rilascia comunque il blocco sulla risorsa
        finally{
            mutex.unlock();
        }
		return o;
	}

}
