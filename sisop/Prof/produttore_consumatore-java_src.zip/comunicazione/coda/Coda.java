package comunicazione.coda;

import java.util.List;
import java.util.LinkedList;
 
public
class
Coda
{
	//*	costruttore
	public
	Coda()
	{
		coda = new LinkedList();
	}
   
	//*	invio (non bloccante) di un messaggio 
	public
	void
	invia
	(
		Object msg
	)
	{
		coda.add( msg );
	}
   
	//*	ricezione (non bloccante) di un messaggio
	public
	Object
	ricevi()
	{
		Object msg = null;
		//	se la coda non e' vuota...
		if ( coda.size() != 0 )
		{
			//	...prende il primo elemento della coda e lo rimuove
			msg = coda.get( 0 );
			coda.remove( 0 );
		}
		return msg;
	}
   
	//*	la coda di messaggi, teoricamente illimitata
	private List coda;
}
