package comunicazione.coda;

import java.util.Date;

public
class
Consumatore
extends
	Thread
{
	//*	costruttore della classe
	public
	Consumatore
	(
		Coda m,
		int mst
	)
	{
		mbox = m;
		maxSleepTime = mst;
	}

	public
	void
	run()
	{
		Date msg;
		//	il consumatore viene eseguito all'infinito
		while ( true )
		{
			//	il thread sospende l'esecuzione per un periodo di tempo casuale
			int sleeptime = (int) ( maxSleepTime * Math.random() );
			System.out.println(
				"Consumatore sospeso per " + sleeptime + " secondi"
			);
			try
			{ 
				sleep( sleeptime * 1000 ); 
			}
			catch(InterruptedException e) {}
			System.out.println( "Consumatore interroga la coda" );
			// riceve un messaggio dalla coda di messaggi
			msg = (Date) mbox.ricevi();
			if ( null != msg )
				System.out.println( "Consumatore consuma il messaggio " + msg );
		}
	}

	//*	coda dei messaggi
	private Coda mbox;

	private int maxSleepTime;
}
