package comunicazione.coda;

import java.util.Date;

public
class
Produttore
extends
	Thread
{
	//*	costruttore
	public
	Produttore
	(
		Coda m,
		int mst
	)
	{
	/*	la coda dei messaggi locale al thread e' forzata a puntare alla coda
		di  messaggi passata in ingresso	*/
		mbox = m;
		maxSleepTime = mst;
	}              
   
	/**
	 *	metodo eseguito quando il thread e' avviato con il metodo start ed ad
	 *	ogni successivo scheduling per l'esecuzione
	 */
	public
	void
	run()
	{
		Date msg;
		//	il produttore genera messaggi all'infinito
		while ( true )
		{
			//	sospenda il produttore per un certo periodo di tempo
			int sleeptime = (int) ( maxSleepTime * Math.random() );
			System.out.println(
				"Produttore sospeso per " + sleeptime + " secondi"
			);
			try
			{
				sleep(sleeptime*1000); 
			}
			catch(InterruptedException e) {}
			msg = new Date();      
			System.out.println("Produttore produce " + msg );
			//	invia il messaggio prodotto alla mailbox (cioe', alla coda)
			mbox.invia( msg );
		}
	}
   
	//* coda dei messaggi
	private Coda mbox;

	private int maxSleepTime;
}
