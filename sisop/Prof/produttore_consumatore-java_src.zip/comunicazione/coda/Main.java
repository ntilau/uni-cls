package comunicazione.coda;

/**
 *	Server.java
 *
 *	Crea la mailbox per lo scambio di messaggi ed i thread
 *	produttore e consumatore
 *
 */

//import java.util.*;
 
public
class
Main
{  
	/**	costante utilizzata nel calcolo del tempo per il quale i thread
		produttore e consumatore si sospendono (in secondi)	*/
	public static final int SLEEP_TIME = 5;

	public
	static
	void
	main
	(
		String[] argomenti
	)
	{
		//	crea la coda messaggi (mailbox)
		Coda coda_messaggi = new Coda();
		//	crea i thread produttore e consumatore
		Produttore produttore = new Produttore( coda_messaggi, SLEEP_TIME );
		Consumatore consumatore = new Consumatore( coda_messaggi, SLEEP_TIME );
		//	crea i thread nella JVM che puo' schedularli per l'esecuzione
		produttore.start();
		consumatore.start();
		/*	si osservi come, in questo caso, pur essendo terminata l'esecuzione               
			del thread principale (questo), il processo non termina, perche'
			altri 2 thread sono ancora in esecuzione	*/
	}
}

