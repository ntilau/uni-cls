package comunicazione.memoria;

public
class
Produttore
extends
	Thread
{
	public
	Produttore
	(
		MemoriaCircolare b
	)
	{
		buffer = b;
	}

	public
	void
	run()
	{
		//	finche' il thread non viene interrotto...
		while ( continua )
		{
			//	... produce informazione, ...
			Double d = new Double( Math.random() );
			//	... attende che ci sia spazio in memoria, ...
			while ( buffer.pieno() );
			try
			{
				//	... ed infine deposita il dato.
				buffer.deposita( d );
			}
			catch ( Exception e ) {}
			System.out.println( "Inserito il valore " + d );
		}
	}

	public
	void
	interrompi()
	{
		continua = false;
	}

	MemoriaCircolare buffer = null;
	boolean continua = true;
}
