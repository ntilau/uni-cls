package comunicazione.memoria;

public
class
Consumatore
extends
	Thread
{
	public
	Consumatore
	(
		MemoriaCircolare b
	)
	{
		buffer = b;
	}

	public
	void
	run()
	{
		//	finche' il thread non e' interrotto o ci sono dati in memoria, ...
		while ( continua || ( ! buffer.vuoto() ) )
		{
			//	... attende la disponibilita' di nuovi dati
			while ( buffer.vuoto() );
			Double d;
			try
			{
				//	... per prelevarli.
				d = (Double) buffer.preleva();
				System.out.println( "Prelevato il valore " + d );
				Thread.sleep( 500 );
			}
			catch ( InterruptedException ie ) {}
			catch ( Exception e ) {}
		}
	}

	public
	void
	interrompi()
	{
		continua = false;
	}

	MemoriaCircolare buffer = null;
	boolean continua = true;
}
