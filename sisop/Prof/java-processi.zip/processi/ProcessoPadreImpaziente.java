package processi;

import java.io.IOException;

public class ProcessoPadreImpaziente
{
	public
	void
	esegui
	(
		int numeroMassimoDiIterazioni,
		int tempoDiAttesa,
		String[] comando
	)
		throws IOException
	{
		Process processo = Runtime.getRuntime().exec( comando );
		boolean attendi = true;
		for ( int iterazione = 1;
			( iterazione <= numeroMassimoDiIterazioni ) && attendi;
			iterazione++
		)
		{
			System.out.println( "iterazione: " + iterazione );
			try
			{
				System.out.println(
					"potrei fare cose utili, ma mi metto a dormire"
				);
				Thread.sleep( tempoDiAttesa );
			}
			catch ( InterruptedException ie ) {}
			try
			{
				int valore = processo.exitValue();
				/*	ok, il processo lanciato e' terminato (altrimenti avrebbe
					lanciato un'eccezione
				*/
				System.out.println(
					"il processo lanciato e' terminato ed ha restituito il valore "
					+ valore
				);
				attendi = false;
			}
			catch ( IllegalThreadStateException itse )
			{
				/*	se e' stato raggiunto il numero massimo di iterazioni, allora
					termina il processo
				 */
				System.out.println(
					"il processo lanciato ancora non e' terminato"
				);
				if ( iterazione == numeroMassimoDiIterazioni )
				{
					System.out.println( "il processo verra' distrutto" );
					processo.destroy();
					System.out.println( "il processo e' stato distrutto" );
				}
			}
		}
	}
	/**
	 * @param args the command line arguments
	 */
	public static void main(String[] argomenti)
	{
		if ( argomenti.length < 3 )
		{
			System.out.println(
				"java ProcessoPadreImpaziente <iterazioni> <tempo di attesa> <figlio> {<argomenti>}"
			);
			System.exit( 1 );
		}
		ProcessoPadreImpaziente p = new ProcessoPadreImpaziente();
		String[] comando = new String[ argomenti.length - 2 ];
		for ( int i = 0; i < comando.length; i++ )
			comando[ i ] = argomenti[ i + 2 ];
		try
		{
			p.esegui(
				Integer.parseInt( argomenti[ 0 ] ),
				Integer.parseInt( argomenti[ 1 ] ),
				comando
			);
		}
		catch ( IOException ioe )
		{
			System.err.println(
				"ERRORE: il comando specificato non e' stato trovato."
			);
		}
	}
	
}
