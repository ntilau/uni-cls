package processi;

import java.io.IOException;

public class ProcessoPadrePaziente
{
	
	/** Creates a new instance of ProcessoPadrePaziente */
	public ProcessoPadrePaziente()
	{
	}
	
	public
	void
	esegui
	(
		String[] comando
	)
		throws IOException
	{
		System.out.println( "Sto per generare il processo figlio." );
		Process figlio = Runtime.getRuntime().exec( comando );
		System.out.println(
			"Processo figlio generato; entro in attesa del completamento."
		);
		boolean attendi = true;
		while ( attendi )
		{
			try
			{
				figlio.waitFor();
				System.out.println( "Il figlio ha completato l'esecuzione." );
				attendi = false;
			}
			catch ( InterruptedException ie )
			{
				System.out.println( "Sono stato interrotto nell'attesa." );
			}
		}
	}

	public static void main(String[] argomenti)
	{
		if ( argomenti.length < 2 )
		{
			System.out.println(
				"java ProcessoPadrePaziente <figlio> {<argomenti>}"
			);
			System.exit( 1 );
		}
		ProcessoPadrePaziente p = new ProcessoPadrePaziente();
		try
		{
			p.esegui( argomenti );
		}
		catch ( IOException ioe )
		{
			System.err.println(
				"ERRORE: il comando specificato non e' stato trovato."
			);
		}
	}
	
}
