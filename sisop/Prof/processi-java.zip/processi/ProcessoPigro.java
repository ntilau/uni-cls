/*
 * FiglioPigro.java
 *
 * Created on 6 marzo 2003, 12.47
 */

package processi;

/**
 *
 * @author  assfalg
 */
public class ProcessoPigro
{
	//	1000 millisecondi, cioe' 1 secondo
	static final int TEMPO_DI_ATTESA_PREDEFINITO = 1000;

	private int tempoDiAttesa;

	public ProcessoPigro()
	{
		this.tempoDiAttesa = TEMPO_DI_ATTESA_PREDEFINITO;
	}

	public ProcessoPigro( int tempoDiAttesa )
	{
		this.tempoDiAttesa = tempoDiAttesa;
	}

	public void esegui()
	{
		System.out.println( "Inizio esecuzione ProcessoPigro." );
		try
		{
			Thread.sleep( tempoDiAttesa );
			System.out.println( "Termine normale esecuzione ProcessoPigro." );
		}
		catch ( InterruptedException ie )
		{
			System.out.println( "Il sonno e' stato interrotto." );
		}
	}
	
	/**
	 * @param args the command line arguments
	 */
	public static void main(String[] argomenti)
	{
		ProcessoPigro pp = null;
		if ( 0 == argomenti.length )
			pp = new ProcessoPigro();
		else
			pp = new ProcessoPigro( Integer.parseInt( argomenti[ 0 ] ) );
		pp.esegui();
	}
	
}
