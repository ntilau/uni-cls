/*
 * PadrePaziente.java
 *
 * Created on 6 marzo 2003, 16.15
 */

package processi;

import java.io.IOException;

/**
 *
 * @author  assfalg
 */
public class PadrePaziente
{
	
	/** Creates a new instance of PadrePaziente */
	public PadrePaziente()
	{
	}
	
	public
	void
	esegui
	(
		String[] comando
	)
		throws IOException
	{
		System.out.println( "Sto per generare il processo figlio." );
		Process figlio = Runtime.getRuntime().exec( comando );
		System.out.println(
			"Processo figlio generato; entro in attesa del completamento."
		);
		boolean attendi = true;
		while ( attendi )
		{
			try
			{
				figlio.waitFor();
				System.out.println( "Il figlio ha completato l'esecuzione." );
				attendi = false;
			}
			catch ( InterruptedException ie )
			{
				System.out.println( "Sono stato interrotto nell'attesa." );
			}
		}
	}
	/**
	 * @param args the command line arguments
	 */
	public static void main(String[] argomenti)
	{
		if ( argomenti.length < 2 )
		{
			System.out.println(
				"java PadrePaziente <figlio> {<argomenti>}"
			);
			System.exit( 1 );
		}
		PadrePaziente p = new PadrePaziente();
		try
		{
			p.esegui( argomenti );
		}
		catch ( IOException ioe )
		{
			System.err.println(
				"ERRORE: il comando specificato non e' stato trovato."
			);
		}
	}
	
}
