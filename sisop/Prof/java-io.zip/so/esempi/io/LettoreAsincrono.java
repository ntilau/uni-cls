package so.esempi.io;

import java.io.InputStream;
import java.io.IOException;
import java.util.Vector;

public
class
	LettoreAsincrono
extends
	Thread
{
	public
	LettoreAsincrono
	(
		InputStream is
	)
	{
		input = is;
		buffer = new Vector();
		start();
	}

	public
	void
	run()
	{
		boolean continua = true;
		while ( continua )
		{
			try
			{
				int dato = input.read();
				if ( -1 == dato )
					//	e' terminata la lettura dallo stream
					continua = false;
				else
					//	aggiunge il dato letto al buffer
					synchronized (this)
					{
						buffer.add( new Byte( (byte) dato ) );
					}
			}
			catch ( IOException ioe )
			{
				//	si e' verificato un errore, quindi interrompe lettura
				System.err.println( "errore di I/O durante la lettura" );
				continua = false;
			}
		}
		try
		{
			input.close();
		}
		catch ( IOException ioe ) {}
	}

	public
	synchronized
	byte[]
	leggi()
	{
		//	copia i dati dal baffer in un array di byte
		byte[] dati = new byte[ buffer.size() ];
		for ( int i = 0; i < buffer.size(); i++ )
		{
			Byte dato = (Byte) buffer.get( i );
			dati[ i ] = dato.byteValue();
		}
		//	svuota il buffer
		buffer.removeAllElements();
		//	restituisce i dati fin qui letti
		return dati;
	}

	//*	lo stream di ingresso da cui leggere i dati
	private InputStream input = null;
	//*	il buffer in cui memorizzare i dati letti
	private Vector buffer = null;
}
