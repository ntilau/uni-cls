package io.asincrono;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;

/**
 *	Programma che esemplifica la lettura asincrona da uno stream di input.
 *
 *	@author	J&uml;urgen Assfalg
 *	@version 1.0 - 19/03/2003
 */

public
class
Main
{  
	/**	costante utilizzata nel calcolo del tempo per il quale i thread
		produttore e consumatore si sospendono (in secondi)	*/
	public static final int SLEEP_TIME = 5;

	public
	static
	void
	main
	(
		String[] argomenti
	)
	{
		if ( 1 != argomenti.length )
		{
			System.err.println(
				"usage:\n\tjava sincronizzazione.io.Main <file>"
			);
			System.exit( 1 );
		}
		InputStream is = null;
		try
		{
			is = new FileInputStream( argomenti[ 0 ] );
		}
		catch ( FileNotFoundException fnfe )
		{
			System.err.println(
				"ERRORE: impossibile trovare il file " + argomenti[ 0 ]
			);
			System.exit( 2 );
		}
		LettoreAsincrono lettore = new LettoreAsincrono( is );
		boolean continua = true;
		while ( continua )
		{
			byte[] dati = lettore.leggi();
			if ( 0 != dati.length )
			{
				System.out.println( "letti " + dati.length + " bytes" );
			}
			else if ( ! lettore.isAlive() )
			{
				System.out.println( "lettura terminata" );
				continua = false;
			}
			System.out.println(
				"mentre il lettore legge il file, il thread principale fa altro"
			);
			int max = (int) ( 1000.0 * Math.random() );
			for ( int i = 0; i < max; i ++ )
			{
				System.out.print( "." );
				System.out.flush();
			}
			System.out.println( max );
/*			try
			{
				Thread.sleep( 1000 );
			}
			catch ( InterruptedException ie ) {}
*/		}
	}
}
