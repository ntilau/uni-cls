package threads;

public
class
ProvaOrologio
{
	ProvaOrologio
	(
		int iterazioni,
		int intervallo
	)
	{
		this.iterazioni = iterazioni;
		this.intervallo = intervallo;
	}

	public
	void
	esegui()
	{
		Orologio o = new Orologio( intervallo );
		o.start();
		
		for ( int i = 0; i < iterazioni; i++ )
		{
			System.out.println( "iterazione " + i );
		}
		o.interrompi();
	}

	private int iterazioni;
	private int intervallo;

	public
	static
	void
	main
	(
		String[] argomenti
	)
	{
		if ( argomenti.length < 2 )
		{
			System.out.println(
				"java threads.ProvaOrologio <iterazioni> <intervallo>"
			);
			System.exit( 1 );
		}
		ProvaOrologio po = new ProvaOrologio(
			Integer.parseInt( argomenti[ 0 ] ),
			Integer.parseInt( argomenti[ 1 ] )
		);
		po.esegui();
	}
}
