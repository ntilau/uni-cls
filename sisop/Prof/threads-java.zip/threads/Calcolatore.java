package threads;

public
class
Calcolatore
implements
	Runnable
{
	Calcolatore
	(
		int iterazioni,
		int intervallo
	)
	{
		this.iterazioni = iterazioni;
		this.intervallo = intervallo;
		calcolo = new CalcoloPiGreco();
	}

	public
	void
	run()
	{
		for ( int i = 0; i < iterazioni; i++ )
		{
			try
			{
				Thread.sleep( intervallo );
				System.out.println(
					"sono passati circa " + intervallo
					+ " millisecondi, ed il valore di pi greco e' " +
					+ calcolo.valorePiGreco()
					
				);
			}
			catch ( InterruptedException ie )
			{
				System.out.println( "calcolo interrotto." );
			}
		}
		calcolo.interrompi();
	}

	public
	void
	esegui()
	{
		Thread calcolatore = new Thread( calcolo );
		calcolatore.start();
		Thread supervisore = new Thread( this );
		supervisore.start();
		System.out.println(
			"thread principale si pone in attesa del completamento del calcolo"
		);
		try
		{
			supervisore.join();
		}
		catch ( InterruptedException ie )
		{
			ie.printStackTrace();
		}
		System.out.println(
			"calcolo completato"
		);
	}


	private int iterazioni;
	private int intervallo;
	private CalcoloPiGreco calcolo;

	public
	static
	void
	main
	(
		String[] argomenti
	)
	{
		if ( argomenti.length < 2 )
		{
			System.out.println(
				"java threads.Calcolatore <iterazioni> <durata>"
			);
			System.exit( 1 );
		}
		Calcolatore c = new Calcolatore(
			Integer.parseInt( argomenti[ 0 ] ),
			Integer.parseInt( argomenti[ 1 ] )
		);
		c.esegui();
	}
}
