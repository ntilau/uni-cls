package threads;

public
class
CalcoloPiGreco
implements
	Runnable
{
	public
	CalcoloPiGreco()
	{
		pi = 4.0;
		continua = true;
	}

	public
	double
	valorePiGreco()
	{
		return pi;
	}

	public
	void
	interrompi()
	{
		continua = false;
	}

	public
	void
	run()
	{
		double sliceWidth = 0.5;
		double y;
		int iterations = 1;
		while ( continua )
		{
			double x = 0.0;
			while (x < 1.0)
			{
				y = Math.sqrt(1 - (x * x));
				pi -= 4 * (sliceWidth * y);
				x += sliceWidth;
				y = Math.sqrt(1 - (x * x));
				pi += 4 * (sliceWidth * y);
				x += sliceWidth;
			}
			++iterations;
			sliceWidth /= 2;
		}
	}

	private double pi;
	private boolean continua;
}
