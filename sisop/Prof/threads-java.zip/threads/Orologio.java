package threads;

public
class
Orologio
extends
	Thread
{
	public
	Orologio
	(
		int intervallo
	)
	{
		this.intervallo = intervallo;
		continua = true;
	}

	public
	void
	interrompi()
	{
		continua = false;
	}

	public
	void
	run()
	{
		while ( continua )
		{
			try
			{
				Thread.sleep( intervallo );
				System.out.println(
					"sono passati circa " + intervallo +
					" millisecondi dall'ultimo \"tick\" dell'orologio."
				);
			}
			catch ( InterruptedException ie )
			{
				System.out.println( "orologio interrotto." );
			}
		}
	}

	private int intervallo;
	private boolean continua;
}
