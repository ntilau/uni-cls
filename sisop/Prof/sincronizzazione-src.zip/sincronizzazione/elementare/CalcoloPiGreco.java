package sincronizzazione.elementare;

/**
 *	la classe consente di calcolare il valore di pi greco fino ad una
 *	determinata precisione, specificata come parametro al costruttore.
 *
 *	@version 1.0 - 12/03/2003
 *	@author Jurgen Assfalg
*/

public
class
CalcoloPiGreco
extends
	Thread
{
	public
	CalcoloPiGreco
	(
		double precisione
	)
	{
		pi = 4.0;
		continua = true;
		this.precisione = precisione;
	}

	public
	double
	valorePiGreco()
	{
		return pi;
	}

	public
	void
	interrompi()
	{
		continua = false;
	}

	public
	void
	run()
	{
		double larghezza_fetta = 0.5;
		double y;
		while ( continua )
		{
			double x = 0.0;
			double vecchio_pi = pi;
			while ( x < 1.0 )
			{
				y = Math.sqrt(1 - ( x * x ) );
				pi -= 4 * ( larghezza_fetta * y );
				x += larghezza_fetta;
				y = Math.sqrt(1 - ( x * x ) );
				pi += 4 * ( larghezza_fetta * y);
				x += larghezza_fetta;
			}
			larghezza_fetta /= 2;
			if ( Math.abs( pi - vecchio_pi ) < precisione )
				continua = false;
		}
	}

	private double pi;
	private double precisione;
	private boolean continua;
}
