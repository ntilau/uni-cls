package sincronizzazione.elementare;


/**
 *	Il programma mostra una semplice forma di sincronizzazione tra threads,
 *	in cui un primo thread attende il completamento dell'esecuzione di un
 *	secondo thread, ad esempio per poter leggere il risultato dell'elaborazione
 *	di quest'ultimo.
 *
 *	Si tenga presente che specificando da linea di comando una precisione
 *	richiesta superiore a quella di macchina, il programma non termina la sua
 *	esecuzione.
 *
 *	@version 1.0 - 12/03/2003
 *	@author Jurgen Assfalg
 */

public
class
Main
{
	public
	static
	void
	main
	(
		String[] argomenti
	)
	{
		if ( 1 > argomenti.length )
		{
			System.out.println(
				"usage:\n\tjava sincronizzazione.elementare.Main <precisione>"
			);
			System.exit( 1 );
		}
		double precisione = Double.parseDouble( argomenti[ 0 ] );
		CalcoloPiGreco calcolatore = new CalcoloPiGreco( precisione );
		calcolatore.start();
		System.out.println(
			"thread principale si sospende in attesa completamento del calcolo"
		);
		try
		{
			calcolatore.join();
		}
		catch ( InterruptedException ie ) {}
		System.out.println(
			"il valore di pi greco, calcolato con precisione " + precisione
			+ ", e' " + calcolatore.valorePiGreco()
		);
	}
}
