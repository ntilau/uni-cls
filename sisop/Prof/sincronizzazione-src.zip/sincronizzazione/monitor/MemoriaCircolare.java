package sincronizzazione.monitor;

/**
 *
 *	@author	J&uml;urgen Assfalg
 *	@version 1.0 - 17/03/2003
 */

public
class
MemoriaCircolare
{
	public
	MemoriaCircolare
	(
		int dimensione
	)
	{
		this.dimensione = dimensione;
		ingresso = 0;
		uscita = 0;
		buffer = new Object[ dimensione ];
	}

	public
	synchronized
	void
	deposita
	(
		Object o
	)
	{
		while ( pieno() )
		{
			try
			{
				this.wait();
			}
			catch ( InterruptedException ie ) {}
		}
		buffer[ ingresso ] = o;
		ingresso = ( ingresso + 1 ) % dimensione;
		this.notify();
	}


	public
	synchronized
	Object
	preleva()
	{
		while ( vuoto() )
		{
			try
			{
				this.wait();
			}
			catch ( InterruptedException ie ) {}
		}
		Object valore = buffer[ uscita ];
		uscita = ( uscita + 1 ) % dimensione;
		this.notify();
		return valore;
	}

	private
	boolean
	pieno()
	{
		return ( ( ingresso + 1 ) % dimensione == uscita );
	}

	private
	boolean
	vuoto()
	{
		return ( ingresso == uscita );
	}

	private int dimensione = 0;
	private int ingresso = 0;
	private int uscita = 0;
	private Object[] buffer = null;
}
