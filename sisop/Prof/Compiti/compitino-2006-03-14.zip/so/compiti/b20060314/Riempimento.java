package so.compiti.b20060314;

import java.util.concurrent.Semaphore;

public class Riempimento
	extends
		Thread
{
	private int valoreMassimo;
	private int[] dati;
	private Semaphore semaforo;

	public Riempimento
	(
		int v,
		int[] d,
		Semaphore s
	)
	{
		valoreMassimo = v;
		dati = d;
		semaforo = s;
	}

	public void run()
	{
		for ( int i = 0; i < dati.length; i++ )
		{
			dati[ i ] = (int) ( valoreMassimo * Math.random() );
			System.out.print( dati[ i ] + " " );
		}
		System.out.println();
		semaforo.release( dati.length );
	}
}
