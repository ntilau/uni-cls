package so.compiti.b20060314;

import java.util.concurrent.Semaphore;

public class Principale
{

	public static final int M = 15;
	public static final int N = 5;

	public static void main( String[] args )
	{
		int[] v = new int[ N ];
		Semaphore fineRiempimento = new Semaphore( 0 );
		Semaphore fineComplemento = new Semaphore( -N + 1 );
		Riempimento r = new Riempimento( M, v, fineRiempimento );
		for( int i = 0; i < v.length; i ++ )
		{
			Complemento c = new Complemento( M, v, i, fineRiempimento, fineComplemento );
			c.start();
		}
		r.start();
		try
		{
			fineComplemento.acquire();
			for ( int i = 0; i < v.length; i++ )
			{
				System.out.print( v[ i ] + " " );
			}
			System.out.println();
		}
		catch ( InterruptedException e )
		{
			e.printStackTrace();
		}
	}

}
