package so.compiti.b20060314;

import java.util.concurrent.Semaphore;

public class Complemento
	extends
		Thread
{
	private int valoreMassimo;
	private int[] dati;
	private int indice;
	private Semaphore attesaInizio;
	private Semaphore segnalazioneFine;

	public Complemento
	(
		int v,
		int[] d,
		int i,
		Semaphore ai,
		Semaphore sf
	)
	{
		valoreMassimo = v;
		dati = d;
		indice = i;
		attesaInizio = ai;
		segnalazioneFine = sf;
	}

	public void run()
	{
		try
		{
			attesaInizio.acquire();
			int c = valoreMassimo - dati[ indice ];
			Thread.sleep( (int) ( 5000.0 * ( 1 + Math.random() )));
			dati[ indice ] = c;
			segnalazioneFine.release();
		}
		catch ( InterruptedException e )
		{
			e.printStackTrace();
		}
		
	}
}
