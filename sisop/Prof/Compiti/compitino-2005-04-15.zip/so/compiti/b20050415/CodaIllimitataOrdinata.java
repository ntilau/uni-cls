package so.compiti.b20050415;

import java.util.LinkedList;


public class CodaIllimitataOrdinata {
	LinkedList coda = new LinkedList();
	int utenti = 0;
	public void chiediServizio ( Object g )
	{
		utenti++;
		coda.add( g );
	}
	public Object serviUtente()
	{
		utenti--;
		return coda.removeFirst();
	}
	public boolean vuota()
	{
		return ( utenti == 0 );
	}
}