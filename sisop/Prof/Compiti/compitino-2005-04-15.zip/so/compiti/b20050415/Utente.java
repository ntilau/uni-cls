package so.compiti.b20050415;

public class Utente extends Thread {
	Distributore d;
	CodaIllimitataOrdinata c;
	Utente( String n, CodaIllimitataOrdinata c, Distributore d ) {
		super( n );
		this.c = c;
		this.d = d;
	}
	public void run() {
		Object g = d.gettone( this.getName() );
		System.out.println( this.getName() + ": preso gettone" );
		synchronized( g ) {
			synchronized( c ) {
				System.out.println( this.getName() + ": chiedo servizio" );
				c.chiediServizio( g );
				System.out.println( this.getName() + ": chiesto servizio" );
				c.notify();
			}
			try {
				g.wait();
			} catch ( InterruptedException ie ) {}
		}
		System.out.println( this.getName() + ": servito" );
	}
}