package so.compiti.b20050415;

public class Distributore {
	public Object gettone( String s ) { return new String( s ); }
}