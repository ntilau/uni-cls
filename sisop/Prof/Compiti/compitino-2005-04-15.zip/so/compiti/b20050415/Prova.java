package so.compiti.b20050415;

public class Prova extends Thread {
	Distributore d = new Distributore();
	CodaIllimitataOrdinata c = new CodaIllimitataOrdinata();
	public void run() {
		for( int i = 0; i < 3; i++ )
			(new Inserviente( "i" + Integer.toString( i ), c, d ) ).start();
		for( int j = 0; ; j++ ) {
			try {
				Thread.sleep( 500 );
			} catch ( InterruptedException ie ) {}
			(new Utente( "u" + Integer.toString( j ), c, d ) ).start();
		}
	}

	public static void main( String[] args ) {
		Prova p = new Prova();
		p.run();
	}
}
