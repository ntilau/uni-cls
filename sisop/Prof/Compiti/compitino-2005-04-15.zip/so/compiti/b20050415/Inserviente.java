package so.compiti.b20050415;

public class Inserviente extends Thread {
	Distributore d;
	CodaIllimitataOrdinata c;
	Inserviente( String n, CodaIllimitataOrdinata c, Distributore d ) {
		super( n );
		this.c = c;
		this.d = d;
	}
	public void run() {
		while ( true ) {
			try {
				Thread.sleep( 2000 );
			} catch ( InterruptedException ie ) {}
			Object g;
			synchronized( c ) {
				if ( c.vuota() ) {
					System.out.println( this.getName() + ": attendo utente" );
					try {
						c.wait();
					} catch ( InterruptedException ie ) {}
				}
				g = c.serviUtente();
				System.out.println( this.getName() + ": servo utente " + g.toString() );
				synchronized( g ) {
					g.notify();
				}
				System.out.println( this.getName() + ": servito utente " + g.toString() );
			}
		}
	}
}