package so.compiti.b20040409;

public
class
ProvaSemaforoBinario
extends
	Thread
{
	public
	ProvaSemaforoBinario
	(
		SemaforoBinario s,
		int n
	)
	{
		this.s = s;
		this.n = n;
	}

	public
	void
	run()
	{
		System.out.println( "sono il thread " + n + ", e cerco di accedere alla sezione critica" );
		try
		{
			s.attendi();
			System.out.println( "sono il thread " + n + ", e sono in sezione critica" );
			Thread.sleep( 1000 );
		}
		catch ( InterruptedException ie ) {}
		System.out.println( "sono il thread " + n + ", e sto per lasciare la sezione critica" );
		s.segnala();
		System.out.println( "sono il thread " + n + ", ed ho lasciato la sezione critica" );
	}

	protected SemaforoBinario s;
	protected int n;

	public
	static
	void
	main
	(
		String[] args
	)
	{
		SemaforoBinario s = new SemaforoBinario();
		for ( int i = 0; i < 3; i++ )
		{
			Thread t = new ProvaSemaforoBinario( s, i );
			t.start();
		}
	}
}
