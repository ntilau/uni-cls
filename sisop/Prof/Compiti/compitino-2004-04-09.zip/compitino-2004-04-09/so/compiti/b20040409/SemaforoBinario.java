package so.compiti.b20040409;

import java.util.LinkedList;

public
class
SemaforoBinario
{
	public
	SemaforoBinario()
	{
		this.valore = true;
		this.coda = new LinkedList();
		threadSbloccato = null;
	}

	//*	esegue la WAIT sul semaforo
	public
	synchronized
	void
	attendi()
	throws
		InterruptedException
	{
		if ( valore )
			valore = false;
		else
		{
			coda.add( Thread.currentThread() );
			boolean sbloccato = false;
			while ( ! sbloccato )
			{
				this.wait();
				sbloccato = (
					Thread.currentThread() == (Thread) coda.getFirst()
					&& null == threadSbloccato
				);
			}
			threadSbloccato = (Thread) coda.removeFirst();
		}
	}

	//*	esegue la SIGNAL sul semaforo
	public
	synchronized
	void
	segnala()
	{
		if ( coda.size() > 0 )
		{
			threadSbloccato = null;
			this.notifyAll();
		}
		else
			valore = true;
	}

	protected boolean valore;
	protected LinkedList coda;
	protected Thread threadSbloccato;
}
