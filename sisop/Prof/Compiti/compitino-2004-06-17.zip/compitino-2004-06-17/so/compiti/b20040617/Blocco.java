package so.compiti.b20040617;

/**
 * Blocco.
 *
 * La classe realizza una primitiva di sincronizzazione di tipo 'usa e getta',
 * per cui finche' nessun thread ha invocato il metodo sblocca(), tutti i threads
 * che invocano il metodo attendi() vengono sospesi; quando, invece, un thread
 * invoca il metodo attendi() dopo che il metodo sblocca() e' stato invocato
 * almeno una volta, allora il thread prosegue immediatamente la sua esecuzione.
 */

public
class
Blocco
{
	public
	Blocco()
	{
	}

	public
	synchronized
	void
	sblocca()
	{
		bloccato = false;
		notifyAll();
	}

	public
	synchronized
	void
	attendi()
	{
		if ( bloccato )
			try
			{
				wait();
			}
			catch ( InterruptedException ie ) {}
	}

	protected boolean bloccato = true;
}
