package so.compiti.a20060221;

public class Generatore
	extends
		Thread
{
	private int ritardoMassimo;
	private boolean continua = true;
	private int messaggiGenerati = 0;
	
	public Generatore( int m )
	{
		super();
		this.ritardoMassimo = m;
	}

	public void run()
	{
		while ( continua )
		{
			messaggiGenerati++;
			System.out.println(
				"Thread \"" + this.getName()
				+ "\" - messaggio n. " + messaggiGenerati
			);
			int ritardo = 1000 * (1 + (int) ((ritardoMassimo - 1) * Math.random()));
			try
			{
				Thread.sleep( ritardo );
			}
			catch ( InterruptedException e)
			{
				System.err.println(
					"Thread \"" + this.getName()
					+ "\" - errore: " + e.getMessage()
				);
			}
		}
	}

	private void interrompi()
	{
		continua = false;
	}

	public int getMessaggiGenerati()
	{
		return messaggiGenerati;
	}

	public static final int M = 10;
	public static final int N = 5;
	public static final int T = 3;

	public static void main( String[] args )
	{
		Generatore[] g = new Generatore[ N ];
		for ( int i = 0; i < g.length; i++ )
		{
			g[ i ] = new Generatore( M );
			g[ i ].start();
		}
		try
		{
			Thread.sleep( 1000 * T );
			int totaleMessaggi = 0;
			for ( int i = 0; i < g.length; i++ )
			{
				g[ i ].interrompi();
				g[ i ].join();
				totaleMessaggi += g[ i ].getMessaggiGenerati();
			}
			System.out.println( "n. totale messaggi generati: "
				+ totaleMessaggi
			);
		}
		catch ( InterruptedException e )
		{
			System.err.println(
				"main - errore: " + e.getMessage()
			);
		}
	}

}
