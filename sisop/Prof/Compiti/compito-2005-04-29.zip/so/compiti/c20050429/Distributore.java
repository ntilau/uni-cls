package so.compiti.c20050429;

public
class
	Distributore
{
	//*	restituisce il prossimo numero all'utente che ne fa richiesta
	public
	synchronized
	int
	nuovoNumero()
	{
		numero++;
		notify();
		return numero;
	}

	public
	synchronized
	int
	ultimoNumero()
	{
		return numero;
	}

	//*	l'ultimo numero erogato
	private int numero = 0;
}
