package so.compiti.c20050429;

public
class
	Lavoratore
extends
	Thread
{
	public
	Lavoratore
	(
		String n,
		Distributore d,
		Pannello p
	)
	{
		super( n );
		this.p = p;
		this.d = d;
	}

	public
	void
	run()
	{
		while ( true )
		{
			synchronized( d )
			{
				try
				{
					if ( p.confronta(  d.ultimoNumero() ) ) {
						System.out.println( "Lavoratore " + getName()
							+ " inattivo" );
						d.wait();
					}
					int n = p.prossimo();
					System.out.println( "Lavoratore " + getName()
						+ " eroga servizio all'utente " + n );
					//	serve utente
				}
				catch ( InterruptedException ie ) {}
			}
		}
	}

	//*	display utilizzato per indicare il prossimo utente da servire
	private Pannello p;
	//*	distributore di numeri, sul cui il lavoratore si sospende se inattivo
	private Distributore d;
}
