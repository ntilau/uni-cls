package so.compiti.c20050429;

public
class
	Pannello
{
	public
	synchronized
	int
	prossimo()
	{
		chiamato++;
		notifyAll();
		return chiamato;
	}

	public
	synchronized
	boolean
	confronta
	(
		int numero
	)
	{
		//	se utente e' gia' stato chiamato puo' considerarsi servito
		return ( numero <= chiamato );
	}

	//*	l'ultimo numero servito
	private int chiamato = 0;
}
