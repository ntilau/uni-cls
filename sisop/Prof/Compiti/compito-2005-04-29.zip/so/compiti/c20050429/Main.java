package so.compiti.c20050429;

public
class
	Main
{

	public
	static
	void
	main
	(
		String[] args
	)
	{
		Distributore d = new Distributore();
		Pannello p = new Pannello();
		for ( int i = 0; i < 3; i++ )
			(new Lavoratore( "L-" + i, d, p ) ).start();
		for ( int j = 0; j < 50; j++ )
		{
			(new Utente( "U-" + j, d, p ) ).start();
			try
			{
				Thread.sleep( (int) ( 3.0 * Math.random() ) );
			}
			catch ( InterruptedException ie ) {}
		}
	}
}
