package so.compiti.c20050429;

public
class
	Utente
extends
	Thread
{
	public
	Utente
	(
		String n,
		Distributore d,
		Pannello p
	)
	{
		super( n );
		this.p = p;
		this.d = d;
	}

	public
	void
	run()
	{
		System.out.println( "Utente " + getName() + " chiede numero " );
		int n = d.nuovoNumero();
		boolean servito = false;
		System.out.println( "Utente " + getName()
			+ " chiede servizio, con numero " + n );
		while ( !servito )
		{
			synchronized( p )
			{
				try
				{
					p.wait();
					servito = p.confronta( n );
				}
				catch ( InterruptedException ie ) {}
			}
		}
		System.out.println( "Utente " + getName()
			+ " ha ottenuto il servizio" );
	}

	//*	pannello utilizzato per indicare il prossimo utente da servire
	private Pannello p;
	//*	distributore che eroga il numero progressivo
	private Distributore d;

}
