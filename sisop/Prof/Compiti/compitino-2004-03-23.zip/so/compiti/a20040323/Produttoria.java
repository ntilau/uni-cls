package so.compiti.a20040323;

import java.math.BigInteger;

public class Produttoria extends Thread
{
	private int inizio;
	private int fine;
	private BigInteger prodotto;

	public Produttoria( int inizio, int fine )
	{
		System.out.println( inizio + " " + fine );
		this.inizio = inizio;
		this.fine = fine;
	}
	
	public void run()
	{
		Integer i = new Integer( inizio );
		prodotto = new BigInteger( i.toString() );
		for ( int j = inizio + 1; j <= fine; j++ )
		{
			i = new Integer( j );
			BigInteger f = new BigInteger( i.toString() );
			prodotto = prodotto.multiply( f );
		}
	}
	
	public BigInteger getProdotto()
	{
		return prodotto;
	}
	
	public static void main(String[] args)
	{
		int n = 3;
		int q = 3;
		int m = n * q;
		Produttoria[] p = new Produttoria[ n ];
		for ( int j = 0; j < n; j++ )
		{
			p[ j ] = new Produttoria( 1 + j * q, ( j + 1 ) * q );
			p[ j ].start();
		}
		BigInteger fattoriale = new BigInteger( "1" );
		for ( int j = 0; j < n; j++ )
		{
			try
			{
				p[ j ].join();
			}
			catch ( InterruptedException ie ) {}
			fattoriale = fattoriale.multiply( p[ j ].getProdotto() );
		}
		System.out.println( "Il fattoriale di " + m + " e' " + fattoriale );
	}
}
