/*
 * MainMedMax.java
 *
 * Created on 2 giugno 2004, 13.20
 */

package assfalg.esempi.esercizi;

/**
 *	MainMedMax.
 *
 *	@author  J&uuml;rgen Assfalg
 */
public
class
MainMedMax
{
	public
	static
	void
	main
	(
		String[] args
	)
	{
		try
		{
			if ( 1 != args.length )
				throw new Exception( "non e' stato specificato il numero di elementi del vettore." );
			int n = Integer.parseInt( args[ 0 ] );
			System.out.println( "creato un vettore di " + n + " elementi" );
			double[] dati = new double[ n ];
			Riempimento r = new Riempimento( dati );
			Massimo m = new Massimo( dati );
			r.start();
			r.join();
			m.start();
			double somma = 0;
			for ( int i = 0; i < dati.length; i++ )
			{
				somma += dati[ i ];
				System.out.println( "#" + i + " somma: " + somma );
			}
			double media = somma / dati.length;
			System.out.println( "completato il calcolo del valor medio." );
			m.join();
			double massimo = m.massimo();
			System.out.println( "la media e' " + media
				+ "; il massimo e' " + massimo
			);
		}
		catch ( NumberFormatException nfe )
		{
			System.err.println( "il parametro specificato non e' compatibile con il tipo int." );
		}
		catch ( InterruptedException ie )
		{
			System.err.println( "un thread e' stato interrotto.");
		}
		catch ( Exception e )
		{
			System.err.println( e.getMessage() );
		}
	}
}
