/*
 * Riempimento.java
 *
 * Created on 2 giugno 2004, 18.46
 */

package assfalg.esempi.esercizi;

/**
 *	Riempie un vettore.
 *	La classe definisce un thread che riempie gli elementi di un vettore di
 *	double con valori casuali.
 *
 *	@author  J&uuml;rgen Assfalg
 */
public
class
Riempimento
extends
	Thread
{
	
	public
	Riempimento
	(
		double[] vettore
	)
	{
		this.vettore = vettore;
	}

	public
	void
	run()
	{
		for( int i = 0; i < vettore.length; i++ )
			vettore[ i ] = Math.random();
		System.out.println( "completato il riempimento del vettore." );
	}

	private double[] vettore;
}
