package compiti.indovina_numero;

/**
 * Tavolo di gioco.
 * Il tavolo tiene traccia degli indovini che partecipano al gioco, e
 * consente l'avvio del gioco solo una volta che tutti gli indovini
 * previsti si sono presentati al tavolo.
 * Il tavolo confronta anche con il numero segreto i numeri presentati da
 * ciascun indovino durante il proprio turno 
 */
public class Tavolo
{
	public Tavolo
	(
		int nm,
		int i
	)
	{
		numeroSegreto = (int) ( nm * Math.random() );
		indovini = i; 
		System.out.println( "Il numero segreto e' " + numeroSegreto );
	}

	/**
	 * invocando il metodo gli indovini comunicano al tavolo che sono stati avviati.
	 */
	public synchronized void comunicaAvvio()
	{
		//	decrementa il numero di indovini che si devono ancora presentare
		indovini--;
		//	se qualche indovino si deve ancora presentare...
		if ( 0 != indovini )
		{
			//	...sospende l'indovino...
			try
			{
				this.wait();
			}
			catch ( InterruptedException ie ) {}
		}
		//	...altrimenti sblocca tutti gli indovini sospesi
		else
			notifyAll();
	}

	/**
	 * confronta con il numero segreto il numero indicato dall'indovino.
	 * 
	 * @param i il numero indicato dall'indovino
	 * @return true se l'indovino ha indovinato il numero, false altrimenti
	 */
	public boolean confronta( int i )
	{
		if ( i == numeroSegreto )
			indovinato = true;
		return indovinato;
	}

	/**
	 * indica se il numero segreto e' gia' stato indovinato da qualche altro indovino.
	 * 
	 * @return true se un indovino ha indovinato il numero, false altrimenti
	 */
	public boolean indovinato()
	{
		return indovinato;
	}

	//*	il numero segreto da indovinare
	private int numeroSegreto;
	//*	indica se il numero segreto e' stato indovinato o meno
	private boolean indovinato = false;
	//*	il numero di indovini che si devono presentare al tavolo
	private int indovini;
}