package compiti.indovina_numero;

/**
 * Programma principale.
 * Il programma principale provvede alla creazione dei tavolo, crea ed avvia
 * i threads degli indovini
 */
public class Programma
{
	//*	il numero di indovini
	public static final int N = 5;
	//*	limite superiore per l'intervallo dei numeri da indovinare [0,M]
	public static final int M = 20;

	public static void main( String[] args )
	{
		//	crea il tavolo
		Tavolo t = new Tavolo( M, N );
		//	crea
		for ( int k = 0; k < N; k++ )
		{
			Indovino i = new Indovino( M, t );
			i.start();
		}
	}
}
