/*
 * Created on 16-feb-2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package compiti.indovina_numero;


public class Indovino extends Thread
{
	public Indovino
	(
		int nm,
		Tavolo t
	)
	{
		tavolo = t;
		numeroMax = nm;
	}

	public void run()
	{
		//	sincronizzazione iniziale (attende il "via" dal programma principale
		tavolo.comunicaAvvio();
		//	finche' il numero non e' stato indovinato il gioco va avanti
		while ( ! finito )
		{
			/*	accesso sincronizzato al tavolo, per consentire l'invocazione dei
			 	due metodi senza che fra le due invocazioni cambi lo stato del tavolo.
			 	Inoltre, si sfrutta l'accodamento implicito nel monitor per gestire
			 	i turni.
			 */
			synchronized( tavolo )
			{
				if ( tavolo.indovinato() )
				{
					System.out.println( "qualcun'altro ha gia' indovinato il numero :'''(" );
					finito = true;
				}
				else
				{
					int n = (int) ( numeroMax * Math.random() );
					System.out.print( "Provo con " + n + "... " );
					if ( tavolo.confronta( n ) )
					{
						System.out.println( "ho indovinato il numero!!!" );
						finito = true;
					}
					else
					{
						System.out.println( "non ho indovinato il numero :(" );
					}
				}
			}
		}
	}

	//*	riferimento al tavolo presso cui si svolge il gioco
	private Tavolo tavolo = null;
	//*	indica se il thread deve terminare
	private boolean finito = false;
	//*	estremo superiore dell'intervallo che comprende i numeri da indovinare [0,numerMax]
	private int numeroMax;
}