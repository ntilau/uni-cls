
package so.compiti.b20050617;
public
class
	UtenteRisorse
extends
	Thread
{
	public
	UtenteRisorse
	(
		Risorsa r,
		int i,
		String n
	)
	{
		super( n );
		this.r = r;
		this.i = i;
	}
	public
	void
	run()
	{
		try
		{
			r.richiediIstanze( i );
			Thread.sleep( (int) ( 10000. * Math.random() ) );
		}
		catch ( InterruptedException ie ) {}
		r.rilasciaIstanze( i );
	}
	private Risorsa r = null;
	private int i;
	public
	static
	void
	main
	(
		String[] args
	)
	{
		Risorsa rr = new Risorsa( 10 );
		for ( int k = 0; k < 10; k++ ) {
			int nr = ( 1 + (int) ( 3. * Math.random() ) );
			UtenteRisorse ur = new UtenteRisorse( rr, nr, "T" + k );
			ur.start();
		}
	}
}
