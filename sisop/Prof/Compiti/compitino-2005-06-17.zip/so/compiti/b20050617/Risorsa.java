package so.compiti.b20050617;
import java.util.LinkedList;
public
class
	Risorsa
{
	class Richiesta {
		public int richiesta;
		public String richiedente;
	}
	public
	Risorsa
	(
		int istanzeDisponibili
	)
	{
		this.istanzeDisponibili = istanzeDisponibili;
	}
	public
	synchronized
	void
	richiediIstanze
	(
		int istanze
	)
	throws
		InterruptedException
	{
		System.out.print( Thread.currentThread().getName() + " chiede " + istanze );
		System.out.print( "; disponibili " + istanzeDisponibili );
		if ( istanze > istanzeDisponibili )
		{
			Richiesta r = new Richiesta();
			r.richiesta = istanze;
			r.richiedente = Thread.currentThread().getName();
			pendenti.add( r );
			System.out.println( "; bloccato" );
			wait();
		}
		else
		{
			istanzeDisponibili -= istanze;
			System.out.println( "; passa; lascia " + istanzeDisponibili );
		}
	}
	public
	synchronized
	void
	rilasciaIstanze
	(
		int istanze
	)
	{
		System.out.print( Thread.currentThread().getName() + " rilascia " + istanze );
		istanzeDisponibili += istanze;
		System.out.println( "; adesso disponibili: " + istanzeDisponibili );
		while ( pendenti.size() > 0 )
		{
			Richiesta r = (Richiesta) pendenti.getFirst();
			System.out.println( "pendente: " + r.richiesta );
			if ( r.richiesta <= istanzeDisponibili )
			{
				pendenti.removeFirst();
				istanzeDisponibili -= r.richiesta;
				System.out.println( "sbloccato " + r.richiedente );
				notify();
			}
			else
				return;
		}
	}
	public int istanzeDisponibili() { return istanzeDisponibili; }; 
	private int istanzeDisponibili;
	private LinkedList pendenti = new LinkedList();
}
