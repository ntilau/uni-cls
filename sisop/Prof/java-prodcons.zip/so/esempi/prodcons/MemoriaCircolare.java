package so.esempi.prodcons;

public
class
MemoriaCircolare
implements
	Memoria
{
	public
	MemoriaCircolare
	(
		int dimensione
	)
	{
		this.dimensione = dimensione;
		ingresso = 0;
		uscita = 0;
		buffer = new Object[ dimensione ];
	}

	public
	void
	deposita
	(
		Object o
	)
	throws
		Exception
	{
		if ( piena() )
			throw new Exception( "Buffer pieno." );
		buffer[ ingresso ] = o;
		ingresso = ( ingresso + 1 ) % dimensione;
		celle_piene++;
	}


	public
	Object
	preleva()
	throws
		Exception
	{
		if ( vuota() )
			throw new Exception( "Buffer vuoto." );
		Object valore = buffer[ uscita ];
		uscita = ( uscita + 1 ) % dimensione;
		celle_piene--;
		return valore;
	}

	public
	boolean
	piena()
	{
		return ( dimensione == celle_piene );
	}

	public
	boolean
	vuota()
	{
		return ( 0 == celle_piene );
	}

	private int dimensione = 0;
	private int celle_piene = 0;
	private int ingresso = 0;
	private int uscita = 0;
	private Object[] buffer = null;
}
