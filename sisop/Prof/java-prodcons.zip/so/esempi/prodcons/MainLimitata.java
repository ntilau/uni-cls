package so.esempi.prodcons;

public class MainLimitata
{
	/**	costante utilizzata nel calcolo del tempo per il quale i thread
	produttore e consumatore si sospendono (in secondi)	*/
	public static final int SLEEP_TIME = 5;

	public static void main( String[] args )
	{
		//	crea una memoria condivisa di capacita' limitata
		MemoriaCircolare b = new MemoriaCircolare( 20 );
		/*	crea un oggetto di tipo Produttore, indicando la memoria condivisa
			in cui depositare i dati	*/
		Produttore p = new Produttore( b, SLEEP_TIME );
		/*	crea un oggetto di tipo Consumatore, indicando la memoria condivisa
			da cui prelevare i dati	*/
		Consumatore c = new Consumatore( b, SLEEP_TIME );
		//	avvia il thread consumatore
		c.start();
		//	avvia il thread produttore
		p.start();
		//	il thread principale (cioe' questo) si pone in attesa (10 secondi)
		try
		{
			Thread.sleep( 10000 );
			//	interrompe i threads produttore e consumatore
			p.interrompi();
			c.interrompi();
			/*	il thread principale si blocca in attesa che il thread consumatore
				termini la sua esecuzione	*/
			c.join();
		}
		catch ( InterruptedException ie ) {}
	}
}
