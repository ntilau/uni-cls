package so.esempi.prodcons;

import java.util.List;
import java.util.LinkedList;
 
public
class
MemoriaIllimitata
implements
	Memoria
{
	/**	costante utilizzata nel calcolo del tempo per il quale i thread
		produttore e consumatore si sospendono (in secondi)	*/
	public static final int SLEEP_TIME = 5;

	public MemoriaIllimitata()
	{
		coda = new LinkedList();
	}
   
	public
	void
	deposita
	(
		Object msg
	)
	throws
		Exception
	{
		coda.add( msg );
	}
   
	public
	Object
	preleva()
	throws
		Exception
	{
		Object msg = null;
		//	se la coda non e' vuota...
		if ( ! vuota() )
		{
			//	...prende il primo elemento della coda e lo rimuove
			msg = coda.get( 0 );
			coda.remove( 0 );
		}
		else
			throw new Exception( "la coda e' piena" );
		return msg;
	}

	public
	boolean
	vuota()
	{
		return ( coda.size() == 0 );
	}

	public
	boolean
	piena()
	{
		return false;
	}

	//*	la coda di messaggi, teoricamente illimitata
	private List coda;
}
