package comunicazione.tcp;

/*	classe Java che realizza un semplice server TCP.
	Il server legge i caratteri inviati dal client, e li rimanda indietro.
*/

import java.io.InputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.Socket;
import java.net.ServerSocket;

class Worker extends Thread {
	Worker( Socket clientSocket ) {
		this.clientSocket = clientSocket;
	}

	public void run() {
		try
		{
			/*	ottiene lo stream di ingresso collegato alla
				socket, ovvero il canale attraverso il quale il
				client invia la richiesta al server
			*/
			InputStream is = clientSocket.getInputStream();
			/*	ottiene lo stream di uscita collegato alla socket,
				ovvero il canale attraverso il quale il server
				invia la risposta al client
			*/
			OutputStream os = clientSocket.getOutputStream();
			/*	legge i dati sullo stream di ingresso e li ricopia
				sullo stream di uscita
			*/
			boolean stop = false;
			while ( ! stop )
			{
				int b = is.read();
				if ( -1 == b )
					stop = true;
				else
					os.write( (byte) b );
			}
		} catch ( IOException ioe )
		{
			System.err.println(
				"errori di I/O durante comunicazione con client"
			);
		}
		finally {
			try {
				clientSocket.close();
			} catch ( IOException ioe ) {}
		}
	}

	private Socket clientSocket = null;
}

public class TCPMultiThreadedEchoServer extends Thread {

	public TCPMultiThreadedEchoServer ( int porta ) {
		try {
		/*	crea la porta su cui ascoltare istanziando un oggetto
			della classe ServerSocket. Al costruttore viene passato
			l'identificatore della porta su cui si intende porre in
			ascolto il processo per fornire il servizio
		*/
			serverSocket = new ServerSocket( porta );
		} catch ( IOException ioe ) {
			System.err.println( "impossibile creare socket" );
			System.exit( 1 );
		}
		System.out.println( "server attivo sulla porta " + porta );
	}

	public void run() {
		while ( true ) {
			/*	il server si blocca in ascolto sulla porta finche' non
				arriva una richiesta da parte in un client. Il metodo
				restituisce quindi un oggetto di tipo socket, attraverso
				il quale il server puo' comunicare con il client
			*/
			Socket client_socket = null;
			try {
				client_socket = serverSocket.accept();
				Worker worker_thread = new Worker( client_socket );
				worker_thread.start();
			} catch ( IOException ioe ) {
				System.err.println( "errore di I/O durante ascolto" );
				try {
					client_socket.close();
				} catch ( IOException ioe2 ) {}
			}
		}
	}

	private ServerSocket serverSocket = null;

	public static void main( String args[] ) {
		int porta = Integer.parseInt( args[ 0 ] );
		TCPMultiThreadedEchoServer dispatcher =
			new TCPMultiThreadedEchoServer( porta );
		dispatcher.start();
	}
}
