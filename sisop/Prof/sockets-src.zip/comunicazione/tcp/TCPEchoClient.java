package comunicazione.tcp;

/*	classe Java che realizza un semplice server TCP.
	Il server legge i caratteri inviati dal client, e li rimanda indietro.
	Per lanciare il server:

java -cp . comunicazione.tcp.TCPEchoServer <host> <porta> <stringa>

*/

import java.io.InputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.Socket;
import java.net.UnknownHostException;

public class TCPEchoClient {
	public static void main( String args[] ) {
		Socket socket = null;
		try {
			String host = args[ 0 ];
			int porta = Integer.parseInt( args[ 1 ] );
			socket = new Socket( host, porta );
			InputStream is = socket.getInputStream();
			OutputStream os = socket.getOutputStream();
			/*	copia in un vettore di bytes la rappresentazione della
				stringa che si intende inviare al server
			*/
			byte[] dati = args[ 2 ].getBytes();
			/*	invia i dati al server
			*/
			os.write( dati );
			/*	chiude lo stream per l'invio dei dati al server
				(la richiesta e' completata)
			*/
			socket.shutdownOutput();
			boolean stop = false;
			while ( ! stop )
			{
				int b = is.read();
				if ( -1 == b )
				{
					/*	e' stata raggiunta la fine dello stream
					*/
					stop = true;
				}
				else
				{
					System.out.print( (char) b );
					System.out.flush();
				}
			}
			socket.close();
		} catch ( UnknownHostException uhe ) {
			System.err.println( "host sconosciuto" );
		} catch ( IOException ioe ) {
			System.err.println( "errore di I/O" );
		} finally {
			try {
				if ( null != socket )
					socket.close();
			} catch ( IOException ioe ) {}
		}
	}
}
