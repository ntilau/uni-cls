package comunicazione.tcp;

/*	classe Java che realizza un semplice server TCP.
	Il server legge i caratteri inviati dal client, e li rimanda indietro.
	Per lanciare il server:

		java -cp . comunicazione.tcp.TCPEchoServer <porta>

	e per verificarne il funzionamento:

		telnet localhost <porta>

	e quindi digitare caratteri. Nota bene: questo server non e' in grado di
	servire piu' richieste contemporaneamente.
*/

import java.io.InputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.Socket;
import java.net.ServerSocket;

public class TCPEchoServer {
	public static void main( String args[] ) {
		ServerSocket server_socket = null;
		int porta = Integer.parseInt( args[ 0 ] );
		try {
		/*	crea la porta su cui ascoltare istanziando un oggetto
			della classe ServerSocket. Al costruttore viene passato
			l'identificatore della porta su cui si intende porre in
			ascolto il processo per fornire il servizio
		*/
			server_socket = new ServerSocket( porta );
		} catch ( IOException ioe ) {
			System.err.println( "impossibile creare socket" );
			System.exit( 1 );
		}
		System.out.println( "server attivo sulla porta " + porta );
		Socket client_socket = null;
		boolean esegui = true;
		while ( esegui ) {
			/*	il server si blocca in ascolto sulla porta finche' non
				arriva una richiesta da parte in un client. Il metodo
				restituisce quindi un oggetto di tipo socket, attraverso
				il quale il server puo' comunicare con il client
			*/
			try {
				client_socket = server_socket.accept();
				/*	ottiene lo stream di ingresso collegato alla
					socket, ovvero il canale attraverso il quale il
					client invia la richiesta al server
				*/
				InputStream is = client_socket.getInputStream();
				/*	ottiene lo stream di uscita collegato alla socket,
					ovvero il canale attraverso il quale il server
					invia la risposta al client
				*/
				OutputStream os = client_socket.getOutputStream();
				/*	legge i dati sullo stream di ingresso e li ricopia
					sullo stream di uscita
				*/
				boolean stop = false;
				while ( ! stop )
				{
					int b = is.read();
					if ( -1 == b )
						stop = true;
					else
						os.write( (byte) b );
				}
			} catch ( IOException ioe ) {
				System.err.println( "errore di I/O" );
			} finally {
				try {
					client_socket.close();
				} catch ( IOException ioe ) {}
			}
		}
		/*	si chiude la socket (anche se in pratica questa istruzione non
			verra' eseguita perche' non e' prevista la possibilita' di
			uscire dal ciclo infinito di servizio)
		*/
		try {
			server_socket.close();
		} catch ( IOException ioe ) {}
	}
}
