#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <limits.h>
#include <time.h>

#define DIM 20
#define N_ELEMENTI 50

/*
	Il programma crea due processi---un produttore ed un consumatore---che
	comunicano attraverso una memoria circolare realizzata in memoria condivisa.
	se DIM e' la dimensione della memoria circolare, al sistema viene richiesta
	un'area di dimensione DIM+3, al fine di memorizzare anche i valori della
	dimensione stessa, ed gli indici "in" e "out".

	Per compilare:

		gcc -o produttore_consumatore-shmem produttore_consumatore-shmem.c

	e per lanciare:

		./produttore_consumatore-shmem

	@version 1.0 12/03/2003
	@author	Jurgen Assfalg
 */

int
main
(
	int argc,
	char **argv
)
{
	int shmid;
	int *buffer;
	int *dimensione;
	int *in;
	int *out;
	int pid;
	
	shmid = shmget(
		IPC_PRIVATE, sizeof( int ) * ( DIM + 3 ), IPC_CREAT | SHM_R | SHM_W
	);
	if ( shmid < 0 )
	{
		printf( "problemi nella creazione della memoria condivisa\n" );
		exit( 1 );
	}
	buffer = (int *) shmat( shmid, 0, 0 );
	/*	imposta dimensione del buffer circolare	*/
	dimensione  = &buffer[ DIM ];
	*dimensione = DIM;
	/*	inizializza il valore dell'indice "in"	*/
	in = &buffer[ DIM + 1 ];
	*in = 0;
	/*	inizializza il valore dell'indice "out"	*/
	out = &buffer[ DIM + 2 ];
	*out = 0;
	pid = fork();
	if ( 0 < pid )
	{
		int i;

		printf( "iniziata esecuzione del produttore\n" );
		/*	inizializza il generatore di numeri casuali	*/
		srand( time( 0 ) );
		/*	il padre ricopre il ruolo del produttore	*/
		for ( i = 0; i < N_ELEMENTI; i++ )
		{
			int valore;

			while ( ( *in + 1 ) % *dimensione == *out );
			valore = rand();
			buffer[ *in ] = valore;
			*in = ( *in + 1 ) % *dimensione;
			printf(
				"p-%2d> produttore ha depositato il valore %d\n", i, valore
			);
		}
		/*	il processo si scollega dalla memoria condivisa, ma non la libera
			(lasciando cosi' al consumatore la possibilita' di prelevare
			eventuali dati non ancora consumati)	*/
		shmdt( buffer );
		printf( "terminata esecuzione del produttore\n" );
		exit( 0 );
	}
	else
	if ( 0 == pid )
	{
		int i;
		struct shmid_ds descrittore;

		printf( "iniziata esecuzione del consumatore\n" );
		/*	inizializza il generatore di numeri casuali	*/
		srand( time( 0 ) );
		/*	il figlio ricopre il ruolo del consumatore	*/
		for ( i = 0; i < N_ELEMENTI; i++ )
		{
			int valore;
			int attesa;

			while ( *in == *out );
			valore = buffer[ *out ];
			*out = ( *out + 1 ) % *dimensione;
			printf(
				"c-%2d> consumatore ha prelevato il valore %d\n", i, valore
			);
			attesa = (int) ( 5.0 * rand() / RAND_MAX );
			printf( "consumatore attende %d secondi\n", attesa );
			sleep( attesa );
		}
		/*	il processo si scollega dalla memoria condivisa...	*/
		shmdt( buffer );
		/*	...e libera la memoria condivisa
			(nessun altro processo la sta piu' usando)	*/
		shmctl( shmid, IPC_RMID, &descrittore );
		printf( "terminata esecuzione del consumatore\n" );
		exit( 0 );
	}
	printf( "problemi nella generazione del processo consumatore" );
	exit( 2 );
}
