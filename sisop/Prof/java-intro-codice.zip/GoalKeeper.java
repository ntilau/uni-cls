public class GoalKeeper extends Player
{
	private int saves = 0;
	private int  failedSaves = 0;

	public GoalKeeper( String n )
	{
		super( n );
	}

	public void incSaves()
	{
		saves++;
	}

	public void incFailedSaves()
	{
		failedSaves++;
	}

	public String toString()
	{
		return new String (
			super.toString() +
			System.getProperty( "line.separator" ) +
			"He succeded in " + saves + " saves, and failed in " + failedSaves + "."
		);
	}
}