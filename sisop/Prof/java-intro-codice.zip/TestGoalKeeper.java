public class TestGoalKeeper
{
	public static void main( String[] args )
	{
		if ( 1 != args.length )
		{
			System.err.println( "\tjava TestGoalKeeper <name>" );
			System.exit( 1 );
		}
		GoalKeeper gk = new GoalKeeper( args[ 0 ] );
		gk.incGoals();
		gk.incSaves();
		gk.incSaves();
		gk.incFailedSaves();
		System.out.println( gk.toString() );
	}
}