public class TestPlayer
{
	public static void main( String[] args )
	{
		if ( 2 != args.length )
		{
			System.err.println( "\tjava TestPlayer <player_name> <number_of_goals>" );
			System.exit( 1 );
		}
		Player p = new Player( args[ 0 ] );
		try
		{
			p.incGoals( Integer.parseInt( args[ 1 ] ) );
		}
		catch ( IllegalArgumentException iae )
		{
			System.err.println( "Exception occurred: " + iae.toString() );
		}
		finally
		{
			System.out.println( p.toString() );
		}
	}
}