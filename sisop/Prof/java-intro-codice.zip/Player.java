public class Player
{
	private String name = null;
	private int goals = 0;

	public Player( String n )
	{
		name = n;
	}

	public String getName()
	{
		return name;
	}

	public int getGoals()
	{
		return goals;
	}

	public void incGoals()
	{
		goals++;
	}

	public void incGoals( int g )
		throws IllegalArgumentException
	{
		if ( g <= 0 )
			throw new IllegalArgumentException( "argument goals must be > 0" );
		goals += g;
	}

	public String toString()
	{
		return new String( name + " has scored " + goals + " goals." );
	}
}