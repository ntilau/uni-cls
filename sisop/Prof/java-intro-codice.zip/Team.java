import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedList;

public class Team
{
	private Collection players = null;
	private String name = null;

	public Team( String n )
	{
		name = n;
		players = new LinkedList();
	}

	public void addPlayer( Player p )
	{
		players.add( p );
	}

	public int getGoals()
	{
		int goals = 0;
		for( Iterator i = players.iterator(); i.hasNext(); )
		{
			Player p = (Player) i.next();
			goals += p.getGoals();
		}
		return goals;
	}

	public String toString()
	{
		StringBuffer sb = new StringBuffer();
		String new_line = System.getProperty( "line.separator" );
		sb.append( "Composition of team \"" + name + "\":" + new_line );
		for( Iterator i = players.iterator(); i.hasNext(); )
		{
			Player p = (Player) i.next();
			sb.append( p.toString() + new_line );
		}
		return sb.toString();
	}
}