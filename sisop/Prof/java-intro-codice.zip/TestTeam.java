public class TestTeam
{
	public static void main( String[] args )
	{
		Team t = new Team( "Squadrone" );
		try
		{
			Player p = new GoalKeeper( "Johnny Portiere" );
			p.incGoals( 1 );
			t.addPlayer( p );
			p = new Player( "Gino Difensore" );
			p.incGoals( 3 );
			t.addPlayer( p );
			p = new Player( "Marc Attaccante" );
			p.incGoals( 8 );
			t.addPlayer( p );
		}
		catch ( IllegalArgumentException iae )
		{
		}
		System.out.println( t.toString() );
		System.out.println( "The team has scored " + t.getGoals() + " goals." );
	}
}