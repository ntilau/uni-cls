package so.esempi.threads;

/**
 * Orologio interrompibile.
 * 
 * Rappresenta un'evoluzione della classe Orologio che prevede la
 * possibilit&agrve; di interrompere l'esecuzione del thread.
 * 
 * @see so.esempi.threads.Orologio 
 */

public
class
OrologioInterrompibile
extends
	Thread
{
	public
	OrologioInterrompibile
	(
		int p
	)
	{
		this.periodo = p;
		continua = true;
	}

	/**
	 *	Interrompe l'orologio.
	 */
	public
	void
	interrompi()
	{
		continua = false;
	}

	public
	void
	run()
	{
		/*	Quando la variabile di controllo assume il valore falso
		 *	il thread esce dal ciclo e termina la propria esecuzione.
		 */
		while ( continua )
		{
			try
			{
				Thread.sleep( periodo );
				System.out.println(
					"millisecondi dal 1' gennaio 1970 "
					+ System.currentTimeMillis()
					+ System.getProperty( "line.separator" )
					+ "sono passati circa " + periodo
					+ " millisecondi dall'ultimo \"tick\" dell'orologio."
				);
			}
			catch ( InterruptedException ie )
			{
				System.out.println( "orologio interrotto." );
			}
		}
	}

	private int periodo;
	//*	indica se il thread pu&ograve; proseguire la propria esecuzione o meno
	private boolean continua;
}
