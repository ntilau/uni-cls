package so.esempi.threads;

/**
 * Esempio d'utilizzo della classe Orologio.
 * 
 * Per eseguire il programma:
 * <tt>java threads.ProvaOrologio &lt;periodo&gt;</tt>
 */

public
class
ProvaOrologio
{
	public
	static
	void
	main
	(
		String[] argomenti
	)
	{
		/*	verifica che sulla linea di comando sia stato specificato
		 	almeno un argomento
		 */ 
		if ( argomenti.length < 1 )
		{
			//	segnala errore e...
			System.err.println(
				"sintassi: java threads.ProvaOrologio <periodo>"
			);
			//	...termina il programma
			System.exit( 1 );
		}
		try
		{
			/*	converte l'argomento in un intero: il metodo puo' generare una
			 * 	NumberFormatException se la stringa non rappresenta un numero
			 *	intero.
			 */
			int periodo = Integer.parseInt( argomenti[ 0 ] );
			//	crea un'istanza della classe Orologio
			Orologio o = new Orologio( periodo );
			//	avvia il thread
			o.start();
		}
		catch ( NumberFormatException nfe )
		{
			//	in caso di eccezione, segnala errore e...
			System.err.println( "il periodo deve essere un numero intero." );
			//	...termina il programma
			System.exit( 2 );
		}
	}
}
