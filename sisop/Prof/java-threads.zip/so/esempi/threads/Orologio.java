package so.esempi.threads;

/**
 * Orologio.
 * 
 * La classe implementa un orologio che periodicamente segnala l'ora corrente
 * (in millisecondi dal 1' gennaio 1970). Il periodo pu&ograve; &egrave;
 * impostatato dall'utente quando l'orologio viene istanziato.
 */

public
class
Orologio
extends
	Thread
{
	/**
	 * Costruttore.
	 * Inizializza l'istanza della classe.
	 * 
	 * @param p il periodo di attivazione dell'orologio
	 */
	public
	Orologio
	(
		int p
	)
	{
		this.periodo = p;
	}

	/**
	 *	ridefinizione del metodo run della classe Thread
	 */
	public
	void
	run()
	{
		while ( true )
		{
			try
			{
				Thread.sleep( periodo );
				System.out.println(
					"millisecondi dal 1' gennaio 1970: "
					+ System.currentTimeMillis()
					+ System.getProperty( "line.separator" )
					+ "sono passati circa " + periodo
					+ " millisecondi dall'ultimo \"tick\" dell'orologio."
				);
			}
			catch ( InterruptedException ie )
			{
				System.out.println( "orologio interrotto." );
			}
		}
	}

	//*	periodo di attivazione dell'orologio
	private int periodo;
}
