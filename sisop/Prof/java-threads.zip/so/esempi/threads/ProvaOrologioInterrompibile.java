package so.esempi.threads;

/**
 * Esempio d'utilizzo della classe OrologioInterrompibile.
 * 
 * Per eseguire il programma: <tt>
 * java threads.ProvaOrologioInterrompibile &lt;periodo&gt; &lt;durata&gt;
 * </tt>
 * Il programma avvia un thread principale che, dopo aver avviato un thread
 * OrologioInterrompibile, si sospende per un periodo di tempo pari a
 * <tt>&lt;durata&gt;</tt>, trascorso il quale provvede ad interrompere
 * l'orologio.
 */

public
class
ProvaOrologioInterrompibile
{
	public
	static
	void
	main
	(
		String[] argomenti
	)
	{
		if ( argomenti.length < 2 )
		{
			System.out.println(
				"sintassi: java threads.ProvaOrologio <periodo> <durata>"
			);
			System.exit( 1 );
		}
		OrologioInterrompibile o = null;
		try
		{
			/*	converte l'argomento in un intero: il metodo puo' generare una
			 * 	NumberFormatException se la stringa non rappresenta un numero
			 *	intero.
			 */
			int periodo = Integer.parseInt( argomenti[ 0 ] );
			int durata = Integer.parseInt( argomenti[ 1 ] );
			//	crea un'istanza della classe Orologio
			o = new OrologioInterrompibile( periodo );
			//	avvia il thread
			o.start();
			//	il thread principale si sospende per un certo tempo
			Thread.sleep( durata );
		}
		catch ( NumberFormatException nfe )
		{
			//	in caso di eccezione, segnala errore e...
			System.err.println( "il periodo deve essere un numero intero." );
			//	...termina il programma
			System.exit( 2 );
		}
		catch ( InterruptedException ie )
		{
			System.err.println( "il thread principale e' stato interrotto." );
		}
		finally
		{
			/*	se e' stata creata un'istanza di OrologioInterrompibile,
			 *	si richiede l'interruzione del thread associato
			 */
			if ( o != null )
				o.interrompi();
		}
	}
}
