package so.esempi.threads;

import java.math.BigInteger;

/**
 *	Calcolo delle potenze di un numero.
 *
 *	La classe realizza il calcolo della potenza di un numero intero con
 *	esponenti creascenti, sfruttando una classe per la gestione di interi
 *	con precisione arbitraria.
 */

public
class
	PotenzeDiInteri
implements
	Runnable
{
	public
	PotenzeDiInteri
	(
		int base
	)
	{
		this.base = BigInteger.valueOf( base );
		esponente = 1;
		continua = true;
		potenza = BigInteger.valueOf( base );
	}

	public
	BigInteger
	base()
	{
		return base;
	}

	public
	int
	esponente()
	{
		return esponente;
	}

	public
	BigInteger
	potenza()
	{
		return potenza;
	}

	public
	void
	interrompi()
	{
		continua = false;
	}

	public
	void
	run()
	{
		while ( continua )
		{
			potenza = base.pow( esponente );
			esponente++;
		}
	}

	private BigInteger base;
	private int esponente;
	private BigInteger potenza;
	private boolean continua;
}
