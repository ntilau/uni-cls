package so.esempi.threads;

/**
 *	Esempio per l'uso di threads per svolgere diverse operazioni in parallelo.
 *
 *	Il programma avvia 3 threads:
 *	-	il thread principale, che crea gli altri 2 threads
 *	-	un thread calcolatore, che svolge operazioni di calcolo definite nella
 *		classe PotenzeDiInteri
 *	-	un thread supervisore, che periodicamente visualizza i risultati
 *		dell'elaborazione svolta dal thread calcolatore; il thread supervisore
 *		determina anche quando &egrave; necessario terminare l'elaborazione.
 */

public
class
SupervisoreCalcolo
implements
	Runnable
{
	SupervisoreCalcolo
	(
		int iterazioni,
		int periodo,
		PotenzeDiInteri calcolo
	)
	{
		this.iterazioni = iterazioni;
		this.periodo = periodo;
		this.calcolo = calcolo;
	}

	public
	void
	run()
	{
		for ( int i = 0; i < iterazioni; i++ )
		{
			try
			{
				//	il supervisore si sospende per il periodo specificato
				Thread.sleep( periodo );
				System.out.println(
					"sono passati circa " + periodo
					+ " millisecondi, dall'ultimo controllo."
				);
				//	visualizza lo stato dell'elaborazione
				System.out.println(
					"base: " + calcolo.base()
					+ "; esponente: " + calcolo.esponente()
					+ "; potenza: " + calcolo.potenza()
				);
			}
			catch ( InterruptedException ie )
			{
				System.out.println( "calcolo interrotto." );
			}
		}
		//	interrompe il calcolo
		calcolo.interrompi();
	}

	private int iterazioni;
	private int periodo;
	private PotenzeDiInteri calcolo;

	public
	static
	void
	main
	(
		String[] argomenti
	)
	{
		if ( argomenti.length < 3 )
		{
			System.out.println(
				"uso: java threads.Calcolatore <iterazioni> <durata> <base>"
				+ System.getProperty( "line.separator" )
				+ "\tla <durata> e' espressa in millisecondi."
			);
			System.exit( 1 );
		}
		try
		{
			PotenzeDiInteri calc = new PotenzeDiInteri(
				Integer.parseInt( argomenti[ 2 ] )
			);
			SupervisoreCalcolo superv = new SupervisoreCalcolo(
				Integer.parseInt( argomenti[ 0 ] ),
				Integer.parseInt( argomenti[ 1 ] ),
				calc
			);
			//	crea un thread per il calcolo...
			Thread thread_calcolatore = new Thread( calc );
			//	...e lo avvia
			thread_calcolatore.start();
			//	crea un thread per il supervisore...
			Thread thread_supervisore = new Thread( superv );
			//	...e lo avvia
			thread_supervisore.start();
			System.out.println(
				"thread principale in attesa del completamento del calcolo"
			);
			try
			{
				/*	il thread principale si sospende in attesa che il thread
				 *	calcolatore termini la propria esecuzione.
				 */
				thread_calcolatore.join();
			}
			catch ( InterruptedException ie )
			{
				ie.printStackTrace();
			}
			System.out.println(
				"calcolo completato"
			);
			//	visualizza lo stato finale dell'elaborazione
			System.out.println(
				"base: " + calc.base()
				+ "; esponente: " + calc.esponente()
				+ "; potenza: " + calc.potenza()
			);
		}
		catch ( NumberFormatException nfe )
		{
			System.err.println( "I 3 parametri devono essere numeri interi" );
			System.exit( 1 );
		}
	}
}
