package so.esempi.threads;

/**
 * Sommatore parallelo.
 * La classe esemplifica l'uso dei threads per parallelizzare l'esecuzione
 * dell'operazione di somma su un vettore di interi.
 */

public class Sommatore extends Thread
{
	
	private int[] dati;

	private int inizio;

	private int fine;

	private int somma;

	private int id = 0;

	/** Crea una nuova istanza del sommatore */
	public Sommatore(int[] data, int inizio, int fine, int id )
	{
		this.dati = data;
		this.inizio = inizio;
		this.fine = fine;
		this.id = id;
	}
	
	public void run()
	{
		somma = 0;
		for ( int i = inizio; i <= fine; i++ )
		{
			somma += dati[ i ];
		}
		try
		{
			Thread.sleep( 10 * somma );
		}
		catch ( InterruptedException ie ) {}
		System.out.println( "Il thread sommatore #" + id + " e' terminato." );
	}
	
	public int getSomma()
	{
		return somma;
	}
	
	public static void main(String[] args)
	{
		int m = 99;
		int n = 10;
		int[] dati = new int[ m ];
		Sommatore[] sommatori = new Sommatore[ n ];
		for ( int i = 0; i < m; i++ )
		{
			//	data[ i ] = (int) ( Math.random() * 100 );
			dati[ i ] = i;
		}
		int dim_lavoro = m / n + ( 0 == ( m % n ) ? 0 : 1 );
		for ( int j = 0; j < n; j++ )
		{
			int inizio = j * dim_lavoro;
			int fine = inizio + ( ( j + 1 == n ) && ( 0 != m % n ) ? m % n : dim_lavoro ) - 1;
			sommatori[ j ] = new Sommatore( dati, inizio , fine, j );
			sommatori[ j ].start();
		}
		int somma = 0;
		for ( int j = 0; j < n; j++ )
		{
			try
			{
				sommatori[ j ].join();
			}
			catch ( InterruptedException ie ) {}
			somma += sommatori[ j ].getSomma();
			System.out.println( "Somma parziale: " + somma );
		}
		System.out.println( "Somma totale: " + somma );
	}
}
